﻿<#
.SYNOPSIS
    CleanOpt - main window + background monitor.
    * Auto-elevates to administrator on launch (default admin).
    * Shows a single main window (plus a tray icon); no other popups are ever shown
      by running tasks.
    * Per-minute background monitor: when RAM is under pressure, silently runs the
      strong memory optimizer (empty working sets + flush modified + purge standby lists,
      PCL / Mem Reduct / RAMMap level) with no window.
    * By default the main window is hidden and the tool lives only in the system tray
      (pass -Tray, which the startup link / logon task do). No window ever opens on its
      own; bring it up via the tray icon ("显示主窗口"). All background tasks are windowless.

.NOTES
    Run with:  powershell -WindowStyle Hidden -File CleanOpt.ps1
    Closing the window hides to the tray (monitor keeps running); use tray "退出" to quit.
#>

param([switch]$Tray)

# ---- tunables (默认; 均可被 settings.json 覆盖) ----
$RamPressureUsedPct = 85      # 内存紧张阈值%
$MonitorIntervalSec  = 60      # 监控间隔(秒)
$script:trayNotify  = $false   # 后台静默动作后是否弹托盘气泡(默认关, 遵守无弹窗)
$script:gndEnabled  = $true    # 游戏/全屏免打扰(默认开)
$script:gndProcesses = 'javaw.exe;java.exe'   # 免打扰进程名(分号/逗号分隔)
$script:diskFreeThresholdPct = 10   # 任一固定盘剩余%低于此值则自动清理
$script:idleMinutes = 5       # 系统需空闲满 N 分钟才自动优化(0=不限)
$script:optimizeStrength = 'strong'   # strong=全量(工作集+备用) / standard=仅备用列表
$script:startupDelaySec = 0   # 启动后延迟 N 秒再开始监控(0=立即)
$script:dailyEmptyRecycle = $true   # 每日任务是否包含清空回收站

# ---- 单实例: 若已运行则唤醒已有实例(打开其窗口), 不重复启动 ----
function Signal-ExistingInstance {
    # 反复尝试打开已存在实例的"显示主窗口"事件, 最多约 2 秒
    $ok = $false
    for ($i = 0; $i -lt 20; $i++) {
        try {
            $ev = [System.Threading.EventWaitHandle]::OpenExisting('CleanOpt_ShowEvent')
            $ev.Set() | Out-Null
            $ev.Dispose()
            $ok = $true
            break
        } catch {
            Start-Sleep -Milliseconds 100
        }
    }
    if (-not $ok) {
        # 极端情况下事件尚未建好: 直接创建并触发一次(无害)
        try {
            $ev = New-Object System.Threading.EventWaitHandle($false, 'AutoReset', 'CleanOpt_ShowEvent')
            $ev.Set() | Out-Null
            $ev.Dispose()
        } catch { }
    }
}

$singleMutex = New-Object System.Threading.Mutex($false, 'CleanOpt_SingleInstance')
$global:showEvent = New-Object System.Threading.EventWaitHandle($false, 'AutoReset', 'CleanOpt_ShowEvent')
try {
    $isFirst = $singleMutex.WaitOne(0)
} catch [System.Threading.AbandonedMutexException] {
    $isFirst = $true
} catch {
    # 其他异常(如权限) -> 当作首个实例继续, 不阻断工具
    $isFirst = $true
}
if (-not $isFirst) {
    # 已有实例在运行 -> 通知它显示主窗口, 然后退出(不重复启动)
    Signal-ExistingInstance
    $singleMutex.Dispose()
    exit
}

# ---- auto-elevate ----
function Test-Admin {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
}
if (-not (Test-Admin)) {
    $trayArg = if ($Tray) { ' -Tray' } else { '' }
    # 释放单实例锁, 让被提权的子进程成为唯一持有者(避免重复/丢失)
    try { $singleMutex.ReleaseMutex() } catch { }
    Start-Process -FilePath (Get-Process -Id $pid).Path -Verb RunAs `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`"$trayArg"
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# 软件图标: 取 Windows 自带的"磁盘清理"扫帚图标 (cleanmgr.exe), 主题最贴合"清理/优化"工具.
try { $script:appIcon = [System.Drawing.Icon]::ExtractAssociatedIcon('C:\Windows\System32\cleanmgr.exe') } catch { $script:appIcon = [System.Drawing.SystemIcons]::Application }

$root = $PSScriptPath | Split-Path -Parent
$global:forceExit = $false

# ---- helpers ----
function Invoke-Optimize {
    $arg = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\optimize_mem.ps1`" -Strength $script:optimizeStrength"
    Start-Process -FilePath 'powershell.exe' -ArgumentList $arg -WindowStyle Hidden
}
function Invoke-RunAll {
    $script:lblStatus.Text = '全面优化中…（清理→优化→回收站，后台无窗口）'
    $bwAll.RunWorkerAsync()
}
function Get-LastLogLine {
    param([string]$Name)
    $p = Join-Path $env:LOCALAPPDATA "CleanOpt\$Name"
    if (Test-Path $p) {
        # 只取最后 1 行, 避免每次监控都整文件读入 (日志变大后开销明显)
        $last = Get-Content -Path $p -Encoding UTF8 -Tail 1 -ErrorAction SilentlyContinue
        if ($last) { return $last[-1] }
    }
    return '(无记录)'
}
function Update-Status {
    try {
        $os = Get-CimInstance Win32_OperatingSystem
        $total = $os.TotalVisibleMemorySize  # KB
        $free  = $os.FreePhysicalMemory       # KB
        $usedPct = [math]::Round(($total - $free) / $total * 100, 1)
        $script:lblRam.Text = "内存占用: $usedPct%   (空闲 $([math]::Round($free/1024,1)) GB / $([math]::Round($total/1024,1)) GB)"
        # F4: 托盘图标随内存压力变色 (复用缓存图标, 避免 GDI 句柄泄漏)
        $script:_lastUsedPct = $usedPct
        Update-TrayIconByPct $usedPct
    } catch { }
    $script:lblClean.Text  = "上次清理: $(Get-LastLogLine 'clean_daily.log')"
    $script:lblOpt.Text    = "上次优化: $(Get-LastLogLine 'optimize_mem.log')"
}

# ---- Win32 P/Invoke + 新增功能函数 ----
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

[StructLayout(LayoutKind.Sequential)]
public struct RectStruct { public int Left, Top, Right, Bottom; }

[StructLayout(LayoutKind.Sequential)]
public struct LastInputStruct { public uint cbSize; public uint dwTime; }

public class Win32Api {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RectStruct lpRect);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("user32.dll")] public static extern bool GetLastInputInfo(ref LastInputStruct plii);
    [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);
    [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
}

public class HotkeyFilter : IMessageFilter {
    public const int WM_HOTKEY = 0x0312;
    public Action OnHotkey;
    public bool PreFilterMessage(ref Message m) {
        if (m.Msg == WM_HOTKEY && OnHotkey != null) { try { OnHotkey(); } catch { } }
        return false;
    }
}
'@

# 托盘图标随内存压力变色: 绿(<60) / 黄(60-85) / 红(>=85)
# 优化: 三个压力档位的图标只构建一次并缓存复用, 不在每次监控都新建/销毁 GDI 对象,
#       避免长期驻留托盘导致 GDI 句柄缓慢泄漏 (原实现每分钟都 New/Dispose, 长时间运行会累加).
$script:_bandIcons = $null
$script:_curBand   = ''
$script:_lastUsedPct = 0

function Build-AllBandIcons {
    $make = {
        param([System.Drawing.Color]$c)
        try {
            $bmp = New-Object System.Drawing.Bitmap(16, 16)
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            $g.SmoothingMode = 'AntiAlias'
            $g.Clear([System.Drawing.Color]::Transparent)
            $g.FillEllipse((New-Object System.Drawing.SolidBrush($c)), 1, 1, 14, 14)
            $g.DrawEllipse((New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(40, 40, 40))), 1, 1, 14, 14)
            $h = $bmp.GetHicon()
            $ico = [System.Drawing.Icon]::FromHandle($h).Clone()
            [System.Runtime.InteropServices.Marshal]::DestroyIcon($h)  # 释放 GetHicon 产生的临时句柄
            $g.Dispose(); $bmp.Dispose()
            return $ico
        } catch { return $null }
    }
    $script:_bandIcons = @{
        green  = & $make ([System.Drawing.Color]::FromArgb(60, 170, 70))
        yellow = & $make ([System.Drawing.Color]::FromArgb(230, 170, 30))
        red    = & $make ([System.Drawing.Color]::FromArgb(220, 40, 40))
    }
}

function Get-BandName {
    param([double]$Pct)
    if ($Pct -ge 85) { return 'red' }
    elseif ($Pct -ge 60) { return 'yellow' }
    else { return 'green' }
}

function Update-TrayIconByPct {
    param([double]$Pct)
    try {
        if (-not $script:_bandIcons) { Build-AllBandIcons }
        $band = Get-BandName $Pct
        if ($band -ne $script:_curBand) {
            $script:_curBand = $band
            $ico = $script:_bandIcons[$band]
            if ($ico -and $notifyIcon) { $notifyIcon.Icon = $ico }
        }
    } catch { }
}

function Dispose-BandIcons {
    if ($script:_bandIcons) {
        $script:_bandIcons.Values | ForEach-Object { try { $_.Dispose() } catch { } }
        $script:_bandIcons = $null
    }
}

function Get-ForegroundProcessName {
    try {
        $hwnd = [Win32Api]::GetForegroundWindow()
        if ($hwnd -eq [IntPtr]::Zero) { return '' }
        $pid = 0
        [Win32Api]::GetWindowThreadProcessId($hwnd, [ref]$pid) | Out-Null
        if ($pid -le 0) { return '' }
        $p = Get-Process -Id $pid -ErrorAction SilentlyContinue
        return if ($p) { $p.ProcessName } else { '' }
    } catch { return '' }
}

function Test-Fullscreen {
    try {
        $hwnd = [Win32Api]::GetForegroundWindow()
        if ($hwnd -eq [IntPtr]::Zero) { return $false }
        $rect = New-Object RectStruct
        if (-not [Win32Api]::GetWindowRect($hwnd, [ref]$rect)) { return $false }
        $b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        return ($rect.Left -le 0 -and $rect.Top -le 0 -and $rect.Right -ge $b.Width -and $rect.Bottom -ge $b.Height)
    } catch { return $false }
}

function Get-IdleMilliseconds {
    try {
        $lii = New-Object LastInputStruct
        $lii.cbSize = [uint32]([System.Runtime.InteropServices.Marshal]::SizeOf($lii))
        if ([Win32Api]::GetLastInputInfo([ref]$lii)) {
            $tick = [Environment]::TickCount
            $idle = $tick - [int]$lii.dwTime
            if ($idle -lt 0) { $idle += [int]::MaxValue }
            return $idle
        }
    } catch { }
    return 0
}

function Get-LowDiskDrive {
    param([double]$ThresholdPct)
    try {
        # 结果缓存 3 分钟, 避免每分钟监控都发起一次 WMI 查询
        if ($script:_diskCache -and (((Get-Date) - $script:_diskCache.ts).TotalSeconds -lt 180)) {
            return $script:_diskCache.result
        }
        $drives = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue
        $found = $null
        foreach ($d in $drives) {
            if ($d.Size -gt 0) {
                $freePct = $d.FreeSpace / $d.Size * 100
                if ($freePct -lt $ThresholdPct) { $found = "$($d.DeviceID) 剩余$([math]::Round($freePct,1))%"; break }
            }
        }
        $script:_diskCache = @{ ts = Get-Date; result = $found }
        return $found
    } catch { }
    return $null
}

# F1 游戏/全屏免打扰: 前台进程在列表 或 前台窗口全屏 -> 暂停自动优化
function Test-ShouldSkipAutoOptimize {
    if (-not $script:gndEnabled) { return $false }
    try {
        $name = Get-ForegroundProcessName
        if ($name) {
            $list = @($script:gndProcesses -split '[;, ]' | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ })
            if ($list -contains $name.ToLower()) { return $true }
        }
        if (Test-Fullscreen) { return $true }
    } catch { }
    return $false
}

# F7 一键导出诊断信息
function Export-Diagnostics {
    try {
        $os = Get-CimInstance Win32_OperatingSystem
        $total = [math]::Round($os.TotalVisibleMemorySize / 1024 / 1024, 2)
        $free  = [math]::Round($os.FreePhysicalMemory / 1024 / 1024, 2)
        $disks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue |
            ForEach-Object { "$($_.DeviceID) 总$([math]::Round($_.Size/1GB,1))GB / 剩余$([math]::Round($_.FreeSpace/1GB,1))GB" }
        $settings = if (Test-Path $settingsFile) { Get-Content $settingsFile -Raw -Encoding UTF8 } else { '(无 settings.json)' }
        $clean = Get-LastLogLine 'clean_daily.log'
        $opt   = Get-LastLogLine 'optimize_mem.log'
        $lines = @(
            '===== CleanOpt 诊断 =====',
            "时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
            "系统: $($os.Caption) ($($os.OSArchitecture))",
            "内存: 总 ${total}GB / 空闲 ${free}GB",
            '磁盘:',
            ($disks -join "`r`n"),
            "上次清理: $clean",
            "上次优化: $opt",
            'settings.json:',
            $settings
        )
        $sfd = New-Object System.Windows.Forms.SaveFileDialog
        $sfd.Filter = '文本文件 (*.txt)|*.txt'
        $sfd.Title = '导出诊断信息'
        $sfd.FileName = "CleanOpt_诊断_$(Get-Date -Format 'yyyyMMdd_HHmm').txt"
        if ($sfd.ShowDialog() -eq 'OK') {
            Set-Content -Path $sfd.FileName -Value ($lines -join "`r`n") -Encoding UTF8
            [System.Windows.Forms.MessageBox]::Show('已导出到:' + [Environment]::NewLine + $sfd.FileName, '诊断导出', 'OK', 'Information')
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show('导出失败: ' + $_.Exception.Message, '错误', 'OK', 'Error')
    }
}

# F10 关于对话框
function Show-AboutDialog {
    $ad = New-Object System.Windows.Forms.Form
    $ad.Text = '关于 CleanOpt'
    $ad.Size = New-Object System.Drawing.Size(420, 360)
    $ad.StartPosition = 'CenterParent'
    $ad.FormBorderStyle = 'FixedDialog'
    $ad.MaximizeBox = $false; $ad.MinimizeBox = $false
    $ad.Icon = $script:appIcon
    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true; $tb.ReadOnly = $true; $tb.ScrollBars = 'Vertical'
    $tb.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $tb.Location = New-Object System.Drawing.Point(12, 12)
    $tb.Size = New-Object System.Drawing.Size(384, 300)
    $ad.Controls.Add($tb)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(160, 320); $btnClose.Size = New-Object System.Drawing.Size(100, 28)
    $ad.Controls.Add($btnClose)
    $feats = @(
        '• 默认管理员运行，静默后台清理+优化',
        '• 内存优化：PCL 优先，回退原生四步强力引擎',
        '• 垃圾清理：火绒方式优先，回退系统原生',
        '• 每分钟监控：内存紧张/磁盘不足/空闲才优化',
        '• 游戏/全屏免打扰、全局热键 Ctrl+Alt+O',
        '• 托盘图标随内存压力变色',
        '• 单实例：重复启动只唤醒已有窗口',
        '• 设置可配置阈值/间隔/强度/延迟/免打扰',
        '• 运行日志、诊断导出、一键全面优化'
    )
    $tb.Text = "CleanOpt v1.7`r`n由 WorkBuddy 为 Jerry 定制`r`n`r`n本次优化：`r`n• 托盘图标按压力档缓存复用，修复长时间驻留的 GDI 句柄泄漏`r`n• 监控循环合并 WMI 查询，降低每分钟开销`r`n• 状态刷新只读日志末行 + 200KB 自动旋转，避免大日志拖慢刷新`r`n• PCL 路径探测结果缓存，避免每次优化都全盘扫描`r`n• 低盘检查 WMI 缓存 3 分钟、清理枚举由 3 趟合并为 1 趟`r`n`r`n功能一览：`r`n" + ($feats -join "`r`n")
    $btnClose.Add_Click({ $ad.DialogResult = 'Cancel'; $ad.Close() })
    $ad.ShowDialog() | Out-Null
}

# ---- form ----
$form = New-Object System.Windows.Forms.Form
$form.Text = 'CleanOpt · 清理优化'
$form.Icon = $script:appIcon
$form.Size = New-Object System.Drawing.Size(460, 410)
$form.StartPosition = 'CenterScreen'
$form.MinimizeBox = $true
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false

$lblRam = New-Object System.Windows.Forms.Label
$lblRam.Location = New-Object System.Drawing.Point(16, 16)
$lblRam.Size = New-Object System.Drawing.Size(420, 22)
$lblRam.Font = New-Object System.Drawing.Font('Segoe UI', 10)

$lblClean = New-Object System.Windows.Forms.Label
$lblClean.Location = New-Object System.Drawing.Point(16, 48)
$lblClean.Size = New-Object System.Drawing.Size(420, 20)
$lblClean.ForeColor = [System.Drawing.Color]::Gray

$lblOpt = New-Object System.Windows.Forms.Label
$lblOpt.Location = New-Object System.Drawing.Point(16, 72)
$lblOpt.Size = New-Object System.Drawing.Size(420, 20)
$lblOpt.ForeColor = [System.Drawing.Color]::Gray

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Location = New-Object System.Drawing.Point(16, 100)
$lblStatus.Size = New-Object System.Drawing.Size(420, 24)
$lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(0, 110, 60)

$btnClean = New-Object System.Windows.Forms.Button
$btnClean.Location = New-Object System.Drawing.Point(16, 140)
$btnClean.Size = New-Object System.Drawing.Size(200, 34)
$btnClean.Text = '立即清理垃圾'

$btnOptimize = New-Object System.Windows.Forms.Button
$btnOptimize.Location = New-Object System.Drawing.Point(236, 140)
$btnOptimize.Size = New-Object System.Drawing.Size(200, 34)
$btnOptimize.Text = '立即优化内存'

$btnRegister = New-Object System.Windows.Forms.Button
$btnRegister.Location = New-Object System.Drawing.Point(16, 186)
$btnRegister.Size = New-Object System.Drawing.Size(200, 34)
$btnRegister.Text = '注册每日任务'

$btnAutostart = New-Object System.Windows.Forms.Button
$btnAutostart.Location = New-Object System.Drawing.Point(236, 186)
$btnAutostart.Size = New-Object System.Drawing.Size(200, 34)
$btnAutostart.Text = '开机自启: 关'
try { if (Get-ScheduledTask -TaskName 'CleanOpt-Logon' -ErrorAction SilentlyContinue) { $btnAutostart.Text = '开机自启: 开' } } catch { }

$btnRecycle = New-Object System.Windows.Forms.Button
$btnRecycle.Location = New-Object System.Drawing.Point(16, 232)
$btnRecycle.Size = New-Object System.Drawing.Size(200, 34)
$btnRecycle.Text = '清空回收站'

$btnLaunch = New-Object System.Windows.Forms.Button
$btnLaunch.Location = New-Object System.Drawing.Point(236, 232)
$btnLaunch.Size = New-Object System.Drawing.Size(200, 34)
$btnLaunch.Text = '打开软件'

$btnSettings = New-Object System.Windows.Forms.Button
$btnSettings.Location = New-Object System.Drawing.Point(16, 278)
$btnSettings.Size = New-Object System.Drawing.Size(200, 34)
$btnSettings.Text = '设置'

$btnExit = New-Object System.Windows.Forms.Button
$btnExit.Location = New-Object System.Drawing.Point(236, 278)
$btnExit.Size = New-Object System.Drawing.Size(200, 34)
$btnExit.Text = '退出（完全关闭）'

$btnRunAll = New-Object System.Windows.Forms.Button
$btnRunAll.Location = New-Object System.Drawing.Point(16, 324)
$btnRunAll.Size = New-Object System.Drawing.Size(200, 34)
$btnRunAll.Text = '一键全面优化'

$btnLog = New-Object System.Windows.Forms.Button
$btnLog.Location = New-Object System.Drawing.Point(236, 324)
$btnLog.Size = New-Object System.Drawing.Size(200, 34)
$btnLog.Text = '运行日志'

$btnAbout = New-Object System.Windows.Forms.Button
$btnAbout.Location = New-Object System.Drawing.Point(16, 370)
$btnAbout.Size = New-Object System.Drawing.Size(200, 34)
$btnAbout.Text = '关于'

$btnDiag = New-Object System.Windows.Forms.Button
$btnDiag.Location = New-Object System.Drawing.Point(236, 370)
$btnDiag.Size = New-Object System.Drawing.Size(200, 34)
$btnDiag.Text = '导出诊断'

$form.Controls.AddRange(@($lblRam, $lblClean, $lblOpt, $lblStatus, $btnClean, $btnOptimize, $btnRegister, $btnAutostart, $btnRecycle, $btnLaunch, $btnSettings, $btnExit, $btnRunAll, $btnLog, $btnAbout, $btnDiag))

# ---- tray ----
$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
$notifyIcon.Icon = $script:appIcon
$notifyIcon.Text = 'CleanOpt'
$notifyIcon.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$mShow = $menu.Items.Add('显示主窗口')
$mOpt  = $menu.Items.Add('立即优化内存')
$mRecycle = $menu.Items.Add('清空回收站')
$mLaunch = $menu.Items.Add('打开软件')
$mSettings = $menu.Items.Add('设置')
$mRunAll = $menu.Items.Add('一键全面优化')
$mLog = $menu.Items.Add('运行日志')
$mDiag = $menu.Items.Add('导出诊断')
$mAbout = $menu.Items.Add('关于')
$mExit = $menu.Items.Add('退出')
$notifyIcon.ContextMenuStrip = $menu
$mShow.Add_Click({ $form.ShowInTaskbar = $true; $form.Show(); $form.WindowState = 'Normal'; $form.Activate() })
$mOpt.Add_Click({ Invoke-Optimize; $lblStatus.Text = '已触发内存优化（后台，无窗口）' })
$mRecycle.Add_Click({ $lblStatus.Text = '正在清空回收站…（后台，无窗口）'; $bwRecycle.RunWorkerAsync() })
$mLaunch.Add_Click({ Show-LauncherDialog })
$mSettings.Add_Click({ Show-SettingsDialog })
$mRunAll.Add_Click({ Invoke-RunAll })
$mLog.Add_Click({ Show-LogDialog })
$mDiag.Add_Click({ Export-Diagnostics })
$mAbout.Add_Click({ Show-AboutDialog })
$mExit.Add_Click({ $global:forceExit = $true; $notifyIcon.Dispose(); $form.Close() })
$notifyIcon.Add_DoubleClick({ $form.ShowInTaskbar = $true; $form.Show(); $form.WindowState = 'Normal'; $form.Activate() })

# ---- close -> hide to tray (no popup) ----
$form.Add_FormClosing({
    param($s, $e)
    if (-not $global:forceExit) {
        $e.Cancel = $true
        $form.Hide()
    }
})

# ---- program launcher (sub-window) ----
$appsFile = Join-Path $root 'apps.json'
function Load-Apps {
    if (Test-Path $appsFile) {
        try { return @(Get-Content $appsFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { }
    }
    return @()
}
function Save-Apps($list) {
    $list | ConvertTo-Json -Encoding UTF8 | Set-Content -Path $appsFile -Encoding UTF8
}
function Show-AddDialog {
    $ad = New-Object System.Windows.Forms.Form
    $ad.Text = '添加程序'
    $ad.Size = New-Object System.Drawing.Size(430, 180)
    $ad.StartPosition = 'CenterParent'
    $ad.FormBorderStyle = 'FixedDialog'
    $ad.MaximizeBox = $false
    $ad.MinimizeBox = $false
    $lName = New-Object System.Windows.Forms.Label; $lName.Text = '名称'; $lName.Location = New-Object System.Drawing.Point(12,16); $lName.Size = New-Object System.Drawing.Size(56,20)
    $tbName = New-Object System.Windows.Forms.TextBox; $tbName.Location = New-Object System.Drawing.Point(74,12); $tbName.Size = New-Object System.Drawing.Size(320,22)
    $lPath = New-Object System.Windows.Forms.Label; $lPath.Text = '路径'; $lPath.Location = New-Object System.Drawing.Point(12,48); $lPath.Size = New-Object System.Drawing.Size(56,20)
    $tbPath = New-Object System.Windows.Forms.TextBox; $tbPath.Location = New-Object System.Drawing.Point(74,44); $tbPath.Size = New-Object System.Drawing.Size(250,22)
    $btnBrowse = New-Object System.Windows.Forms.Button; $btnBrowse.Text = '浏览'; $btnBrowse.Location = New-Object System.Drawing.Point(330,42); $btnBrowse.Size = New-Object System.Drawing.Size(64,24)
    $btnOK = New-Object System.Windows.Forms.Button; $btnOK.Text = '确定'; $btnOK.Location = New-Object System.Drawing.Point(150,98); $btnOK.Size = New-Object System.Drawing.Size(110,28)
    $btnCancel = New-Object System.Windows.Forms.Button; $btnCancel.Text = '取消'; $btnCancel.Location = New-Object System.Drawing.Point(270,98); $btnCancel.Size = New-Object System.Drawing.Size(110,28)
    $ad.Controls.AddRange(@($lName,$tbName,$lPath,$tbPath,$btnBrowse,$btnOK,$btnCancel))
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = '可执行文件 (*.exe)|*.exe|所有文件 (*.*)|*.*'
    $ofd.Title = '选择要添加的程序'
    $btnBrowse.Add_Click({ if ($ofd.ShowDialog() -eq 'OK') { $tbPath.Text = $ofd.FileName; if (-not $tbName.Text) { $tbName.Text = [System.IO.Path]::GetFileNameWithoutExtension($ofd.FileName) } } })
    $btnOK.Add_Click({
        if (-not $tbName.Text -or -not $tbPath.Text) { [System.Windows.Forms.MessageBox]::Show('请填写名称和路径','提示','OK','Warning'); return }
        if (-not (Test-Path $tbPath.Text)) { [System.Windows.Forms.MessageBox]::Show('路径不存在: ' + $tbPath.Text,'提示','OK','Warning'); return }
        $ad.DialogResult = 'OK'; $ad.Close()
    })
    $btnCancel.Add_Click({ $ad.DialogResult = 'Cancel'; $ad.Close() })
    if ($ad.ShowDialog() -eq 'OK') { return [PSCustomObject]@{ name = $tbName.Text; path = $tbPath.Text } }
    return $null
}
function Show-LauncherDialog {
    $script:apps = @(Load-Apps)
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = '打开软件'
    $dlg.Size = New-Object System.Drawing.Size(420, 360)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.Owner = $form
    $lbl = New-Object System.Windows.Forms.Label; $lbl.Text = '选择一个程序打开（双击或点“打开”）'; $lbl.Location = New-Object System.Drawing.Point(12,10); $lbl.Size = New-Object System.Drawing.Size(384,20)
    $lb = New-Object System.Windows.Forms.ListBox; $lb.Location = New-Object System.Drawing.Point(12,36); $lb.Size = New-Object System.Drawing.Size(384,250)
    $btnOpen = New-Object System.Windows.Forms.Button; $btnOpen.Text = '打开'; $btnOpen.Location = New-Object System.Drawing.Point(12,298); $btnOpen.Size = New-Object System.Drawing.Size(116,28)
    $btnDel = New-Object System.Windows.Forms.Button; $btnDel.Text = '删除'; $btnDel.Location = New-Object System.Drawing.Point(138,298); $btnDel.Size = New-Object System.Drawing.Size(116,28)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(264,298); $btnClose.Size = New-Object System.Drawing.Size(116,28)
    $dlg.Controls.AddRange(@($lbl,$lb,$btnOpen,$btnDel,$btnClose))
    function Refresh-List {
        $lb.Items.Clear()
        foreach ($a in $script:apps) { $lb.Items.Add($a.name) }
        $lb.Items.Add('➕ 添加程序')
    }
    Refresh-List
    function Launch-ByIndex($idx) {
        if ($idx -lt 0 -or $idx -ge ($lb.Items.Count - 1)) { return }
        $a = $script:apps[$idx]
        try { Start-Process -FilePath $a.path -ErrorAction Stop; $dlg.Close() }
        catch { [System.Windows.Forms.MessageBox]::Show('无法打开: ' + $a.path,'错误','OK','Error') }
    }
    function Do-Select {
        $i = $lb.SelectedIndex
        if ($i -eq ($lb.Items.Count - 1)) {
            $na = Show-AddDialog
            if ($na) { $script:apps = @($script:apps) + $na; Save-Apps $script:apps; Refresh-List }
        } else { Launch-ByIndex $i }
    }
    $lb.Add_DoubleClick({ Do-Select })
    $btnOpen.Add_Click({ Do-Select })
    $btnDel.Add_Click({
        $i = $lb.SelectedIndex
        if ($i -ge 0 -and $i -ne ($lb.Items.Count - 1)) {
            $new = @()
            for ($k = 0; $k -lt $script:apps.Count; $k++) { if ($k -ne $i) { $new += $script:apps[$k] } }
            $script:apps = $new
            Save-Apps $script:apps
            Refresh-List
        }
    })
    $btnClose.Add_Click({ $dlg.Close() })
    $dlg.ShowDialog() | Out-Null
}

# ---- settings (external tool paths) ----
$settingsFile = Join-Path $root 'settings.json'
function Load-Settings {
    $s = [PSCustomObject]@{
        huorongPath          = ''
        pclPath              = ''
        ramPressurePct       = $RamPressureUsedPct
        monitorIntervalSec   = $MonitorIntervalSec
        trayNotify           = $script:trayNotify
        gndEnabled           = $script:gndEnabled
        gndProcesses         = $script:gndProcesses
        diskFreeThresholdPct = $script:diskFreeThresholdPct
        idleMinutes          = $script:idleMinutes
        optimizeStrength     = $script:optimizeStrength
        startupDelaySec      = $script:startupDelaySec
        dailyEmptyRecycle    = $script:dailyEmptyRecycle
    }
    if (Test-Path $settingsFile) {
        try {
            $j = Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($j.huorongPath) { $s.huorongPath = $j.huorongPath }
            if ($j.pclPath) { $s.pclPath = $j.pclPath }
            if ($j.ramPressurePct) { $s.ramPressurePct = $j.ramPressurePct }
            if ($j.monitorIntervalSec) { $s.monitorIntervalSec = $j.monitorIntervalSec }
            if ($null -ne $j.trayNotify) { $s.trayNotify = [bool]$j.trayNotify }
            if ($null -ne $j.gndEnabled) { $s.gndEnabled = [bool]$j.gndEnabled }
            if ($j.gndProcesses) { $s.gndProcesses = $j.gndProcesses }
            if ($j.diskFreeThresholdPct) { $s.diskFreeThresholdPct = $j.diskFreeThresholdPct }
            if ($null -ne $j.idleMinutes) { $s.idleMinutes = $j.idleMinutes }
            if ($j.optimizeStrength) { $s.optimizeStrength = $j.optimizeStrength }
            if ($null -ne $j.startupDelaySec) { $s.startupDelaySec = $j.startupDelaySec }
            if ($null -ne $j.dailyEmptyRecycle) { $s.dailyEmptyRecycle = [bool]$j.dailyEmptyRecycle }
        } catch { }
    }
    return $s
}
function Save-Settings($obj) {
    try { $obj | ConvertTo-Json -Encoding UTF8 | Set-Content -Path $settingsFile -Encoding UTF8 } catch { }
}

function Set-PathStatus($box) {
    $lab = $box.Tag
    if ($box.Text -and (Test-Path $box.Text)) {
        $lab.Text = '✓ 已找到'
        $lab.ForeColor = [System.Drawing.Color]::FromArgb(0, 140, 0)
    } elseif ($box.Text) {
        $lab.Text = '✗ 路径不存在，请检查'
        $lab.ForeColor = [System.Drawing.Color]::FromArgb(200, 0, 0)
    } else {
        $lab.Text = '留空 = 自动探测'
        $lab.ForeColor = [System.Drawing.Color]::Gray
    }
}

function Show-SettingsDialog {
    $cfg = Load-Settings
    $sd = New-Object System.Windows.Forms.Form
    $sd.Text = '设置 · 外部工具路径与行为'
    $sd.Size = New-Object System.Drawing.Size(560, 600)
    $sd.StartPosition = 'CenterParent'
    $sd.FormBorderStyle = 'FixedDialog'
    $sd.MaximizeBox = $false
    $sd.MinimizeBox = $false
    $sd.Owner = $form

    $hint = New-Object System.Windows.Forms.Label
    $hint.Text = '若某工具未被自动找到，请点“浏览”指定其 .exe 路径（留空则自动探测）：'
    $hint.Location = New-Object System.Drawing.Point(12, 10)
    $hint.Size = New-Object System.Drawing.Size(490, 20)
    $hint.ForeColor = [System.Drawing.Color]::Gray
    $sd.Controls.Add($hint)

    $tools = @(
        [PSCustomObject]@{ key = 'huorongPath'; name = '火绒 (垃圾清理 sysclean.exe)'; desc = '用于垃圾清理的火绒主程序' },
        [PSCustomObject]@{ key = 'pclPath'; name = 'PCL (内存优化 PCL.exe)'; desc = '用于内存优化的启动器' }
    )

    $rows = @{}
    $y = 40
    foreach ($t in $tools) {
        $lblName = New-Object System.Windows.Forms.Label
        $lblName.Text = $t.name
        $lblName.Location = New-Object System.Drawing.Point(12, $y)
        $lblName.Size = New-Object System.Drawing.Size(490, 18)
        $tb = New-Object System.Windows.Forms.TextBox
        $tb.Name = $t.name
        $tb.Text = $cfg.($t.key)
        $tb.Location = New-Object System.Drawing.Point(12, ($y + 20))
        $tb.Size = New-Object System.Drawing.Size(370, 22)
        $btnBr = New-Object System.Windows.Forms.Button
        $btnBr.Text = '浏览'
        $btnBr.Location = New-Object System.Drawing.Point(390, ($y + 18))
        $btnBr.Size = New-Object System.Drawing.Size(60, 24)
        $btnBr.Tag = $tb   # 用 Tag 避免闭包捕获循环变量
        $lblSt = New-Object System.Windows.Forms.Label
        $lblSt.Location = New-Object System.Drawing.Point(12, ($y + 46))
        $lblSt.Size = New-Object System.Drawing.Size(490, 18)
        $tb.Tag = $lblSt
        Set-PathStatus $tb
        $tb.Add_TextChanged({ param($s, $e) Set-PathStatus $s })
        $btnBr.Add_Click({
            param($s, $e)
            $ofd = New-Object System.Windows.Forms.OpenFileDialog
            $ofd.Filter = '可执行文件 (*.exe)|*.exe|所有文件 (*.*)|*.*'
            $ofd.Title = '选择 ' + $s.Tag.Name
            if ($ofd.ShowDialog() -eq 'OK') { $s.Tag.Text = $ofd.FileName }
        })
        $sd.Controls.AddRange(@($lblName, $tb, $btnBr, $lblSt))
        $rows[$t.key] = $tb
        $y += 78
    }

    # ---- 行为设置 ----
    $y += 6
    $lblBeh = New-Object System.Windows.Forms.Label
    $lblBeh.Text = '行为设置'
    $lblBeh.Location = New-Object System.Drawing.Point(12, $y)
    $lblBeh.Size = New-Object System.Drawing.Size(490, 18)
    $lblBeh.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
    $sd.Controls.Add($lblBeh)
    $y += 22

    $cbGnd = New-Object System.Windows.Forms.CheckBox; $cbGnd.Text = '游戏/全屏免打扰（全屏或下列进程运行时暂停自动优化）'; $cbGnd.Location = New-Object System.Drawing.Point(12, $y); $cbGnd.Size = New-Object System.Drawing.Size(490, 20); $cbGnd.Checked = $cfg.gndEnabled; $sd.Controls.Add($cbGnd)
    $y += 24
    $lblGndP = New-Object System.Windows.Forms.Label; $lblGndP.Text = '免打扰进程名（分号分隔，如 javaw.exe;java.exe）'; $lblGndP.Location = New-Object System.Drawing.Point(12, $y); $lblGndP.Size = New-Object System.Drawing.Size(490, 18); $sd.Controls.Add($lblGndP)
    $y += 20
    $tbGndProc = New-Object System.Windows.Forms.TextBox; $tbGndProc.Text = $cfg.gndProcesses; $tbGndProc.Location = New-Object System.Drawing.Point(12, $y); $tbGndProc.Size = New-Object System.Drawing.Size(470, 22); $sd.Controls.Add($tbGndProc)
    $y += 30

    $lblT = New-Object System.Windows.Forms.Label; $lblT.Text = '内存紧张阈值 (%)'; $lblT.Location = New-Object System.Drawing.Point(12, $y); $lblT.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblT)
    $tbThresh = New-Object System.Windows.Forms.TextBox; $tbThresh.Text = [string]$cfg.ramPressurePct; $tbThresh.Location = New-Object System.Drawing.Point(260, $y); $tbThresh.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbThresh)
    $y += 30

    $lblD = New-Object System.Windows.Forms.Label; $lblD.Text = '磁盘剩余低于 (%) 自动清理'; $lblD.Location = New-Object System.Drawing.Point(12, $y); $lblD.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblD)
    $tbDisk = New-Object System.Windows.Forms.TextBox; $tbDisk.Text = [string]$cfg.diskFreeThresholdPct; $tbDisk.Location = New-Object System.Drawing.Point(260, $y); $tbDisk.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbDisk)
    $y += 30

    $lblIv = New-Object System.Windows.Forms.Label; $lblIv.Text = '监控间隔 (秒)'; $lblIv.Location = New-Object System.Drawing.Point(12, $y); $lblIv.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblIv)
    $tbInt = New-Object System.Windows.Forms.TextBox; $tbInt.Text = [string]$cfg.monitorIntervalSec; $tbInt.Location = New-Object System.Drawing.Point(260, $y); $tbInt.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbInt)
    $y += 30

    $lblIdle = New-Object System.Windows.Forms.Label; $lblIdle.Text = '空闲满 (分钟) 才自动优化 (0=不限)'; $lblIdle.Location = New-Object System.Drawing.Point(12, $y); $lblIdle.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblIdle)
    $tbIdle = New-Object System.Windows.Forms.TextBox; $tbIdle.Text = [string]$cfg.idleMinutes; $tbIdle.Location = New-Object System.Drawing.Point(260, $y); $tbIdle.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbIdle)
    $y += 30

    $lblStr = New-Object System.Windows.Forms.Label; $lblStr.Text = '优化强度'; $lblStr.Location = New-Object System.Drawing.Point(12, $y); $lblStr.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblStr)
    $cbStrength = New-Object System.Windows.Forms.ComboBox; $cbStrength.Items.AddRange(@('strong|强力（全量：工作集+备用列表）', 'standard|标准（仅备用列表，最温和）')); $cbStrength.DropDownStyle = 'DropDownList'; $cbStrength.Location = New-Object System.Drawing.Point(260, $y); $cbStrength.Size = New-Object System.Drawing.Size(250, 22)
    if ($cfg.optimizeStrength -eq 'standard') { $cbStrength.SelectedIndex = 1 } else { $cbStrength.SelectedIndex = 0 }
    $sd.Controls.Add($cbStrength)
    $y += 30

    $lblDel = New-Object System.Windows.Forms.Label; $lblDel.Text = '启动后延迟 (秒) 再监控 (0=立即)'; $lblDel.Location = New-Object System.Drawing.Point(12, $y); $lblDel.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblDel)
    $tbDelay = New-Object System.Windows.Forms.TextBox; $tbDelay.Text = [string]$cfg.startupDelaySec; $tbDelay.Location = New-Object System.Drawing.Point(260, $y); $tbDelay.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbDelay)
    $y += 30

    $cbRecycle = New-Object System.Windows.Forms.CheckBox; $cbRecycle.Text = '每日任务包含“清空回收站”'; $cbRecycle.Location = New-Object System.Drawing.Point(12, $y); $cbRecycle.Size = New-Object System.Drawing.Size(490, 20); $cbRecycle.Checked = $cfg.dailyEmptyRecycle; $sd.Controls.Add($cbRecycle)
    $y += 26

    $cbNotify = New-Object System.Windows.Forms.CheckBox; $cbNotify.Text = '后台静默动作后显示托盘气泡提示（默认关）'; $cbNotify.Location = New-Object System.Drawing.Point(12, $y); $cbNotify.Size = New-Object System.Drawing.Size(470, 20); $cbNotify.Checked = $cfg.trayNotify; $sd.Controls.Add($cbNotify)
    $y += 32

    $btnSave = New-Object System.Windows.Forms.Button
    $btnSave.Text = '保存'
    $btnSave.Location = New-Object System.Drawing.Point(380, $y)
    $btnSave.Size = New-Object System.Drawing.Size(75, 28)
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = '取消'
    $btnCancel.Location = New-Object System.Drawing.Point(465, $y)
    $btnCancel.Size = New-Object System.Drawing.Size(75, 28)
    $sd.Controls.AddRange(@($btnSave, $btnCancel))

    $btnSave.Add_Click({
        $new = [PSCustomObject]@{
            huorongPath        = $rows['huorongPath'].Text.Trim()
            pclPath            = $rows['pclPath'].Text.Trim()
            ramPressurePct     = $RamPressureUsedPct
            monitorIntervalSec = $MonitorIntervalSec
            trayNotify         = $false
            gndEnabled         = $cbGnd.Checked
            gndProcesses       = $tbGndProc.Text.Trim()
            diskFreeThresholdPct = 10
            idleMinutes        = 5
            optimizeStrength   = 'strong'
            startupDelaySec    = 0
            dailyEmptyRecycle  = $cbRecycle.Checked
        }
        $bad = @()
        if ($new.huorongPath -and -not (Test-Path $new.huorongPath)) { $bad += '火绒' }
        if ($new.pclPath -and -not (Test-Path $new.pclPath)) { $bad += 'PCL' }
        $thr = 0; $intv = 0; $disk = 0; $idle = 0; $delay = 0
        if (-not [int]::TryParse($tbThresh.Text, [ref]$thr)) { $bad += '阈值(需整数)' }
        elseif ($thr -lt 50 -or $thr -gt 99) { $bad += '阈值(需50-99)' }
        if (-not [int]::TryParse($tbInt.Text, [ref]$intv)) { $bad += '间隔(需整数)' }
        elseif ($intv -lt 10) { $bad += '间隔(≥10秒)' }
        if (-not [int]::TryParse($tbDisk.Text, [ref]$disk)) { $bad += '磁盘阈值(需整数)' }
        elseif ($disk -lt 1 -or $disk -gt 90) { $bad += '磁盘阈值(1-90)' }
        if (-not [int]::TryParse($tbIdle.Text, [ref]$idle)) { $bad += '空闲(需整数)' }
        elseif ($idle -lt 0) { $bad += '空闲(≥0)' }
        if (-not [int]::TryParse($tbDelay.Text, [ref]$delay)) { $bad += '延迟(需整数)' }
        elseif ($delay -lt 0) { $bad += '延迟(≥0)' }
        if ($bad.Count -gt 0) {
            [System.Windows.Forms.MessageBox]::Show('请修正: ' + ($bad -join '、'), '提示', 'OK', 'Warning')
            return
        }
        $new.ramPressurePct = $thr
        $new.monitorIntervalSec = $intv
        $new.diskFreeThresholdPct = $disk
        $new.idleMinutes = $idle
        $new.startupDelaySec = $delay
        $new.optimizeStrength = if ($cbStrength.SelectedIndex -eq 1) { 'standard' } else { 'strong' }
        $new.trayNotify = $cbNotify.Checked
        Save-Settings $new
        # 立即应用到当前运行实例
        $script:RamPressureUsedPct = $thr
        $script:MonitorIntervalSec = $intv
        $script:trayNotify = $cbNotify.Checked
        $script:gndEnabled = $cbGnd.Checked
        $script:gndProcesses = $tbGndProc.Text.Trim()
        $script:diskFreeThresholdPct = $disk
        $script:idleMinutes = $idle
        $script:optimizeStrength = $new.optimizeStrength
        $script:startupDelaySec = $delay
        $script:dailyEmptyRecycle = $cbRecycle.Checked
        if ($timer) { $timer.Interval = $intv * 1000 }
        $script:lblStatus.Text = "设置已保存并生效（阈值 $thr% / 间隔 ${intv}s）"
        $sd.DialogResult = 'OK'; $sd.Close()
    })
    $btnCancel.Add_Click({ $sd.DialogResult = 'Cancel'; $sd.Close() })
    $sd.ShowDialog() | Out-Null
}

# ---- run-log viewer (read-only, user-triggered) ----
function Show-LogDialog {
    $ld = New-Object System.Windows.Forms.Form
    $ld.Text = '运行日志'
    $ld.Size = New-Object System.Drawing.Size(560, 440)
    $ld.StartPosition = 'CenterParent'
    $ld.FormBorderStyle = 'FixedDialog'
    $ld.MaximizeBox = $false
    $ld.MinimizeBox = $false
    $ld.Owner = $form
    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true
    $tb.ReadOnly = $true
    $tb.ScrollBars = 'Vertical'
    $tb.Font = New-Object System.Drawing.Font('Consolas', 9)
    $tb.Location = New-Object System.Drawing.Point(12, 12)
    $tb.Size = New-Object System.Drawing.Size(536, 360)
    $ld.Controls.Add($tb)
    $btnRefresh = New-Object System.Windows.Forms.Button; $btnRefresh.Text = '刷新'; $btnRefresh.Location = New-Object System.Drawing.Point(372, 384); $btnRefresh.Size = New-Object System.Drawing.Size(90, 28)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(468, 384); $btnClose.Size = New-Object System.Drawing.Size(80, 28)
    $ld.Controls.AddRange(@($btnRefresh, $btnClose))
    function Refresh-Log {
        $out = @()
        foreach ($n in @('clean_daily', 'optimize_mem')) {
            $p = Join-Path $env:LOCALAPPDATA "CleanOpt\$n.log"
            $out += "===== $n.log ====="
            if (Test-Path $p) { $out += (Get-Content -Path $p -Encoding UTF8 -Tail 150) } else { $out += '(无记录)' }
            $out += ''
        }
        $tb.Text = $out -join "`r`n"
        $tb.SelectionStart = $tb.Text.Length
    }
    $btnRefresh.Add_Click({ Refresh-Log })
    $btnClose.Add_Click({ $ld.DialogResult = 'Cancel'; $ld.Close() })
    Refresh-Log
    $ld.ShowDialog() | Out-Null
}

# ---- buttons ----
$btnOptimize.Add_Click({ Invoke-Optimize; $lblStatus.Text = '已触发内存优化（后台，无窗口）' })

$btnClean.Add_Click({
    $lblStatus.Text = '清理中…（后台，无窗口）'
    $bw.RunWorkerAsync()
})

$btnRecycle.Add_Click({
    $lblStatus.Text = '正在清空回收站…（后台，无窗口）'
    $bwRecycle.RunWorkerAsync()
})

$btnLaunch.Add_Click({ Show-LauncherDialog })

$btnSettings.Add_Click({ Show-SettingsDialog })

$btnRunAll.Add_Click({ Invoke-RunAll })

$btnLog.Add_Click({ Show-LogDialog })

$btnAbout.Add_Click({ Show-AboutDialog })

$btnDiag.Add_Click({ Export-Diagnostics })

$btnRegister.Add_Click({
    try {
        & "$root\Register-Tasks.ps1" -DailyTime '03:00'
        $ok = Get-ScheduledTask -TaskName 'CleanOpt-Daily' -ErrorAction SilentlyContinue
        $lblStatus.Text = if ($ok) { '每日任务已注册（03:00，静默运行）' } else { '注册失败，请手动以管理员运行 Register-Tasks.ps1' }
    } catch {
        $lblStatus.Text = '注册失败: ' + $_.Exception.Message
    }
})

$btnAutostart.Add_Click({
    $t = Get-ScheduledTask -TaskName 'CleanOpt-Logon' -ErrorAction SilentlyContinue
    if ($t) {
        Unregister-ScheduledTask -TaskName 'CleanOpt-Logon' -Confirm:$false -ErrorAction SilentlyContinue
        $btnAutostart.Text = '开机自启: 关'
        $lblStatus.Text = '已关闭开机自启'
    } else {
        & "$root\Register-Tasks.ps1" -DailyTime '03:00'
        $btnAutostart.Text = '开机自启: 开'
        $lblStatus.Text = '已开启开机自启（登录后后台运行）'
    }
})

$btnExit.Add_Click({ $global:forceExit = $true; if ($notifyIcon) { $notifyIcon.Icon = $null }; Dispose-BandIcons; $notifyIcon.Dispose(); $form.Close() })

# ---- background worker for cleanup (keeps UI responsive) ----
$bw = New-Object System.ComponentModel.BackgroundWorker
$bw.Add_DoWork({
    Start-Process -FilePath 'powershell.exe' `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\clean_daily.ps1`"" `
        -WindowStyle Hidden -Wait
})
$bw.Add_RunWorkerCompleted({
    Update-Status
    $script:lblStatus.Text = '清理完成（' + (Get-Date -Format 'HH:mm:ss') + '）'
})

# ---- background worker for emptying the Recycle Bin (keeps UI responsive, no popup) ----
# Resilient: native cmdlet first; if it fails (e.g. a locked file aborts the whole
# operation, or the cmdlet is unavailable), fall back to per-drive per-item deletion so
# one bad file never aborts the rest. Reports PARTIAL instead of a hard error.
$bwRecycle = New-Object System.ComponentModel.BackgroundWorker
$bwRecycle.Add_DoWork({
    param($s, $e)
    # 1) Preferred: native silent cmdlet
    try {
        Clear-RecycleBin -Force -ErrorAction Stop
        $global:recycleResult = 'OK'
        return
    } catch { }
    # 2) Fallback: enumerate every filesystem drive's $Recycle.Bin and delete contents
    $done = 0; $failed = 0
    try {
        $bins = @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue |
            ForEach-Object { Join-Path $_.Root '$Recycle.Bin' })
        foreach ($bin in $bins) {
            if (-not (Test-Path $bin)) { continue }
            Get-ChildItem -Path $bin -Force -ErrorAction SilentlyContinue | ForEach-Object {
                try {
                    $_ | Remove-Item -Recurse -Force -ErrorAction Stop
                    $done++
                } catch {
                    $failed++
                }
            }
        }
        if ($failed -eq 0) {
            $global:recycleResult = 'OK'
        } else {
            $global:recycleResult = "PARTIAL|已删除 $done 项，跳过 $failed 项(被占用或无权限)"
        }
    } catch {
        $global:recycleResult = 'ERR|' + $_.Exception.Message
    }
})
$bwRecycle.Add_RunWorkerCompleted({
    $r = $global:recycleResult
    if ($r -eq 'OK') {
        $script:lblStatus.Text = '回收站已清空（' + (Get-Date -Format 'HH:mm:ss') + '）'
    } elseif ($r -like 'PARTIAL|*') {
        $script:lblStatus.Text = ($r.Substring(8)) + '（' + (Get-Date -Format 'HH:mm:ss') + '）'
    } else {
        $script:lblStatus.Text = '清空回收站失败: ' + $r.Substring(4)
    }
    Update-Status
})

# ---- background worker for "一键全面优化" (clean -> optimize -> recycle, silent) ----
$bwAll = New-Object System.ComponentModel.BackgroundWorker
$bwAll.Add_DoWork({
    param($s, $e)
    # 1) 清理垃圾
    Start-Process -FilePath 'powershell.exe' `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\clean_daily.ps1`"" `
        -WindowStyle Hidden -Wait
    # 2) 优化内存 (PCL 优先, 失败回退原生, 见 optimize_mem.ps1)
    $argOpt = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\optimize_mem.ps1`" -Strength $script:optimizeStrength"
    Start-Process -FilePath 'powershell.exe' -ArgumentList $argOpt -WindowStyle Hidden -Wait
    # 3) 清空回收站 (原生静默优先, 失败逐盘回退)
    try {
        Clear-RecycleBin -Force -ErrorAction Stop
    } catch {
        Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
            $bin = Join-Path $_.Root '$Recycle.Bin'
            if (Test-Path $bin) { Get-ChildItem $bin -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue }
        }
    }
})
$bwAll.Add_RunWorkerCompleted({
    Update-Status
    $script:lblStatus.Text = '全面优化完成（' + (Get-Date -Format 'HH:mm:ss') + '）'
    if ($script:trayNotify) { $notifyIcon.ShowBalloonTip(3000, 'CleanOpt', '全面优化完成（清理+优化+回收站）', 'Info') }
})

# ---- 应用 settings.json 中的行为设置 (启动即生效) ----
$startupSettings = Load-Settings
if ($startupSettings.ramPressurePct -and $startupSettings.ramPressurePct -ge 50 -and $startupSettings.ramPressurePct -le 99) { $script:RamPressureUsedPct = $startupSettings.ramPressurePct }
if ($startupSettings.monitorIntervalSec -and $startupSettings.monitorIntervalSec -ge 10) { $script:MonitorIntervalSec = $startupSettings.monitorIntervalSec }
$script:trayNotify = [bool]$startupSettings.trayNotify
if ($null -ne $startupSettings.gndEnabled) { $script:gndEnabled = [bool]$startupSettings.gndEnabled }
if ($startupSettings.gndProcesses) { $script:gndProcesses = $startupSettings.gndProcesses }
if ($startupSettings.diskFreeThresholdPct -and $startupSettings.diskFreeThresholdPct -ge 1 -and $startupSettings.diskFreeThresholdPct -le 90) { $script:diskFreeThresholdPct = $startupSettings.diskFreeThresholdPct }
if ($null -ne $startupSettings.idleMinutes -and $startupSettings.idleMinutes -ge 0) { $script:idleMinutes = $startupSettings.idleMinutes }
if ($startupSettings.optimizeStrength -eq 'standard' -or $startupSettings.optimizeStrength -eq 'strong') { $script:optimizeStrength = $startupSettings.optimizeStrength }
if ($null -ne $startupSettings.startupDelaySec -and $startupSettings.startupDelaySec -ge 0) { $script:startupDelaySec = $startupSettings.startupDelaySec }
if ($null -ne $startupSettings.dailyEmptyRecycle) { $script:dailyEmptyRecycle = [bool]$startupSettings.dailyEmptyRecycle }

# ---- per-minute monitor ----
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = $MonitorIntervalSec * 1000
$timer.Add_Tick({
    Update-Status
    try {
        # F2: 磁盘空间不足 -> 静默自动清理 (6 小时内只触发一次, 用 stamp 限流)
        if ($script:diskFreeThresholdPct -gt 0) {
            $low = Get-LowDiskDrive $script:diskFreeThresholdPct
            if ($low) {
                $now = Get-Date
                $stamp = Join-Path $env:LOCALAPPDATA 'CleanOpt\diskclean.stamp'
                $doClean = $true
                if (Test-Path $stamp) {
                    try { $last = [datetime]::Parse((Get-Content $stamp -Encoding UTF8 -Raw).Trim()); if (($now - $last).TotalHours -lt 6) { $doClean = $false } } catch { }
                }
                if ($doClean) {
                    (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | Set-Content -Path $stamp -Encoding UTF8
                    $script:lblStatus.Text = "磁盘空间不足($low)，自动清理中…"
                    Start-Process -FilePath 'powershell.exe' -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\clean_daily.ps1`"" -WindowStyle Hidden -Wait
                    if ($script:trayNotify) { $notifyIcon.ShowBalloonTip(3000, 'CleanOpt', "磁盘空间不足($low)，已自动清理", 'Info') }
                }
            }
        }
        # 内存紧张 -> 自动优化 (受免打扰 / 空闲 控制)
        # 复用 Update-Status 刚算好的占用率, 避免每分钟重复查询 WMI
        $usedPct = $script:_lastUsedPct
        if ($usedPct -ge $RamPressureUsedPct) {
            if (Test-ShouldSkipAutoOptimize) {
                $script:lblStatus.Text = (Get-Date -Format 'HH:mm:ss') + " 内存紧张($usedPct%)，但处于免打扰(游戏/全屏)，跳过"
            } else {
                $idleOk = $true
                if ($script:idleMinutes -gt 0) {
                    $idleMs = Get-IdleMilliseconds
                    if ($idleMs -lt ($script:idleMinutes * 60000)) { $idleOk = $false }
                }
                if ($idleOk) {
                    Invoke-Optimize
                    $script:lblStatus.Text = (Get-Date -Format 'HH:mm:ss') + " 内存紧张($usedPct%)，已自动优化"
                    if ($script:trayNotify) { $notifyIcon.ShowBalloonTip(3000, 'CleanOpt', "内存紧张($usedPct%)，已自动优化", 'Info') }
                } else {
                    $script:lblStatus.Text = (Get-Date -Format 'HH:mm:ss') + " 内存紧张($usedPct%)，系统使用中，稍后优化"
                }
            }
        }
    } catch { }
})
# F6: 启动延迟 —— 延迟 N 秒再开始监控
if ($script:startupDelaySec -gt 0) {
    $startupTimer = New-Object System.Windows.Forms.Timer
    $startupTimer.Interval = $script:startupDelaySec * 1000
    $startupTimer.Add_Tick({
        $timer.Start()
        $startupTimer.Stop(); $startupTimer.Dispose()
    })
    $startupTimer.Start()
} else {
    $timer.Start()
}

# ---- 单实例: 唤醒信号(被另一实例触发时打开窗口) ----
# 用 WinForms 计时器轮询命名事件: 在 UI 线程执行, 无需跨线程封送, 最稳.
$wakeTimer = New-Object System.Windows.Forms.Timer
$wakeTimer.Interval = 500
$wakeTimer.Add_Tick({
    if ($global:showEvent.WaitOne(0)) {
        $form.ShowInTaskbar = $true
        $form.Show()
        $form.WindowState = 'Normal'
        $form.Activate()
    }
})
$wakeTimer.Start()

# ---- F9: 全局热键 Ctrl+Alt+O -> 立即优化内存 ----
try {
    $global:hotkeyFilter = New-Object HotkeyFilter
    $global:hotkeyFilter.OnHotkey = {
        try {
            Invoke-Optimize
            if ($script:lblStatus) { $script:lblStatus.Text = '全局热键(Ctrl+Alt+O)已触发内存优化' }
            if ($script:trayNotify) { $notifyIcon.ShowBalloonTip(3000, 'CleanOpt', '已通过热键优化内存', 'Info') }
        } catch { }
    }
    [System.Windows.Forms.Application]::AddMessageFilter($global:hotkeyFilter)
    $null = $form.Handle   # 确保窗口句柄已创建
    # MOD_CONTROL(2) | MOD_ALT(1), VK_O = 0x4F
    $global:hotkeyRegistered = [Win32Api]::RegisterHotKey($form.Handle, 1, (2 -bor 1), 0x4F)
} catch { $global:hotkeyRegistered = $false }

# ---- go ----
Update-Status
if ($Tray) {
    # 托盘模式: 启动后不弹任何窗口, 仅驻留系统托盘.
    $form.WindowState = 'Minimized'
    $form.ShowInTaskbar = $false
    $form.Hide()
}
[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::Run($form)
