﻿<#
.SYNOPSIS
    CleanOpt - Register / unregister scheduled tasks.
    * CleanOpt-Daily : runs the silent cleaner+optimizer every day (hidden, SYSTEM, no UI).
    * CleanOpt-Logon : launches the GUI/monitor at user logon (hidden; GUI lives in tray).

.NOTES
    Requires administrator privileges (auto-elevates). No windows are created by the
    daily task because it runs as SYSTEM with -WindowStyle Hidden.
#>

[CmdletBinding()]
param(
    [string]$DailyTime = '03:00',
    [switch]$Unregister
)

$ErrorActionPreference = 'SilentlyContinue'

function Test-Admin {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Self-elevate
if (-not (Test-Admin)) {
    Start-Process -FilePath (Get-Process -Id $pid).Path -Verb RunAs `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -DailyTime $DailyTime"
    exit
}

$root = $PSScriptRoot
$dailyAction = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\daily_run.ps1`""
$logonAction = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\CleanOpt.ps1`" -Tray"

if ($Unregister) {
    Unregister-ScheduledTask -TaskName 'CleanOpt-Daily' -Confirm:$false -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName 'CleanOpt-Logon' -Confirm:$false -ErrorAction SilentlyContinue
    Write-Output 'CleanOpt tasks removed.'
    exit
}

# ---- Daily task (SYSTEM, hidden, no UI) ----
$dailyTrigger = New-ScheduledTaskTrigger -Daily -At $DailyTime
$dailyPrincipal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$dailySettings = New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
    -ExecutionTimeLimit (New-TimeSpan -Hours 1) -StartWhenAvailable
Register-ScheduledTask -TaskName 'CleanOpt-Daily' -Action $dailyAction -Trigger $dailyTrigger `
    -Principal $dailyPrincipal -Settings $dailySettings -Force | Out-Null
Write-Output "Registered CleanOpt-Daily @ $DailyTime (SYSTEM, hidden)."

# ---- Logon task (current user, hidden; GUI minimizes to tray) ----
$logonTrigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$logonPrincipal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Highest
$logonSettings = New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName 'CleanOpt-Logon' -Action $logonAction -Trigger $logonTrigger `
    -Principal $logonPrincipal -Settings $logonSettings -Force | Out-Null
Write-Output "Registered CleanOpt-Logon (user, hidden)."

Write-Output 'Done. The daily task runs silently with no popups.'
