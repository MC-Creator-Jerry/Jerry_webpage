@echo off
cd /d "%~dp0"
if not exist "useful_files.sed" (
  echo [ERROR] useful_files.sed not found.
  pause
  exit /b 1
)
iexpress /N /Q "useful_files.sed"
if exist "useful_files.exe" (
  echo.
  echo [OK] useful_files.exe generated in this folder.
  echo     Double-click useful_files.exe to self-extract.
) else (
  echo.
  echo [FAIL] Could not create useful_files.exe.
  echo        Make sure IExpress (Windows built-in) is available.
  pause
)
