﻿<#
.SYNOPSIS
    CleanOpt - 静默每日垃圾清理.
    清理路线 (按用户要求):
      检测到火绒  -> 走火绒方式 (尽量触发火绒后台静默清理任务; 若没有可用的静默清理则退回系统方式)
      未检测到火绒 -> 走系统原生方式 (原生静默清理)

    无论走哪条路, 都保持 100% 无窗口、无提示、无弹窗.

.DESCRIPTION
    原生安全清理只删"绝对安全"的临时/缓存目录:
      系统+用户 TEMP、Prefetch、缩略图缓存、Delivery Optimization 缓存、Edge/Chrome 缓存子目录.
    回收站默认不清空 (把 $EmptyRecycleBin 设为 $true 可启用).

    关于"火绒方式":
      火绒的清理主程序 sysclean.exe 是 GUI 程序, 没有任何静默命令行参数(已实测),
      因此本工具无法"无窗口"地直接驱动它.
      火绒真正静默的清理只能靠它自己的后台计划任务(在火绒『垃圾清理-定时清理』中开启后,
      由火绒服务在后台静默运行, 完全不弹窗). 所以这里的"火绒方式"实现为:
      探测到火绒时, 自动查找并触发它的静默清理计划任务; 找不到该任务时, 退回原生静默清理,
      保证无窗口也能把垃圾清干净.
#>

param(
    [switch]$PrivacyOnly,  # 仅执行隐私痕迹清理 (由主界面『隐私清理』按钮调用)
    [string]$CategoriesFile = ''  # 仅清理指定类别 (由主界面『扫描→选择→执行』调用)
)

$ErrorActionPreference = 'SilentlyContinue'
$logFile = Join-Path $env:LOCALAPPDATA 'CleanOpt\clean_daily.log'

function Write-Log {
    param([string]$Msg)
    try {
        $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        $line = "$ts  [clean_daily] $Msg"
        # 日志旋转: 超过 200KB 时仅保留末尾 500 行, 避免无限增长影响读/写性能
        if (Test-Path $logFile) {
            if ((Get-Item $logFile).Length -gt 200KB) {
                $keep = Get-Content -Path $logFile -Encoding UTF8 -Tail 500 -ErrorAction SilentlyContinue
                Set-Content -Path $logFile -Value $keep -Encoding UTF8
            }
        }
        Add-Content -Path $logFile -Value $line -Encoding UTF8
    } catch { }
}

# 审计日志 (P3·操作留痕): 记录每次清理动作, 供主界面『操作审计』查看
function Write-Audit {
    param([string]$Action, [string]$Detail = '')
    try {
        $af = Join-Path $env:LOCALAPPDATA 'CleanOpt\audit.log'
        $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        Add-Content -Path $af -Value "$ts`t$Action`t$Detail" -Encoding UTF8
    } catch { }
}

# ---- tunables ----
# 注: 清空回收站由 daily_run.ps1 根据 settings.json 的 dailyEmptyRecycle 统一处理,
#      本脚本只负责"绝对安全"的临时/缓存清理, 不碰回收站.

# ---- 火绒探测 (settings.json 配置路径 优先 + 常见安装位置) ----
$settingsFile = Join-Path $PSScriptRoot 'settings.json'
$settingsHuorong = ''
$settingsRestore = $true
$settingsKeepDays = 30
$settingsPrivacy = $false
if (Test-Path $settingsFile) {
    try {
        $j = Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($j.huorongPath) { $settingsHuorong = $j.huorongPath }
        if ($null -ne $j.restoreEnabled) { $settingsRestore = [bool]$j.restoreEnabled }
        if ($null -ne $j.restoreKeepDays) { $settingsKeepDays = [int]$j.restoreKeepDays }
        if ($null -ne $j.privacyClean) { $settingsPrivacy = [bool]$j.privacyClean }
    } catch { }
}
$script:privacyClean = $settingsPrivacy
$script:restoreEnabled = $settingsRestore
$script:restoreKeepDays = $settingsKeepDays

# 自定义清理规则 (P3): 读取用户自定义路径/通配符, 常规清理时一并处理
$script:customRules = @()
$customRulesFile = Join-Path $PSScriptRoot 'custom_rules.json'
if (Test-Path $customRulesFile) {
    try {
        $cr = Get-Content $customRulesFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($cr) { $script:customRules = @($cr) | Where-Object { $_.enabled -ne $false } }
    } catch { Write-Log "读取 custom_rules.json 失败" }
}

# 选择性清理: 若传入 CategoriesFile, 仅清理其中列出的类别 (键见 CleanOpt.ps1 的 Get-CleanScanCategories)
$script:limitCategories = $null
if ($CategoriesFile -and (Test-Path $CategoriesFile)) {
    try {
        $arr = Get-Content $CategoriesFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($arr) { $script:limitCategories = @($arr) }
        Write-Log "选择性清理模式: $(($script:limitCategories | Out-String).Trim())"
    } catch { Write-Log "读取 CategoriesFile 失败, 退回全量清理" }
}
$script:batchDir = $null
$script:manifest = @()
$script:failedMove = 0
$HuorongCandidates = @()
if ($settingsHuorong) { $HuorongCandidates += $settingsHuorong }
$HuorongCandidates += @(
    'D:\软件\HuorongSafety\Huorong\Sysdiag\bin\sysclean.exe',
    "$env:ProgramFiles\Huorong\Sysdiag\bin\sysclean.exe",
    "${env:ProgramFiles(x86)}\Huorong\Sysdiag\bin\sysclean.exe",
    'C:\Program Files\Huorong\Sysdiag\bin\sysclean.exe',
    'C:\Program Files (x86)\Huorong\Sysdiag\bin\sysclean.exe'
)
$huorongExe = $null
foreach ($c in $HuorongCandidates) {
    if ($c -and (Test-Path $c)) { $huorongExe = $c; break }
}

# 探测火绒的"静默清理计划任务"(用户开启『定时清理』后才存在)
function Find-HuorongCleanTask {
    try {
        $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue |
            Where-Object { ($_.TaskName -match '火绒|Huorong|SysDiag') -or ($_.TaskPath -match 'Huorong|SysDiag') }
        foreach ($t in $tasks) {
            try {
                # 直接读取首次枚举已返回的对象属性, 避免对每个任务再次 Get-ScheduledTask (N+1)
                $act = $t.Actions
                $txt = ($act | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' '
                if ($txt -match 'sysclean|clean') { return $t }
            } catch { }
        }
    } catch { }
    return $null
}

# ---- 原生静默清理 ----
function In-Limit($key) {
    return (-not $script:limitCategories -or $script:limitCategories -contains $key)
}

function Invoke-NativeCleanup {
    Write-Log "--- 原生静默清理开始 ---"
    if (In-Limit 'temp') {
        # 1) 用户 + 系统 TEMP
        Remove-Safe -Path $env:TEMP -Label "user TEMP ($env:TEMP)"
        Remove-Safe -Path "$env:SystemRoot\Temp" -Label "system TEMP"
    }
    if (In-Limit 'prefetch') {
        # 2) Prefetch
        Remove-Safe -Path "$env:SystemRoot\Prefetch" -Label "Prefetch"
    }
    if (In-Limit 'thumbcache') {
        # 3) 缩略图缓存
        Remove-Safe -Path "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_*.db" -Label "thumbnail cache"
    }
    if (In-Limit 'deliveryopt') {
        # 4) Delivery Optimization 缓存
        Remove-Safe -Path "$env:SystemRoot\SoftwareDistribution\DeliveryOptimizationCache" -Label "Delivery Optimization cache"
    }
    if (In-Limit 'browsercache') {
        # 5) 浏览器缓存 (Edge + Chrome 的缓存子目录, 不动 profile/密码)
        $browserRoots = @(
            "$env:LOCALAPPDATA\Microsoft\Edge\User Data",
            "$env:LOCALAPPDATA\Google\Chrome\User Data"
        )
        $cacheFolders = @('Cache', 'Cache2', 'Code Cache', 'GPUCache', 'Media Cache', 'Service Worker\CacheStorage')
        foreach ($root in $browserRoots) {
            if (Test-Path $root) {
                Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                    $profile = $_.FullName
                    foreach ($cf in $cacheFolders) {
                        Remove-Safe -Path (Join-Path $profile $cf) -Label "browser cache ($profile\$cf)"
                    }
                }
            }
        }
    }
    if (In-Limit 'dism') {
        # 6) Windows Update 残留 (标准安全项) —— DISM 较重, 限频为每周最多一次, 省时且避免在每次清理都跑
        $dismStamp = Join-Path $env:LOCALAPPDATA 'CleanOpt\dism.stamp'
        $runDism = $true
        if (Test-Path $dismStamp) {
            try {
                $last = [datetime]::Parse((Get-Content $dismStamp -Encoding UTF8 -Raw -ErrorAction SilentlyContinue).Trim())
                if ((Get-Date - $last).TotalDays -lt 7) { $runDism = $false }
            } catch { }
        }
        if ($runDism) {
            try {
                Write-Log "DISM StartComponentCleanup ..."
                Start-Process -FilePath 'Dism.exe' -ArgumentList '/Online /Cleanup-Image /StartComponentCleanup' -WindowStyle Hidden -Wait
                Write-Log "DISM done"
                (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | Set-Content -Path $dismStamp -Encoding UTF8
            } catch {
                Write-Log ("ERROR DISM: " + $_.Exception.Message)
            }
        } else {
            Write-Log "DISM 7 天内已运行, 本次跳过 (限频)"
        }
    }
    Write-Log "--- 原生静默清理结束 ---"
}

# 自定义清理规则处理 (P3): 按用户配置的路径/通配符删除, 同样走隔离(可还原)
function Invoke-CustomRulesCleanup {
    if (-not (In-Limit 'custom')) { return }
    if (-not $script:customRules -or @($script:customRules).Count -eq 0) { return }
    Write-Log "--- 自定义清理规则开始 ($(@($script:customRules).Count) 条) ---"
    foreach ($rule in $script:customRules) {
        $path = $rule.path
        if (-not $path) { continue }
        $recurse = if ($null -ne $rule.recurse) { [bool]$rule.recurse } else { $true }
        $pat = if ($rule.pattern) { $rule.pattern } else { '*' }
        $label = "自定义规则: $path"
        try {
            $targets = @(Get-ChildItem -LiteralPath $path -Include $pat -Recurse:$recurse -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer })
            if ($targets.Count -eq 0 -and (Test-Path -LiteralPath $path)) {
                $targets = @(Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer })
            }
            foreach ($it in $targets) { Remove-Safe -Path $it.FullName -Label $label }
            Write-Log "自定义规则已处理: $path ($(if ($recurse) { '含子目录' } else { '仅当前目录' }), 模式=$pat)"
        } catch {
            Write-Log ("ERROR 自定义规则 $path : " + $_.Exception.Message)
        }
    }
    Write-Log "--- 自定义清理规则结束 ---"
}

function Remove-Safe {
    param([string]$Path, [string]$Label)
    if (-not $Path -or -not (Test-Path $Path)) { return }
    try {
        # 只取文件(非目录): 避免移动非空目录失败, 空目录留在原处无害
        $items = @(Get-ChildItem -Path $Path -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer })
        $before = $items.Count
        if ($script:restoreEnabled -and $script:batchDir) {
            # 还原模式: 删除前把文件移入隔离区(batchDir)并记清单, 可一键还原
            $base = Split-Path $Path.TrimEnd('\') -Parent
            $moved = 0
            foreach ($it in $items) {
                try {
                    $rel = $it.FullName.Substring($base.TrimEnd('\').Length).TrimStart('\')
                    $dest = Join-Path $script:batchDir $rel
                    $destParent = Split-Path $dest -Parent
                    if (-not (Test-Path $destParent)) { New-Item -ItemType Directory -Path $destParent -Force | Out-Null }
                    Move-Item -Path $it.FullName -Destination $dest -Force -ErrorAction Stop
                    $script:manifest += [PSCustomObject]@{ orig = $it.FullName; rel = $rel; size = [long]$it.Length; kind = 'file' }
                    $moved++
                } catch {
                    # 被占用/锁定 -> 直接删除(无法隔离, 记录失败数)
                    try { $it.FullName | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue } catch { }
                    $script:failedMove++
                }
            }
            Write-Log "cleaned(可还原) $Label ($moved/$before 文件已隔离, 失败 $($script:failedMove))"
        } else {
            # 非还原模式: 直接删除
            $items | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
            Write-Log "cleaned $Label ($before items scanned)"
        }
    } catch {
        Write-Log ("ERROR cleaning $Label : " + $_.Exception.Message)
    }
}

# ---- 隔离区过期清理: 删除超过保留天数的批次 ----
function Invoke-PurgeRestore {
    try {
        $root = Join-Path $env:LOCALAPPDATA 'CleanOpt\Restore'
        if (-not (Test-Path $root)) { return }
        $cutoff = (Get-Date).AddDays(-$script:restoreKeepDays)
        Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $dt = [datetime]::ParseExact($_.Name, 'yyyyMMdd-HHmmss', $null)
                if ($dt -lt $cutoff) {
                    $_ | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
                    Write-Log "还原区过期清理: $($_.Name)"
                }
            } catch { }
        }
    } catch { }
}

# ---- 隐私痕迹清理 (P2): 最近使用/跳转列表/运行记录 ----
# 只清"使用痕迹", 不碰用户文件; 还原模式开启时同样先隔离, 保证可还原.
function Invoke-PrivacyCleanup {
    Write-Log "--- 隐私痕迹清理开始 ---"
    $done = 0

    # 文件类痕迹: 最近使用 .lnk + 跳转列表(Automatic/Custom Destinations)
    $privacyPaths = @(
        (Join-Path $env:APPDATA 'Microsoft\Windows\Recent'),
        (Join-Path $env:APPDATA 'Microsoft\Windows\Recent\AutomaticDestinations'),
        (Join-Path $env:APPDATA 'Microsoft\Windows\Recent\CustomDestinations')
    )
    foreach ($p in $privacyPaths) {
        if (-not $p -or -not (Test-Path $p)) { continue }
        $dirInfo = Get-Item -LiteralPath $p -ErrorAction SilentlyContinue
        $isDir = $dirInfo -and $dirInfo.PSIsContainer
        try {
            if ($isDir) {
                $items = @(Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer })
            } else {
                $items = @(Get-Item -LiteralPath $p -ErrorAction SilentlyContinue)
            }
            foreach ($it in $items) {
                $moved = $false
                if ($script:restoreEnabled -and $script:batchDir) {
                    try {
                        $rel = 'privacy\' + (Split-Path $it.FullName -Parent).TrimEnd('\').Split('\')[-1] + '\' + $it.Name
                        $dest = Join-Path $script:batchDir $rel
                        $destParent = Split-Path $dest -Parent
                        if (-not (Test-Path $destParent)) { New-Item -ItemType Directory -Path $destParent -Force | Out-Null }
                        Move-Item -LiteralPath $it.FullName -Destination $dest -Force -ErrorAction Stop
                        $script:manifest += [PSCustomObject]@{ orig = $it.FullName; rel = $rel; size = [long]$it.Length; kind = 'file' }
                        $moved = $true
                    } catch {
                        try { Remove-Item -LiteralPath $it.FullName -Force -ErrorAction SilentlyContinue } catch { }
                    }
                } else {
                    try { Remove-Item -LiteralPath $it.FullName -Force -ErrorAction SilentlyContinue } catch { }
                }
                if ($moved -or -not (Test-Path -LiteralPath $it.FullName)) { $done++ }
            }
        } catch {
            Write-Log ("ERROR privacy path $p : " + $_.Exception.Message)
        }
    }

    # 注册表类痕迹: 运行记录(RunMRU) / 最近文档(RecentDocs) / 地址栏输入记录(TypedPaths)
    $privacyKeys = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\TypedPaths'
    )
    foreach ($k in $privacyKeys) {
        if (-not (Test-Path $k)) { continue }
        try {
            # RecentDocs 有子项, 一并移除; 其余键只清值
            Get-ChildItem -Path $k -ErrorAction SilentlyContinue | ForEach-Object {
                try { Remove-Item -Path $_.PSPath -Recurse -Force -ErrorAction SilentlyContinue; $done++ } catch { }
            }
            Get-Item -Path $k -ErrorAction SilentlyContinue | ForEach-Object {
                $_.GetValueNames() | ForEach-Object {
                    try { Remove-ItemProperty -Path $k -Name $_ -Force -ErrorAction Stop; $done++ } catch { }
                }
            }
            Write-Log "privacy registry cleaned: $k"
        } catch {
            Write-Log ("ERROR privacy reg $k : " + $_.Exception.Message)
        }
    }

    Write-Log "--- 隐私痕迹清理结束 (共处理 $done 项) ---"
    Write-Log "PRIVACY_DONE|$done"
}

# ============ 清理路线分派 ============
Write-Log "=== daily clean start (privacyOnly=$PrivacyOnly) ==="

# 还原模式开启时, 先过期清理一次隔离区
Invoke-PurgeRestore

# 还原模式: 建立隔离批次目录 (隐私清理同样走隔离, 保证可还原)
if ($script:restoreEnabled) {
    $restoreRoot = Join-Path $env:LOCALAPPDATA 'CleanOpt\Restore'
    if (-not (Test-Path $restoreRoot)) { New-Item -ItemType Directory -Path $restoreRoot -Force | Out-Null }
    $runId = Get-Date -Format 'yyyyMMdd-HHmmss'
    $script:batchDir = Join-Path $restoreRoot $runId
    New-Item -ItemType Directory -Path $script:batchDir -Force | Out-Null
    $script:manifest = @()
    $script:failedMove = 0
    Write-Log "还原模式开启: 清理结果将隔离至 $($script:batchDir) (可还原)"
}

if ($PrivacyOnly) {
    # 仅隐私清理: 隔离目录已就绪, 直接执行
    Invoke-PrivacyCleanup
    if ($script:batchDir -and (Test-Path $script:batchDir)) {
        $cnt = $script:manifest.Count
        $byts = 0
        if ($cnt -gt 0) { $byts = ($script:manifest | Measure-Object -Property size -Sum).Sum }
        $obj = [PSCustomObject]@{
            cleanedAt  = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            runId      = if ($runId) { $runId } else { 'manual' }
            files      = $script:manifest
            totalBytes = [long]$byts
            failedMove = $script:failedMove
        }
        try { $obj | ConvertTo-Json -Depth 3 | Set-Content -Path (Join-Path $script:batchDir 'manifest.json') -Encoding UTF8 } catch { }
        Write-Log "RESTORE_BATCH|$($obj.runId)|$cnt|$byts"
    }
    Write-Log "=== daily clean end ==="
    exit 0
}

if ($script:restoreEnabled) {
    # 还原模式: 一律走原生隔离清理, 确保"清理结果可还原" (跳过火绒, 因火绒删除不可控)
    Invoke-NativeCleanup
    Invoke-CustomRulesCleanup
    if ($script:privacyClean -and -not $script:limitCategories) { Invoke-PrivacyCleanup }
} else {
    # 原逻辑: 火绒优先, 回退原生
    if ($huorongExe) {
        Write-Log "检测到火绒: $huorongExe -> 走火绒方式"
        $hrTask = Find-HuorongCleanTask
        if ($hrTask) {
            try {
                $tn = "$($hrTask.TaskPath)$($hrTask.TaskName)"
                Write-Log "触发火绒后台静默清理任务: $tn"
                Start-Process -FilePath 'schtasks.exe' -ArgumentList "/run /tn `"$tn`"" -WindowStyle Hidden -Wait
                Write-Log "火绒后台清理任务已触发 (火绒服务在后台静默执行, 无窗口)"
            } catch {
                Write-Log ("触发火绒任务失败, 退回系统方式: " + $_.Exception.Message)
                Invoke-NativeCleanup
            }
        } else {
            Write-Log "未找到火绒的静默清理计划任务(火绒无命令行静默清理). 退回系统原生方式."
            Write-Log "提示: 在火绒『垃圾清理 - 定时清理』中开启, 即可让火绒自己在后台静默清理, 届时本工具会改走火绒方式."
            Invoke-NativeCleanup
        }
    } else {
        Write-Log "未检测到火绒 -> 走系统原生方式"
        Invoke-NativeCleanup
    }
    Invoke-CustomRulesCleanup
    if ($script:privacyClean -and -not $script:limitCategories) { Invoke-PrivacyCleanup }
}

# 写出还原批次清单 (仅还原模式有 batchDir)
if ($script:batchDir -and (Test-Path $script:batchDir)) {
    $cnt = $script:manifest.Count
    $byts = 0
    if ($cnt -gt 0) { $byts = ($script:manifest | Measure-Object -Property size -Sum).Sum }
    $obj = [PSCustomObject]@{
        cleanedAt  = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        runId      = if ($runId) { $runId } else { 'manual' }
        files      = $script:manifest
        totalBytes = [long]$byts
        failedMove = $script:failedMove
    }
    # 注意: ConvertTo-Json 在 Windows PowerShell 5.1 不支持 -Encoding, 加上会抛错导致还原清单静默不写入
    try { $obj | ConvertTo-Json -Depth 3 | Set-Content -Path (Join-Path $script:batchDir 'manifest.json') -Encoding UTF8 } catch { }
    Write-Log "RESTORE_BATCH|$($obj.runId)|$cnt|$byts"
    Write-Audit "垃圾清理" "模式=$(if ($script:limitCategories) { '选择性' } else { '全量' }); 批次=$($obj.runId); 隔离文件=$cnt; 体积=$([math]::Round($byts/1MB,1))MB"
    if ($script:failedMove -gt 0) { Write-Log "注意: $($script:failedMove) 个文件被占用/锁定, 已直接删除(无法隔离)" }
}

if (-not $script:batchDir) { Write-Audit "垃圾清理" "模式=$(if ($script:limitCategories) { '选择性' } else { '全量' }); 非隔离模式(直接删除)" }
Write-Log "=== daily clean end ==="
exit 0
