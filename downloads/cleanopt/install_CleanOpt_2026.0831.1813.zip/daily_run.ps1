﻿<#
.SYNOPSIS
    CleanOpt - Daily runner invoked by the scheduled task.
    Runs the silent junk cleaner, then the memory optimizer, then (optionally)
    empties the Recycle Bin. Fully unattended.

.NOTES
    Launched by Task Scheduler with -WindowStyle Hidden, so it produces no window.
    The "empty Recycle Bin" step is controlled by settings.json -> dailyEmptyRecycle
    (default: true).
#>

$ErrorActionPreference = 'SilentlyContinue'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Definition

# 1) Junk cleanup
& "$dir\clean_daily.ps1"

# 2) Memory optimize
& "$dir\optimize_mem.ps1"

# 3) Empty Recycle Bin (optional, from settings.json)
$settingsFile = Join-Path $dir 'settings.json'
$emptyRecycle = $true
if (Test-Path $settingsFile) {
    try {
        $j = Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -ne $j.dailyEmptyRecycle) { $emptyRecycle = [bool]$j.dailyEmptyRecycle }
    } catch { }
}
if ($emptyRecycle) {
    try {
        Clear-RecycleBin -Force -ErrorAction Stop
    } catch {
        Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
            $bin = Join-Path $_.Root '$Recycle.Bin'
            if (Test-Path $bin) { Get-ChildItem $bin -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue }
        }
    }
}

exit 0
