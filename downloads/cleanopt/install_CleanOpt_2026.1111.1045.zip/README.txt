﻿CleanOpt · 系统清理与内存优化工具 使用说明
========================================

【简介】
CleanOpt 是一套纯 PowerShell 实现的 Windows 清理 / 内存优化工具。
默认以管理员权限运行，后台静默清理垃圾 + 优化内存，常驻系统托盘，
全程不弹任何窗口。

【快速安装】
1. 把本压缩包解压到任意目录（例如 D:\Tools\useful_files）。
2. 双击根目录的 install.bat（建议右键“以管理员身份运行”）。
   安装脚本会：
     - 把工具复制到 C:\Program Files\CleanOpt
     - 在桌面创建“CleanOpt”快捷方式
     - 注册每日静默清理任务（03:00）与开机自启（登录后后台运行）
3. 双击桌面“CleanOpt”即可运行（默认最小化到托盘）。
   右键托盘图标可：立即优化内存 / 清空回收站 / 打开软件 / 设置 /
   运行日志 / 导出诊断 / 关于 / 退出。

【不安装直接运行】
- 直接双击 CleanOpt\CleanOpt.ps1（首次会请求管理员权限），同样可用。
- CleanOpt\CleanOpt-Tray.cmd 也可一键以托盘模式启动（已提权）。
- CleanOpt\CleanOpt.lnk 是托盘模式快捷方式，可固定到任务栏 / 桌面。

【核心功能】
- 内存优化：优先调用 PCL（PCL.exe --memory）静默优化；未检测到则使用
  原生四步强力引擎（清空工作集 / 刷新修改页 / 清空备用列表），达到
  PCL / Mem Reduct / RAMMap 同级别。
- 垃圾清理：检测到火绒则尽量走火绒后台静默清理；否则系统原生清理
  （TEMP / Prefetch / 缩略图 / Delivery Optimization / 浏览器缓存，
  安全、不碰用户数据）。
- 每分钟监控：内存紧张 / 磁盘不足 / 空闲时才自动优化。
- 游戏 / 全屏免打扰、全局热键 Ctrl+Alt+O、托盘图标随内存压力变色。
- 单实例：重复启动只唤醒已存在的窗口，不重复运行。
- 清理结果可还原（安全）：清理前文件先移入隔离区 %LOCALAPPDATA%\CleanOpt\Restore\
  并按批次记录清单，主窗口“还原清理”可勾选一键还原；超过保留天数（默认 30 天）
  自动彻底删除。锁定/占用文件会直接删除并在日志中记录。
- 启动项管理：汇总注册表 Run（当前用户 + 本机 32/64 位）、启动文件夹（当前用户 +
  所有用户）、登录触发的计划任务（排除系统自带）。可勾选禁用 / 启用；
  禁用前自动保存原值，随时可原样还原；启动文件夹项移到
  %LOCALAPPDATA%\CleanOpt\DisabledStartup\ 保存。计划任务类需管理员权限。
- 隐私痕迹清理：最近使用 .lnk、跳转列表（Automatic / Custom Destinations）、
  运行记录（RunMRU）、最近文档（RecentDocs）、地址栏输入记录（TypedPaths）。
  可手动一键清理（“隐私清理”按钮），也可设为随常规清理自动执行
  （设置里开关，默认关）。还原模式开启时同样先隔离，可还原。
- 常用工具：结束进程（带确认）、网络修复（刷 DNS / 重置网络栈）、清空剪贴板、锁屏。
- 设置可配置阈值 / 间隔 / 强度 / 延迟 / 免打扰进程 / 回收站 / 隔离区 / 隐私清理等。
- 自动更新（下一代起生效）：每周静默检查更新源，发现新版本后台下载应用并自重启；
  另有“内存大户”视图看谁在吃内存、“检查更新”对话框可手动更新。
- 界面：内存占用仪表、操作分组、按钮悬停高亮与工具提示、自适应缩放（高 DPI 清晰）、
  主面板滚动条（窗口缩小自动出现）。

【卸载】
以管理员运行：
  PowerShell -File "C:\Program Files\CleanOpt\install.ps1" -Uninstall
（也可重新运行安装包内的 安装.bat 后手动删除目录）。

【文件清单】
  CleanOpt\CleanOpt.ps1        主程序（窗口 + 后台监控）
  CleanOpt\optimize_mem.ps1    内存优化引擎
  CleanOpt\clean_daily.ps1     每日垃圾清理
  CleanOpt\daily_run.ps1       每日任务入口（清理→优化→回收站）
  CleanOpt\Register-Tasks.ps1  注册 / 注销计划任务（需管理员）
  CleanOpt\CleanOpt-Tray.cmd   托盘模式快速启动（已提权）
  CleanOpt\CleanOpt.lnk        托盘模式快捷方式
  CleanOpt\update.ps1          自动更新执行器（下载/解压/应用/自重启，无窗口）
  CleanOpt\make_release.ps1    发布助手：打包 CleanOpt.zip + version.json
  CleanOpt\lint.ps1            静态质量门禁（只读自检：语法 / BOM / 换行 / 重复函数 / 未定义调用 / 版本号）
  install.ps1                  安装 / 卸载脚本
  install.bat                  以管理员运行安装脚本的入口

【生成自解压 exe（install_CleanOpt_<版本>.exe）】
压缩包与安装程序统一命名为：install_[软件名]_[版本]（本包即 install_CleanOpt_2026.1111.1045.zip / install_CleanOpt_2026.1111.1045.exe）。版本号采用构建日期时间格式 年.月日.时分（月日/时分补零，如 2026.0905.1330）。
新版本生成时会自动删除旧的 install_CleanOpt_*.zip / *.exe，只保留当前版本。
本包已附带 IExpress 指令文件 useful_files.sed 与一键生成器 build_exe.bat / build_exe.ps1：
1. 把压缩包解压到任意目录（会得到 useful_files\ 文件夹 + useful_files.sed + build_exe.bat + build_exe.ps1）。
2. 双击 build_exe.bat（无需管理员）。
3. 同目录下即生成 install_CleanOpt_2026.1111.1045.exe 自解压包（版本号自动取自 CleanOpt.ps1 的 $AppVersion）；双击它即可解压出全部文件。
   注意：build_exe.bat 依赖 Windows 自带的 IExpress，仅在你自己的电脑上可用，
   在受限/沙箱环境里会被拦截（属正常）。

【本次版本 (v2026.1111.1045 全量代码优化) 更新点】
  - 垃圾扫描提速：同一目录由「算大小 + 算数量」两次递归改为一次枚举同时统计；
    本机实测 1450ms -> 927ms（约快 36%），各类别体积统计结果完全一致。
  - 修复缩略图缓存数量恒为 0：-Include 未配合 -Recurse 时会被 PowerShell 忽略；
    改为按文件名过滤后，本机正确统计到 15 个 thumbcache_*.db。
  - 修复删除自定义清理规则时可能连带删掉内容相同的其他规则：改为按索引删除。
  - 去重与规范化：移除还原窗口内重复的 Format-Bytes；两个同名 Refresh-List
    改为语义化命名；启动项 / 隔离批次列表改用 List 收集，避免数组反复重建。
  - 新增 lint.ps1 静态质量门禁；修复 Register-Tasks.ps1 提权时丢失 -Unregister；
    全部辅助脚本统一 UTF-8 BOM + CRLF；交付包与开发目录重新对齐（不再有分叉）。
  - 关于框变更日志里的 $I / $R / $Recycle.Bin 补上转义，避免被当作变量展开后丢字。

【备注】
所有后台任务均 100% 无窗口、无弹窗、无提示，
仅写日志到 %LOCALAPPDATA%\CleanOpt\*.log。

【自动更新（下一代起生效）】
CleanOpt 从下一版开始支持自动更新，机制如下：
1. 在“设置”里填写“更新源”——一个 version.json 的地址（http(s) URL 或本地文件夹）。
2. version.json 格式：{ "version": "1.10", "url": "<CleanOpt.zip 地址>",
   "notes": "更新说明", "date": "2026-08-30" }。
3. 监控循环每周静默读取更新源：若版本号更高，后台下载并应用新文件（保留你的
   settings.json / apps.json），然后自动重启到新版本，全程无窗口。
4. 也可在主窗口或托盘右键“检查更新”手动查看/更新。

如何发布“下一代”新版本（在你自己的电脑上）：
  PowerShell -File "CleanOpt\make_release.ps1" -Version 1.10 -Url "https://你的地址/CleanOpt.zip" -Notes "本次更新内容"
  它会生成 CleanOpt.zip 和 version.json；把这两个文件放到一个可访问地址（或本地
  共享文件夹），并把 version.json 的 URL 填到 CleanOpt“设置→更新源”即可。
  若为本地更新源，-Url 可留空，把整个文件夹路径填到“更新源”即可。

本次版本 (v2026.0905.1727 修复无法启动) 更新点：
  - 【修复】修「无法启动」：上一版(v2026.0905.1330)关于框变更日志里用了弯引号（“ ”），
    PowerShell 解析整个脚本时直接报错、无法运行；已统一改为转义直引号（`"），脚本恢复正常启动。
  - 在 v2026.0905.1330 的基础上继续生效：缓存清理页 / 清理历史记录页 全部功能。

上一版 (v2026.0905.1330 清理缓存 + 清理历史记录) 更新点：
  - 【新增】缓存清理页：自动检测微信/QQ/TIM/钉钉/企业微信/飞书/Telegram/Chrome/Edge 等已装软件，
    按「软件·账号·类型」列出缓存并附估算大小，可多选勾选后一键清理（缓存可再生，直接删安全）。
  - 【新增】清理历史记录页：选软件 → 多选账号清空聊天记录；因微信/QQ 等聊天库加密(读不到群聊名)，
    以【账号】为最小可选单元，删除前默认备份到隔离区(可还原)。
  - 【新增】历史清理提供「直接删除(立即释放空间, 不可还原)」选项，默认走安全备份；
    钉钉/企业微信/飞书本地加密，提示用软件内「清空聊天记录」。
  - 上一版 (v2026.0903.1918 回收站清空修复)：仅清当前用户 SID 回收站 + 原生 rd /s /q 快速可靠。
  - 上上版 (v2026.0901.1934 显示与工作方法优化)：导航分组 + 首页运行概况卡片 + New-Card 统一视觉
    + 低盘预估算(<30MB 跳过) + 更新提示「稍后提醒」+ 清理结束写 stat.json。
  - 上上上版 (v2026.0831.1813)：版本号格式改为 3段(年.月日.时分) / Get-VersionKey 改 datetime Ticks 比较。
  - v1.14：启动项管理 + 隐私痕迹清理，并修复 ConvertTo-Json -Encoding 静默失败问题。
  - v1.13：清理结果可还原——隔离区 + 批次清单 + 一键还原 + 自动过期清理。
  - 历史优化：托盘图标 GDI 句柄泄漏修复、监控 WMI 合并、日志 200KB 旋转、
    PCL 路径缓存、低盘 WMI 3 分钟缓存、清理枚举合并、引擎 DLL 缓存、
    自动优化 10 分钟冷却、低盘清理异步、空闲 32 位 tick 差、DISM 周限频。
