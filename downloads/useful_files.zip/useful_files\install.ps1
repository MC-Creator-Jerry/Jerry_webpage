<#
.SYNOPSIS
    CleanOpt 安装 / 卸载脚本 (由 安装.bat 以管理员身份调用).

.DESCRIPTION
    安装: 复制工具到 C:\Program Files\CleanOpt, 在桌面创建托盘快捷方式,
          并注册计划任务 (每日静默清理 + 登录自启).
    卸载: 删除计划任务, 删除桌面快捷方式, 删除安装目录.
#>

[CmdletBinding()]
param(
    [string]$InstallDir = "$env:ProgramFiles\CleanOpt",
    [switch]$Uninstall
)

$ErrorActionPreference = 'SilentlyContinue'

function Test-Admin {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
}

# 自动提权
if (-not (Test-Admin)) {
    $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    if ($Uninstall) { $arg += ' -Uninstall' }
    Start-Process -FilePath (Get-Process -Id $pid).Path -Verb RunAs -ArgumentList $arg
    exit
}

$src = Join-Path $PSScriptRoot 'CleanOpt'

if ($Uninstall) {
    try { Unregister-ScheduledTask -TaskName 'CleanOpt-Daily' -Confirm:$false -ErrorAction SilentlyContinue } catch { }
    try { Unregister-ScheduledTask -TaskName 'CleanOpt-Logon' -Confirm:$false -ErrorAction SilentlyContinue } catch { }
    $desktop = [Environment]::GetFolderPath('Desktop')
    $lnk = Join-Path $desktop 'CleanOpt.lnk'
    if (Test-Path $lnk) { Remove-Item $lnk -Force -ErrorAction SilentlyContinue }
    if (Test-Path $InstallDir) { Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue }
    Write-Output 'CleanOpt 已卸载 (任务/快捷方式/目录均已移除)。'
    Read-Host '按回车键退出'
    exit
}

# ---- 安装 ----
if (-not (Test-Path $src)) {
    Write-Error '未找到 CleanOpt 源文件夹 (CleanOpt)。请确认 install.ps1 与 CleanOpt 在同一目录。'
    Read-Host '按回车键退出'
    exit
}

if (-not (Test-Path $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
Copy-Item -Path (Join-Path $src '*') -Destination $InstallDir -Recurse -Force

# 桌面快捷方式 (托盘模式: 启动即最小化到托盘; CleanOpt 自身会按需提权)
try {
    $desktop = [Environment]::GetFolderPath('Desktop')
    $lnkPath = Join-Path $desktop 'CleanOpt.lnk'
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($lnkPath)
    $sc.TargetPath = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
    $sc.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$InstallDir\CleanOpt.ps1`" -Tray"
    $sc.WorkingDirectory = $InstallDir
    $sc.IconLocation = 'C:\Windows\System32\cleanmgr.exe'
    $sc.Description = 'CleanOpt · 清理优化 (托盘)'
    $sc.Save()
    Write-Output '桌面快捷方式已创建: CleanOpt.lnk'
} catch {
    Write-Output ('创建桌面快捷方式失败: ' + $_.Exception.Message)
}

# 注册计划任务 (Register-Tasks.ps1 会自行提权)
try {
    & "$InstallDir\Register-Tasks.ps1" -DailyTime '03:00'
} catch {
    Write-Output ('注册计划任务失败: ' + $_.Exception.Message)
}

Write-Output ''
Write-Output 'CleanOpt 安装完成。'
Write-Output ('安装位置: ' + $InstallDir)
Write-Output '双击桌面“CleanOpt”即以托盘模式运行; 首次会请求管理员权限。'
Read-Host '按回车键退出'
