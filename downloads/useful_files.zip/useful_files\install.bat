@echo off
chcp 65001 >nul
PowerShell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'PowerShell.exe' -Verb RunAs -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File \"%~dp0install.ps1\"'"
