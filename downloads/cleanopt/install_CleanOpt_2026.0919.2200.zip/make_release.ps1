﻿<#
.SYNOPSIS
    CleanOpt release builder.
    Packages the CleanOpt folder into CleanOpt.zip (with a top-level CleanOpt\ dir so
    the updater can extract it) and writes version.json next to it. Host both files on
    a reachable URL (or a local shared folder) and point CleanOpt's "update source" at
    the version.json URL.

.PARAMETER Version
    New version number, e.g. 2026.8.31.18.07（日期时间格式）。留空则自动读取 CleanOpt.ps1 的 $script:AppVersion。
.PARAMETER Url
    Public URL of the CleanOpt.zip asset. Leave empty for a local-folder update source.
.PARAMETER Notes
    Short changelog shown in the "check update" dialog.
#>

[CmdletBinding()]
param(
    [string]$Version = '',
    [string]$Url = '',
    [string]$Notes = ''
)

$base = Split-Path $PSCommandPath -Parent
$src = Join-Path $base 'CleanOpt'
if (-not (Test-Path $src)) { Write-Error 'CleanOpt folder not found next to make_release.ps1'; exit 1 }

# 未显式传 -Version 时，自动从 CleanOpt.ps1 读取 $script:AppVersion（日期格式 年.月.日.时.分）
if (-not $Version) {
    $main = Join-Path $src 'CleanOpt.ps1'
    if (Test-Path $main) {
        $m = (Get-Content $main -Raw) -match "\`$script:AppVersion\s*=\s*'([^']+)'"
        if ($m) { $Version = $Matches[1] }
    }
    if (-not $Version) { Write-Error '无法从 CleanOpt.ps1 读取 AppVersion，请显式传 -Version'; exit 1 }
}

$zip = Join-Path $base 'CleanOpt.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path $src -DestinationPath $zip -Force

$obj = [PSCustomObject]@{
    version = $Version
    url     = $Url
    notes   = $Notes
    date    = (Get-Date -Format 'yyyy-MM-dd')
}
$obj | ConvertTo-Json | Set-Content -Path (Join-Path $base 'version.json') -Encoding UTF8

Write-Output "Release $Version built:"
Write-Output "  $zip"
Write-Output ("  " + (Join-Path $base 'version.json'))
if ($Url) { Write-Output "  Set update source to the version.json URL; its 'url' already points at the zip." }
else { Write-Output "  Local update source: point CleanOpt at this folder (version.json + CleanOpt.zip). Release new generations by re-running with a higher -Version." }
