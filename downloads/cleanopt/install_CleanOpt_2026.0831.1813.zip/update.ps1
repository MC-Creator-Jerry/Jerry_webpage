<#
.SYNOPSIS
    CleanOpt auto-updater (silent, no window).
    Reads version.json from a local folder or an http(s) URL, compares with the
    running version, and if a newer one exists: downloads the asset zip, extracts it,
    copies the new files over the install dir (preserving settings.json / apps.json),
    waits for the old instance to exit, then relaunches CleanOpt -Tray.

.PARAMETER CurrentVersion
    The running CleanOpt version (e.g. 1.9).
.PARAMETER UpdateUrl
    Either a local folder that contains version.json (+ CleanOpt.zip), a direct path
    to version.json, or an http(s) URL to version.json.
.PARAMETER InstallDir
    The CleanOpt install folder (defaults to this script's own directory).
.PARAMETER Restart
    If set, relaunch CleanOpt -Tray after applying.
.PARAMETER OldPid
    PID of the running CleanOpt instance; updater waits for it to exit before relaunch
    so the new instance can take over the single-instance mutex cleanly.
#>

param(
    [string]$CurrentVersion = '0.0',
    [string]$UpdateUrl = '',
    [string]$InstallDir = '',
    [switch]$Restart,
    [int]$OldPid = 0
)

$ErrorActionPreference = 'Stop'

if (-not $InstallDir) { $InstallDir = Split-Path $PSCommandPath -Parent }
$logFile = Join-Path $env:LOCALAPPDATA 'CleanOpt\update.log'
function Write-U { param([string]$m) try { $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'; Add-Content -Path $logFile -Value "$ts [update] $m" -Encoding UTF8 } catch { } }

function Get-VersionInfo {
    param([string]$Url)
    if ($Url -match '^https?://') {
        return Invoke-RestMethod -Uri $Url -UseBasicParsing -ErrorAction Stop
    }
    if (Test-Path $Url) {
        $p = Get-Item $Url
        if ($p.PSIsContainer) { $Url = Join-Path $Url 'version.json' }
        if (Test-Path $Url) { return Get-Content $Url -Raw -Encoding UTF8 | ConvertFrom-Json }
    }
    return $null
}

function Resolve-Asset {
    param([string]$AssetUrl, [string]$BaseFolder, [string]$BaseUrl)
    if ($AssetUrl -match '^https?://') { return $AssetUrl }
    if ($AssetUrl -and (Test-Path $AssetUrl)) {
        if ((Get-Item $AssetUrl).PSIsContainer) { return Join-Path $AssetUrl 'CleanOpt.zip' }
        return $AssetUrl
    }
    if ($BaseFolder -and (Test-Path (Join-Path $BaseFolder $AssetUrl))) { return Join-Path $BaseFolder $AssetUrl }
    if ($BaseUrl -and $AssetUrl) {
        $base = $BaseUrl.Substring(0, $BaseUrl.LastIndexOf('/') + 1)
        return $base + $AssetUrl
    }
    return $null
}

try {
    Write-U "apply start: current=$CurrentVersion url=$UpdateUrl dir=$InstallDir"
    if (-not $UpdateUrl) { Write-U 'no UpdateUrl configured; nothing to do'; exit 0 }

    $vi = Get-VersionInfo $UpdateUrl
    if (-not $vi -or -not $vi.version) { Write-U 'invalid version.json'; exit 1 }

    $cur = [version]::Parse($CurrentVersion)
    $lat = [version]::Parse([string]$vi.version)
    if ($lat -le $cur) { Write-U "already up to date ($($vi.version))"; exit 0 }

    $baseFolder = $null; $baseUrl = $null
    if ($UpdateUrl -match '^https?://') { $baseUrl = $UpdateUrl } elseif (Test-Path $UpdateUrl) {
        $pp = Get-Item $UpdateUrl
        $baseFolder = if ($pp.PSIsContainer) { $pp.FullName } else { $pp.DirectoryName }
    }
    $asset = Resolve-Asset ([string]$vi.url) $baseFolder $baseUrl
    if (-not $asset) { Write-U 'cannot resolve asset url'; exit 1 }

    $tmp = Join-Path $env:LOCALAPPDATA 'CleanOpt\update.tmp'
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Path $tmp -Force | Out-Null
    $zip = Join-Path $tmp 'CleanOpt.zip'

    if ($asset -match '^https?://') {
        (New-Object System.Net.WebClient).DownloadFile($asset, $zip)
    } else {
        Copy-Item $asset $zip -Force
    }
    Write-U "downloaded asset -> $zip"

    $extract = Join-Path $tmp 'extract'
    Expand-Archive -Path $zip -DestinationPath $extract -Force
    $src = $extract
    if (Test-Path (Join-Path $extract 'CleanOpt')) { $src = Join-Path $extract 'CleanOpt' }
    elseif (Test-Path (Join-Path $extract 'useful_files\CleanOpt')) { $src = Join-Path $extract 'useful_files\CleanOpt' }
    if (-not (Test-Path (Join-Path $src 'CleanOpt.ps1'))) { Write-U 'asset missing CleanOpt.ps1'; exit 1 }

    # copy over install dir, preserving user config
    $keep = @('settings.json', 'apps.json')
    Get-ChildItem -Path $src -Recurse | ForEach-Object {
        $rel = $_.FullName.Substring($src.Length).TrimStart('\', '/')
        $dest = Join-Path $InstallDir $rel
        if ($_.PSIsContainer) {
            if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest -Force | Out-Null }
        } else {
            if ($keep -contains (Split-Path $rel -Leaf) -and (Test-Path $dest)) { return }
            Copy-Item $_.FullName $dest -Force
        }
    }
    Write-U "applied files to $InstallDir"

    if ($Restart) {
        if ($OldPid -gt 0) {
            try { Wait-Process -Id $OldPid -Timeout 15 -ErrorAction SilentlyContinue } catch { }
        }
        Start-Process -FilePath 'powershell.exe' `
            -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$InstallDir\CleanOpt.ps1`" -Tray" `
            -WindowStyle Hidden
        Write-U "relaunched -> $($vi.version)"
    }
    Write-U "update done -> $($vi.version)"
    exit 0
} catch {
    Write-U ("ERROR: " + $_.Exception.Message)
    exit 2
}
