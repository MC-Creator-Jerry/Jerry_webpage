﻿<#
.SYNOPSIS
    CleanOpt - 静默每日垃圾清理.
    清理路线 (按用户要求):
      检测到火绒  -> 走火绒方式 (尽量触发火绒后台静默清理任务; 若没有可用的静默清理则退回系统方式)
      未检测到火绒 -> 走系统原生方式 (原生静默清理)

    无论走哪条路, 都保持 100% 无窗口、无提示、无弹窗.

.DESCRIPTION
    原生安全清理只删"绝对安全"的临时/缓存目录:
      系统+用户 TEMP、Prefetch、缩略图缓存、Delivery Optimization 缓存、Edge/Chrome 缓存子目录.
    回收站默认不清空 (把 $EmptyRecycleBin 设为 $true 可启用).

    关于"火绒方式":
      火绒的清理主程序 sysclean.exe 是 GUI 程序, 没有任何静默命令行参数(已实测),
      因此本工具无法"无窗口"地直接驱动它.
      火绒真正静默的清理只能靠它自己的后台计划任务(在火绒『垃圾清理-定时清理』中开启后,
      由火绒服务在后台静默运行, 完全不弹窗). 所以这里的"火绒方式"实现为:
      探测到火绒时, 自动查找并触发它的静默清理计划任务; 找不到该任务时, 退回原生静默清理,
      保证无窗口也能把垃圾清干净.
#>

$ErrorActionPreference = 'SilentlyContinue'
$logFile = Join-Path $env:LOCALAPPDATA 'CleanOpt\clean_daily.log'

function Write-Log {
    param([string]$Msg)
    try {
        $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        $line = "$ts  [clean_daily] $Msg"
        # 日志旋转: 超过 200KB 时仅保留末尾 500 行, 避免无限增长影响读/写性能
        if (Test-Path $logFile) {
            if ((Get-Item $logFile).Length -gt 200KB) {
                $keep = Get-Content -Path $logFile -Encoding UTF8 -Tail 500 -ErrorAction SilentlyContinue
                Set-Content -Path $logFile -Value $keep -Encoding UTF8
            }
        }
        Add-Content -Path $logFile -Value $line -Encoding UTF8
    } catch { }
}

# ---- tunables ----
# 注: 清空回收站由 daily_run.ps1 根据 settings.json 的 dailyEmptyRecycle 统一处理,
#      本脚本只负责"绝对安全"的临时/缓存清理, 不碰回收站.

# ---- 火绒探测 (settings.json 配置路径 优先 + 常见安装位置) ----
$settingsFile = Join-Path $PSScriptRoot 'settings.json'
$settingsHuorong = ''
if (Test-Path $settingsFile) {
    try {
        $j = Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($j.huorongPath) { $settingsHuorong = $j.huorongPath }
    } catch { }
}
$HuorongCandidates = @()
if ($settingsHuorong) { $HuorongCandidates += $settingsHuorong }
$HuorongCandidates += @(
    'D:\软件\HuorongSafety\Huorong\Sysdiag\bin\sysclean.exe',
    "$env:ProgramFiles\Huorong\Sysdiag\bin\sysclean.exe",
    "${env:ProgramFiles(x86)}\Huorong\Sysdiag\bin\sysclean.exe",
    'C:\Program Files\Huorong\Sysdiag\bin\sysclean.exe',
    'C:\Program Files (x86)\Huorong\Sysdiag\bin\sysclean.exe'
)
$huorongExe = $null
foreach ($c in $HuorongCandidates) {
    if ($c -and (Test-Path $c)) { $huorongExe = $c; break }
}

# 探测火绒的"静默清理计划任务"(用户开启『定时清理』后才存在)
function Find-HuorongCleanTask {
    try {
        $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue |
            Where-Object { ($_.TaskName -match '火绒|Huorong|SysDiag') -or ($_.TaskPath -match 'Huorong|SysDiag') }
        foreach ($t in $tasks) {
            try {
                # 直接读取首次枚举已返回的对象属性, 避免对每个任务再次 Get-ScheduledTask (N+1)
                $act = $t.Actions
                $txt = ($act | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' '
                if ($txt -match 'sysclean|clean') { return $t }
            } catch { }
        }
    } catch { }
    return $null
}

# ---- 原生静默清理 ----
function Invoke-NativeCleanup {
    Write-Log "--- 原生静默清理开始 ---"
    # 1) 用户 + 系统 TEMP
    Remove-Safe -Path $env:TEMP -Label "user TEMP ($env:TEMP)"
    Remove-Safe -Path "$env:SystemRoot\Temp" -Label "system TEMP"
    # 2) Prefetch
    Remove-Safe -Path "$env:SystemRoot\Prefetch" -Label "Prefetch"
    # 3) 缩略图缓存
    Remove-Safe -Path "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_*.db" -Label "thumbnail cache"
    # 4) Delivery Optimization 缓存
    Remove-Safe -Path "$env:SystemRoot\SoftwareDistribution\DeliveryOptimizationCache" -Label "Delivery Optimization cache"
    # 5) 浏览器缓存 (Edge + Chrome 的缓存子目录, 不动 profile/密码)
    $browserRoots = @(
        "$env:LOCALAPPDATA\Microsoft\Edge\User Data",
        "$env:LOCALAPPDATA\Google\Chrome\User Data"
    )
    $cacheFolders = @('Cache', 'Cache2', 'Code Cache', 'GPUCache', 'Media Cache', 'Service Worker\CacheStorage')
    foreach ($root in $browserRoots) {
        if (Test-Path $root) {
            Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                $profile = $_.FullName
                foreach ($cf in $cacheFolders) {
                    Remove-Safe -Path (Join-Path $profile $cf) -Label "browser cache ($profile\$cf)"
                }
            }
        }
    }
    # 6) Windows Update 残留 (标准安全项)
    try {
        Write-Log "DISM StartComponentCleanup ..."
        Start-Process -FilePath 'Dism.exe' -ArgumentList '/Online /Cleanup-Image /StartComponentCleanup' -WindowStyle Hidden -Wait
        Write-Log "DISM done"
    } catch {
        Write-Log ("ERROR DISM: " + $_.Exception.Message)
    }
    Write-Log "--- 原生静默清理结束 ---"
}

function Remove-Safe {
    param([string]$Path, [string]$Label)
    if (-not $Path -or -not (Test-Path $Path)) { return }
    try {
        # 单次枚举即完成计数与删除 (原实现分 3 趟枚举, 对大目录开销明显)
        $items = @(Get-ChildItem -Path $Path -Recurse -Force -ErrorAction SilentlyContinue)
        $before = $items.Count
        $items | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Write-Log "cleaned $Label ($before items scanned)"
    } catch {
        Write-Log ("ERROR cleaning $Label : " + $_.Exception.Message)
    }
}

# ============ 清理路线分派 ============
Write-Log "=== daily clean start ==="

if ($huorongExe) {
    Write-Log "检测到火绒: $huorongExe -> 走火绒方式"
    $hrTask = Find-HuorongCleanTask
    if ($hrTask) {
        try {
            $tn = "$($hrTask.TaskPath)$($hrTask.TaskName)"
            Write-Log "触发火绒后台静默清理任务: $tn"
            Start-Process -FilePath 'schtasks.exe' -ArgumentList "/run /tn `"$tn`"" -WindowStyle Hidden -Wait
            Write-Log "火绒后台清理任务已触发 (火绒服务在后台静默执行, 无窗口)"
        } catch {
            Write-Log ("触发火绒任务失败, 退回系统方式: " + $_.Exception.Message)
            Invoke-NativeCleanup
        }
    } else {
        Write-Log "未找到火绒的静默清理计划任务(火绒无命令行静默清理). 退回系统原生方式."
        Write-Log "提示: 在火绒『垃圾清理 - 定时清理』中开启, 即可让火绒自己在后台静默清理, 届时本工具会改走火绒方式."
        Invoke-NativeCleanup
    }
} else {
    Write-Log "未检测到火绒 -> 走系统原生方式"
    Invoke-NativeCleanup
}

Write-Log "=== daily clean end ==="
exit 0
