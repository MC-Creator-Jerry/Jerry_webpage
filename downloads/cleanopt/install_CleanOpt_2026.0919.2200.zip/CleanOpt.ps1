﻿<#
.SYNOPSIS
    CleanOpt - main window + background monitor.
    * Auto-elevates to administrator on launch (default admin).
    * Shows a single main window (plus a tray icon); no other popups are ever shown
      by running tasks.
    * Per-minute background monitor: when RAM is under pressure, silently runs the
      strong memory optimizer (empty working sets + flush modified + purge standby lists,
      PCL / Mem Reduct / RAMMap level) with no window.
    * By default the main window is hidden and the tool lives only in the system tray
      (pass -Tray, which the startup link / logon task do). No window ever opens on its
      own; bring it up via the tray icon ("显示主窗口"). All background tasks are windowless.

.NOTES
    Run with:  powershell -WindowStyle Hidden -File CleanOpt.ps1
    Closing the window hides to the tray (monitor keeps running); use tray "退出" to quit.
#>

param([switch]$Tray)

# ---- tunables (默认; 均可被 settings.json 覆盖) ----
$RamPressureUsedPct = 85      # 内存紧张阈值%
$MonitorIntervalSec  = 60      # 监控间隔(秒)
$script:trayNotify  = $false   # 后台静默动作后是否弹托盘气泡(默认关, 遵守无弹窗)
$script:gndEnabled  = $true    # 游戏/全屏免打扰(默认开)
$script:gndProcesses = 'javaw.exe;java.exe'   # 免打扰进程名(分号/逗号分隔)
$script:diskFreeThresholdPct = 10   # 任一固定盘剩余%低于此值则自动清理
$script:idleMinutes = 5       # 系统需空闲满 N 分钟才自动优化(0=不限)
$script:optimizeStrength = 'strong'   # strong=全量(工作集+备用) / standard=仅备用列表
$script:startupDelaySec = 0   # 启动后延迟 N 秒再开始监控(0=立即)
$script:dailyEmptyRecycle = $true   # 每日任务是否包含清空回收站
$script:restoreEnabled    = $true   # 清理结果可还原: 默认开, 删除前移入隔离区
$script:restoreKeepDays   = 30      # 隔离区保留天数, 超过自动彻底删除
$script:privacyClean      = $false  # 隐私痕迹清理: 默认关(敏感), 开启后常规清理顺带清隐私痕迹

# ---- 自动更新 (下一代起生效) ----
$script:AppVersion = '2026.0919.2200'   # 版本号 = 构建日期时间 (年.月日.时分, 月日/时分补零); 用于与更新源比对
$script:autoUpdate = $true           # 是否自动检查并静默应用更新
$script:updateUrl  = ''              # 更新源: version.json 的地址(本地文件夹或 http(s) URL); 留空=关闭
$script:updateIntervalDays = 7       # 自动检查间隔(天)
$script:_lastUpdateCheck = $null     # 上次检查更新时间

# ---- 单实例: 若已运行则唤醒已有实例(打开其窗口), 不重复启动 ----
function Signal-ExistingInstance {
    # 反复尝试打开已存在实例的"显示主窗口"事件, 最多约 2 秒
    $ok = $false
    for ($i = 0; $i -lt 20; $i++) {
        try {
            $ev = [System.Threading.EventWaitHandle]::OpenExisting('CleanOpt_ShowEvent')
            $ev.Set() | Out-Null
            $ev.Dispose()
            $ok = $true
            break
        } catch {
            Start-Sleep -Milliseconds 100
        }
    }
    if (-not $ok) {
        # 极端情况下事件尚未建好: 直接创建并触发一次(无害)
        try {
            $ev = New-Object System.Threading.EventWaitHandle($false, 'AutoReset', 'CleanOpt_ShowEvent')
            $ev.Set() | Out-Null
            $ev.Dispose()
        } catch { }
    }
}

$singleMutex = New-Object System.Threading.Mutex($false, 'CleanOpt_SingleInstance')
$global:showEvent = New-Object System.Threading.EventWaitHandle($false, 'AutoReset', 'CleanOpt_ShowEvent')
try {
    $isFirst = $singleMutex.WaitOne(0)
} catch [System.Threading.AbandonedMutexException] {
    $isFirst = $true
} catch {
    # 其他异常(如权限) -> 当作首个实例继续, 不阻断工具
    $isFirst = $true
}
if (-not $isFirst) {
    # 已有实例在运行 -> 通知它显示主窗口, 然后退出(不重复启动)
    Signal-ExistingInstance
    $singleMutex.Dispose()
    exit
}

# ---- auto-elevate ----
function Test-Admin {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object System.Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
}
if (-not (Test-Admin)) {
    $trayArg = if ($Tray) { ' -Tray' } else { '' }
    # 释放单实例锁, 让被提权的子进程成为唯一持有者(避免重复/丢失)
    try { $singleMutex.ReleaseMutex() } catch { }
    Start-Process -FilePath (Get-Process -Id $pid).Path -Verb RunAs `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`"$trayArg"
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# 软件图标: 取 Windows 自带的"磁盘清理"扫帚图标 (cleanmgr.exe), 主题最贴合"清理/优化"工具.
try {
    $ico = Join-Path $PSScriptRoot 'CleanOpt.ico'
    if (Test-Path $ico) { $script:appIcon = [System.Drawing.Icon]::FromFile($ico) }
    else { $script:appIcon = [System.Drawing.SystemIcons]::Application }
} catch { $script:appIcon = [System.Drawing.SystemIcons]::Application }

$root = $PSScriptPath | Split-Path -Parent
$global:forceExit = $false

# ---- helpers ----
function Invoke-Optimize {
    $arg = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\optimize_mem.ps1`" -Strength $script:optimizeStrength"
    Start-Process -FilePath 'powershell.exe' -ArgumentList $arg -WindowStyle Hidden
}
function Invoke-RunAll {
    $script:lblStatus.Text = '全面优化中…（清理→优化→回收站，后台无窗口）'
    $bwAll.RunWorkerAsync()
}
function Get-LastLogLine {
    param([string]$Name)
    $p = Join-Path $env:LOCALAPPDATA "CleanOpt\$Name"
    if (Test-Path $p) {
        # 只取最后 1 行, 避免每次监控都整文件读入 (日志变大后开销明显)
        # 修复「上次优化: A」: -Tail 1 返回的是字符串(标量), 旧代码 $last[-1] 取的是最后一个"字符"
        $last = @(Get-Content -Path $p -Encoding UTF8 -Tail 1 -ErrorAction SilentlyContinue | Where-Object { $_.Trim() -ne '' })
        if ($last.Count -gt 0) { return $last[-1].Trim() }
    }
    return '(无记录)'
}
# 头部标签只显示日志行首的时间戳 (yyyy-MM-dd HH:mm:ss), 避免把整行塞进窄标签
function Get-LastLogDate {
    param([string]$Name)
    $line = Get-LastLogLine $Name
    if ($line -and $line -ne '(无记录)' -and $line -match '^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})') { return $Matches[1] }
    return '无记录'
}
# 读取清理统计 (clean_daily.ps1 写入): lastRun / freedBytes / cleanCount
function Get-CleanStat {
    $p = Join-Path $env:LOCALAPPDATA 'CleanOpt\stat.json'
    if (Test-Path $p) {
        try { return (Get-Content $p -Encoding UTF8 -Raw | ConvertFrom-Json) } catch { }
    }
    return $null
}
function Format-Bytes {
    param([long]$Bytes)
    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N1} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N1} KB' -f ($Bytes / 1KB)) }
    return ('{0} B' -f $Bytes)
}
function Update-Status {
    try {
        $os = Get-CimInstance Win32_OperatingSystem
        $total = $os.TotalVisibleMemorySize  # KB
        $free  = $os.FreePhysicalMemory       # KB
        $usedPct = [math]::Round(($total - $free) / $total * 100, 1)
        $script:lblRam.Text = "内存占用: $usedPct%   (空闲 $([math]::Round($free/1024,1)) GB / $([math]::Round($total/1024,1)) GB)"
        # 内存仪表: 进度条 + 文字随压力档变色
        try {
            $script:pbRam.Value = [math]::Min(100, [math]::Max(0, [int]$usedPct))
            $band = Get-BandName $usedPct
            if ($band -eq 'red') { $script:lblRam.ForeColor = [System.Drawing.Color]::FromArgb(200, 40, 40) }
            elseif ($band -eq 'yellow') { $script:lblRam.ForeColor = [System.Drawing.Color]::FromArgb(190, 140, 20) }
            else { $script:lblRam.ForeColor = [System.Drawing.Color]::FromArgb(0, 120, 60) }
        } catch { }
        # F4: 托盘图标随内存压力变色 (复用缓存图标, 避免 GDI 句柄泄漏)
        $script:_lastUsedPct = $usedPct
        Update-TrayIconByPct $usedPct
    } catch { }
    # 磁盘仪表 (C:)
    try {
        $cd = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
        if ($cd -and $cd.Size -gt 0) {
            $freePct = [math]::Round($cd.FreeSpace / $cd.Size * 100, 1)
            $usedPctD = [math]::Round(100 - $freePct, 1)
            $script:pbDisk.Value = [math]::Min(100, [math]::Max(0, [int]$usedPctD))
            $script:pbDisk.ForeColor = $script:cAccent
            $script:lblDisk.ForeColor = [System.Drawing.Color]::FromArgb(64, 72, 84)
            $script:lblDisk.Text = "C盘: 已用 $usedPctD%  (剩 $([math]::Round($cd.FreeSpace/1GB,1)) GB / $([math]::Round($cd.Size/1GB,1)) GB)"
        }
    } catch { }
    $script:lblClean.Text  = "上次清理: $(Get-LastLogDate 'clean_daily.log')"
    $script:lblOpt.Text    = "上次优化: $(Get-LastLogDate 'optimize_mem.log')"
}

# ---- Win32 P/Invoke + 新增功能函数 ----
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

[StructLayout(LayoutKind.Sequential)]
public struct RectStruct { public int Left, Top, Right, Bottom; }

[StructLayout(LayoutKind.Sequential)]
public struct LastInputStruct { public uint cbSize; public uint dwTime; }

public class Win32Api {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RectStruct lpRect);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("user32.dll")] public static extern bool GetLastInputInfo(ref LastInputStruct plii);
    [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);
    [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
}

public class HotkeyFilter : IMessageFilter {
    public const int WM_HOTKEY = 0x0312;
    public Action OnHotkey;
    public bool PreFilterMessage(ref Message m) {
        if (m.Msg == WM_HOTKEY && OnHotkey != null) { try { OnHotkey(); } catch { } }
        return false;
    }
}
'@

# 托盘图标随内存压力变色: 绿(<60) / 黄(60-85) / 红(>=85)
# 优化: 三个压力档位的图标只构建一次并缓存复用, 不在每次监控都新建/销毁 GDI 对象,
#       避免长期驻留托盘导致 GDI 句柄缓慢泄漏 (原实现每分钟都 New/Dispose, 长时间运行会累加).
$script:_bandIcons = $null
$script:_curBand   = ''
$script:_lastUsedPct = 0
$script:_lastAutoOptimize = [datetime]::MinValue   # 自动优化冷却时间戳

function Build-AllBandIcons {
    $make = {
        param([System.Drawing.Color]$c)
        try {
            $bmp = New-Object System.Drawing.Bitmap(16, 16)
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            $g.SmoothingMode = 'AntiAlias'
            $g.Clear([System.Drawing.Color]::Transparent)
            $g.FillEllipse((New-Object System.Drawing.SolidBrush($c)), 1, 1, 14, 14)
            $g.DrawEllipse((New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(40, 40, 40))), 1, 1, 14, 14)
            $h = $bmp.GetHicon()
            $ico = [System.Drawing.Icon]::FromHandle($h).Clone()
            [System.Runtime.InteropServices.Marshal]::DestroyIcon($h)  # 释放 GetHicon 产生的临时句柄
            $g.Dispose(); $bmp.Dispose()
            return $ico
        } catch { return $null }
    }
    $script:_bandIcons = @{
        green  = & $make ([System.Drawing.Color]::FromArgb(60, 170, 70))
        yellow = & $make ([System.Drawing.Color]::FromArgb(230, 170, 30))
        red    = & $make ([System.Drawing.Color]::FromArgb(220, 40, 40))
    }
}

function Get-BandName {
    param([double]$Pct)
    if ($Pct -ge 85) { return 'red' }
    elseif ($Pct -ge 60) { return 'yellow' }
    else { return 'green' }
}

function Update-TrayIconByPct {
    param([double]$Pct)
    try {
        if (-not $script:_bandIcons) { Build-AllBandIcons }
        $band = Get-BandName $Pct
        if ($band -ne $script:_curBand) {
            $script:_curBand = $band
            $ico = $script:_bandIcons[$band]
            if ($ico -and $notifyIcon) { $notifyIcon.Icon = $ico }
        }
    } catch { }
}

function Dispose-BandIcons {
    if ($script:_bandIcons) {
        $script:_bandIcons.Values | ForEach-Object { try { $_.Dispose() } catch { } }
        $script:_bandIcons = $null
    }
}

function Get-ForegroundProcessName {
    try {
        $hwnd = [Win32Api]::GetForegroundWindow()
        if ($hwnd -eq [IntPtr]::Zero) { return '' }
        $pid = 0
        [Win32Api]::GetWindowThreadProcessId($hwnd, [ref]$pid) | Out-Null
        if ($pid -le 0) { return '' }
        $p = Get-Process -Id $pid -ErrorAction SilentlyContinue
        return if ($p) { $p.ProcessName } else { '' }
    } catch { return '' }
}

function Test-Fullscreen {
    try {
        $hwnd = [Win32Api]::GetForegroundWindow()
        if ($hwnd -eq [IntPtr]::Zero) { return $false }
        $rect = New-Object RectStruct
        if (-not [Win32Api]::GetWindowRect($hwnd, [ref]$rect)) { return $false }
        $b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        return ($rect.Left -le 0 -and $rect.Top -le 0 -and $rect.Right -ge $b.Width -and $rect.Bottom -ge $b.Height)
    } catch { return $false }
}

function Get-IdleMilliseconds {
    try {
        $lii = New-Object LastInputStruct
        $lii.cbSize = [uint32]([System.Runtime.InteropServices.Marshal]::SizeOf($lii))
        if ([Win32Api]::GetLastInputInfo([ref]$lii)) {
            # 用 32 位 tick 差计算, 自动处理 49.7 天回绕 (TickCount64 不回绕反而会错位)
            $tickNow = [uint32][Environment]::TickCount
            $idle = [long]($tickNow - $lii.dwTime)
            if ($idle -lt 0) { $idle += [uint32]::MaxValue + 1 }
            return $idle
        }
    } catch { }
    return 0
}

function Get-LowDiskDrive {
    param([double]$ThresholdPct)
    try {
        # 结果缓存 3 分钟, 避免每分钟监控都发起一次 WMI 查询
        if ($script:_diskCache -and (((Get-Date) - $script:_diskCache.ts).TotalSeconds -lt 180)) {
            return $script:_diskCache.result
        }
        $drives = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue
        $found = $null
        foreach ($d in $drives) {
            if ($d.Size -gt 0) {
                $freePct = $d.FreeSpace / $d.Size * 100
                if ($freePct -lt $ThresholdPct) { $found = "$($d.DeviceID) 剩余$([math]::Round($freePct,1))%"; break }
            }
        }
        $script:_diskCache = @{ ts = Get-Date; result = $found }
        return $found
    } catch { }
    return $null
}

# 估算原生清理项可回收大小 (字节): 低盘触发自动清理前先判断是否有意义
function Measure-CleanupPotential {
    $paths = @(
        $env:TEMP,
        "$env:SystemRoot\Temp",
        "$env:SystemRoot\Prefetch",
        "$env:LOCALAPPDATA\Microsoft\Windows\Explorer",
        "$env:SystemRoot\SoftwareDistribution\DeliveryOptimizationCache"
    )
    $total = 0
    foreach ($p in $paths) {
        if (Test-Path $p) {
            try {
                $total += (Get-ChildItem -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue |
                    Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum).Sum
            } catch { }
        }
    }
    $browserRoots = @("$env:LOCALAPPDATA\Microsoft\Edge\User Data", "$env:LOCALAPPDATA\Google\Chrome\User Data")
    $cacheFolders = @('Cache', 'Cache2', 'Code Cache', 'GPUCache', 'Media Cache', 'Service Worker\CacheStorage')
    foreach ($root in $browserRoots) {
        if (Test-Path $root) {
            Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                $profile = $_.FullName
                foreach ($cf in $cacheFolders) {
                    $cp = Join-Path $profile $cf
                    if (Test-Path $cp) {
                        try {
                            $total += (Get-ChildItem -LiteralPath $cp -Recurse -Force -ErrorAction SilentlyContinue |
                                Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum).Sum
                        } catch { }
                    }
                }
            }
        }
    }
    return $total
}

# ---- 清空【当前用户】回收站（不依赖 Add-Type/P/Invoke，兼容受限语言模式/加固环境）----
# 做法：① Clear-RecycleBin cmdlet（与资源管理器“清空回收站”同源）→ ② SHEmptyRecycleBin P/Invoke 兜底
#       → ③ 逐盘强删当前用户 SID 回收站目录（cmd rd/del，先剥离只读/系统/隐藏属性）。
# 每一步结果写入 %LOCALAPPDATA%\CleanOpt\recycle_debug.log；仍删不掉的占用项写入 recycle_residue.log。
function Clear-MyRecycleBin {
    $dbg = @()
    $sid = $null
    try { $sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value } catch { }
    if (-not $sid) { return @{ Ok = $false; Removed = 0; Remaining = 0; Note = '无法获取当前用户 SID' } }

    function Get-RBItems {
        param([string]$s)
        $n = 0
        $drives = @(Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction SilentlyContinue | ForEach-Object { $_.DeviceID.TrimEnd(':') + ':' })
        foreach ($drv in $drives) {
            $bin = "$drv\`$Recycle.Bin\$s"
            if (Test-Path -LiteralPath $bin) { $n += @(Get-ChildItem -LiteralPath $bin -Force -ErrorAction SilentlyContinue).Count }
        }
        return $n
    }

    $before = Get-RBItems -s $sid
    $dbg += ('before(items)=' + $before + ' sid=' + $sid)

    $emptied = $false
    try {
        Clear-RecycleBin -Force -ErrorAction Stop
        $emptied = $true
        $dbg += 'Clear-RecycleBin: OK'
    } catch { $dbg += ('Clear-RecycleBin FAILED: ' + $_.Exception.Message) }

    if (-not $emptied) {
        try {
            try { $null = [WinAPI.ShellRecycle] } catch {
                Add-Type -MemberDefinition @'
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
public struct SHQUERYRBINFO { public int cbSize; public long i64Size; public long i64NumItems; }
[DllImport("shell32.dll", CharSet = CharSet.Unicode)]
public static extern int SHQueryRecycleBin(string pszRootPath, ref SHQUERYRBINFO pInfo);
[DllImport("shell32.dll", CharSet = CharSet.Unicode)]
public static extern int SHEmptyRecycleBin(IntPtr hwnd, string pszRootPath, int dwFlags);
'@ -Name 'ShellRecycle' -Namespace 'WinAPI' -PassThru | Out-Null
            }
            $code = [WinAPI.ShellRecycle]::SHEmptyRecycleBin([IntPtr]::Zero, $null, 0x1 -bor 0x2 -bor 0x4)
            if ($code -eq 0) { $emptied = $true; $dbg += 'SHEmptyRecycleBin: OK' }
            else { $dbg += ('SHEmptyRecycleBin code=' + $code) }
        } catch { $dbg += ('SHEmptyRecycleBin EXC: ' + $_.Exception.Message) }
    }

    $residue = @()
    $drives = @(Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction SilentlyContinue | ForEach-Object { $_.DeviceID.TrimEnd(':') + ':' })
    foreach ($drv in $drives) {
        $bin = "$drv\`$Recycle.Bin\$sid"
        if (-not (Test-Path -LiteralPath $bin)) { continue }
        cmd /c "attrib -r -s -h /s /d ""$bin\*""" 2>$null
        cmd /c "attrib -r -s -h ""$bin""" 2>$null
        cmd /c "rd /s /q ""\\?\$bin""" 2>$null
        if (Test-Path -LiteralPath $bin) {
            foreach ($it in @(Get-ChildItem -LiteralPath $bin -Force -ErrorAction SilentlyContinue)) {
                $p = '\\?\' + $it.FullName
                cmd /c "attrib -r -s -h ""$($it.FullName)""" 2>$null
                if ($it.PSIsContainer) { cmd /c "rd /s /q ""$p""" 2>$null } else { cmd /c "del /f /q /a ""$p""" 2>$null }
            }
            Start-Sleep -Milliseconds 400
            foreach ($it in @(Get-ChildItem -LiteralPath $bin -Force -ErrorAction SilentlyContinue)) {
                $p = '\\?\' + $it.FullName
                if ($it.PSIsContainer) { cmd /c "rd /s /q ""$p""" 2>$null } else { cmd /c "del /f /q /a ""$p""" 2>$null }
                if (Test-Path -LiteralPath $it.FullName) { $residue += $it.FullName }
            }
        }
    }

    $after = Get-RBItems -s $sid
    $dbg += ('after(items)=' + $after + ' residue=' + $residue.Count)
    try {
        $ld = Join-Path $env:LOCALAPPDATA 'CleanOpt'
        if (-not (Test-Path $ld)) { New-Item -ItemType Directory -Path $ld -Force | Out-Null }
        $dbg | Out-File -FilePath (Join-Path $ld 'recycle_debug.log') -Encoding UTF8
        if ($residue.Count -gt 0) { $residue | Out-File -FilePath (Join-Path $ld 'recycle_residue.log') -Encoding UTF8 }
    } catch { }

    $removed = if ($before -ge 0) { [Math]::Max(0, $before - $after) } else { 0 }
    if ($residue.Count -gt 0) {
        return @{ Ok = $true; Removed = $removed; Remaining = $residue.Count; Note = "有 $($residue.Count) 项因被程序占用未能清除（路径见 recycle_residue.log）" }
    }
    return @{ Ok = $true; Removed = $removed; Remaining = 0; Note = '' }
}


# ===== 清理缓存 / 清理历史记录 的目标引擎 =====
# 说明：微信/QQ/TIM/企业微信/飞书 等聊天记录数据库是加密的(SQLCipher)，纯本地脚本读不到
# “群聊名称”，故“清理历史记录”以【账号】为最小可选单元（多选）；删除前默认备份到隔离区(可还原)。
# “清理缓存”针对各应用可再生的缓存目录，直接删除、不备份。

function Get-FolderSize {
    param([string]$Path)
    try {
        $sz = (Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue |
            Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum).Sum
        if ($null -eq $sz) { $sz = 0 }
        return [int64]$sz
    } catch { return 0 }
}

# 应用注册表：Root=账号根目录；Cache=缓存子目录(相对账号)；History=历史子目录(相对账号, 空=整账号)
function Get-AppCleanRegistry {
    $prof = $env:USERPROFILE
    $la   = $env:LOCALAPPDATA
    $roam = $env:APPDATA
    return @(
        @{ App='微信';     Root=Join-Path $prof 'Documents\WeChat Files';       Cache=@('FileStorage\Cache','FileStorage\Video'); History=@('Msg') }
        @{ App='QQ';      Root=Join-Path $prof 'Documents\Tencent Files';       Cache=@('Image','Video');                          History=@('Msg3.0','Msg2.0','Msg') }
        @{ App='TIM';     Root=Join-Path $roam 'Tencent\TIM';                    Cache=@('Cache','Image','Video');                 History=@('Msg3.0','Msg2.0') }
        @{ App='钉钉';     Root=Join-Path $roam 'DingTalk';                       Cache=@('Cache','GPUCache','Code Cache');         History=@() }
        @{ App='企业微信'; Root=Join-Path $roam 'WXWork';                         Cache=@('Cache','GPUCache','Code Cache');         History=@() }
        @{ App='飞书';     Root=Join-Path $roam 'Lark';                           Cache=@('Cache','GPUCache','Code Cache');         History=@() }
        @{ App='Telegram';Root=Join-Path $roam 'Telegram Desktop';               Cache=@();                                        History=@('tdata') }
        @{ App='Chrome';   Root=Join-Path $la   'Google\Chrome\User Data';       Cache=@('Cache','Cache2','Code Cache','GPUCache');History=@('History') }
        @{ App='Edge';     Root=Join-Path $la   'Microsoft\Edge\User Data';      Cache=@('Cache','Cache2','Code Cache','GPUCache');History=@('History') }
    )
}

# 扫描并返回 flat 目标列表：每个对象含 App/Account/Kind('cache'|'history')/Path/Label/Size
function Get-CleanTargets {
    $reg = Get-AppCleanRegistry
    $out = @()
    foreach ($a in $reg) {
        $root = $a.Root
        if (-not (Test-Path -LiteralPath $root)) { continue }
        $subs = @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue)
        if ($subs.Count -eq 0) {
            $accounts = @(@{ Name='(本机)'; Path=$root })
        } else {
            $accounts = @($subs | ForEach-Object { @{ Name=$_.Name; Path=$_.FullName } })
        }
        foreach ($acct in $accounts) {
            foreach ($c in $a.Cache) {
                $p = Join-Path $acct.Path $c
                if (Test-Path -LiteralPath $p) {
                    $out += @{ App=$a.App; Account=$acct.Name; Kind='cache'; Path=$p;
                                Label=("$($a.App) · $($acct.Name) · $c"); Size=(Get-FolderSize $p) }
                }
            }
            foreach ($h in $a.History) {
                $p = if ($h) { Join-Path $acct.Path $h } else { $acct.Path }
                if (Test-Path -LiteralPath $p) {
                    $out += @{ App=$a.App; Account=$acct.Name; Kind='history'; Path=$p;
                                Label=("$($a.App) · $($acct.Name) · 聊天记录"); Size=(Get-FolderSize $p) }
                }
            }
        }
    }
    return $out
}

# 历史清理：备份到隔离区(可还原)后删除；direct=$true 时直接删除(立即释放空间, 不可还原)
function Backup-And-Delete {
    param([string]$Path, [string]$Tag, [bool]$Direct = $false)
    if ($Direct) {
        try { Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop; return @{ Ok = $true; Backup = '' } }
        catch { return @{ Ok = $false; Error = $_.Exception.Message } }
    }
    $restoreRoot = Join-Path $env:LOCALAPPDATA 'CleanOpt\Restore'
    try { New-Item -ItemType Directory -Path $restoreRoot -Force -ErrorAction SilentlyContinue | Out-Null } catch { }
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $safeName = ($Tag -replace '[\\/:*?"<>&|]', '_')
    $dest = Join-Path $restoreRoot ($stamp + '_' + $safeName)
    try {
        Copy-Item -LiteralPath $Path -Destination $dest -Recurse -Force -ErrorAction Stop
        Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
        return @{ Ok = $true; Backup = $dest }
    } catch {
        return @{ Ok = $false; Error = $_.Exception.Message }
    }
}

# F1 游戏/全屏免打扰: 前台进程在列表 或 前台窗口全屏 -> 暂停自动优化
function Test-ShouldSkipAutoOptimize {
    if (-not $script:gndEnabled) { return $false }
    try {
        $name = Get-ForegroundProcessName
        if ($name) {
            $list = @($script:gndProcesses -split '[;, ]' | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ })
            if ($list -contains $name.ToLower()) { return $true }
        }
        if (Test-Fullscreen) { return $true }
    } catch { }
    return $false
}

# F7 一键导出诊断信息
function Export-Diagnostics {
    try {
        $os = Get-CimInstance Win32_OperatingSystem
        $total = [math]::Round($os.TotalVisibleMemorySize / 1024 / 1024, 2)
        $free  = [math]::Round($os.FreePhysicalMemory / 1024 / 1024, 2)
        $disks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue |
            ForEach-Object { "$($_.DeviceID) 总$([math]::Round($_.Size/1GB,1))GB / 剩余$([math]::Round($_.FreeSpace/1GB,1))GB" }
        $settings = if (Test-Path $settingsFile) { Get-Content $settingsFile -Raw -Encoding UTF8 } else { '(无 settings.json)' }
        $clean = Get-LastLogLine 'clean_daily.log'
        $opt   = Get-LastLogLine 'optimize_mem.log'
        $lines = @(
            '===== CleanOpt 诊断 =====',
            "时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
            "系统: $($os.Caption) ($($os.OSArchitecture))",
            "内存: 总 ${total}GB / 空闲 ${free}GB",
            '磁盘:',
            ($disks -join "`r`n"),
            "上次清理: $clean",
            "上次优化: $opt",
            'settings.json:',
            $settings
        )
        $sfd = New-Object System.Windows.Forms.SaveFileDialog
        $sfd.Filter = '文本文件 (*.txt)|*.txt'
        $sfd.Title = '导出诊断信息'
        $sfd.FileName = "CleanOpt_诊断_$(Get-Date -Format 'yyyyMMdd_HHmm').txt"
        if ($sfd.ShowDialog() -eq 'OK') {
            Set-Content -Path $sfd.FileName -Value ($lines -join "`r`n") -Encoding UTF8
            [System.Windows.Forms.MessageBox]::Show('已导出到:' + [Environment]::NewLine + $sfd.FileName, '诊断导出', 'OK', 'Information')
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show('导出失败: ' + $_.Exception.Message, '错误', 'OK', 'Error')
    }
}

# F10 关于对话框
function Show-AboutDialog {
    $ad = New-Object System.Windows.Forms.Form
    $ad.Text = '关于 CleanOpt'
    $ad.Size = New-Object System.Drawing.Size(420, 360)
    $ad.StartPosition = 'CenterParent'
    $ad.FormBorderStyle = 'FixedDialog'
    $ad.MaximizeBox = $false; $ad.MinimizeBox = $false
    $ad.Icon = $script:appIcon
    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true; $tb.ReadOnly = $true; $tb.ScrollBars = 'Vertical'
    $tb.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $tb.Location = New-Object System.Drawing.Point(12, 12)
    $tb.Size = New-Object System.Drawing.Size(384, 300)
    $ad.Controls.Add($tb)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(160, 320); $btnClose.Size = New-Object System.Drawing.Size(100, 28)
    $ad.Controls.Add($btnClose)
    $feats = @(
        '• 默认管理员运行，静默后台清理+优化',
        '• 内存优化：终止 WorkBuddy 预热带(可回收缓存) + 清空系统备用列表（去除无效的清工作集，避免越优化越涨）',
        '• 垃圾清理：火绒方式优先，回退系统原生',
        '• 每分钟监控：内存紧张/磁盘不足/空闲才优化',
        '• 游戏/全屏免打扰、全局热键 Ctrl+Alt+O',
        '• 托盘图标随内存压力变色',
        '• 单实例：重复启动只唤醒已有窗口',
        '• 设置可配置阈值/间隔/强度/延迟/免打扰',
        '• 运行日志、诊断导出、一键全面优化',
        '• 自动更新：每周静默检查并应用新版本',
        '• 内存大户 Top 视图，看清谁在占用内存'
        '• 自适应缩放（高 DPI 自动清晰）、主面板滚动条（窗口缩小自动出现）'
        '• 全新界面 v1.11：内存占用仪表、操作分组、悬停高亮与工具提示'
        '• 清理结果可还原：隔离区 + 自动过期清理，可一键还原（满足安全硬性要求）'
        '• 启动项管理：注册表/启动文件夹/计划任务三类开机启动项，可禁用/启用并还原'
        '• 隐私痕迹清理：最近使用、跳转列表、运行记录、地址栏输入记录'
    )
    $tb.Text = "CleanOpt v$($script:AppVersion)`r`n由 WorkBuddy 为 Jerry 定制`r`n`r`n本次新增（v2026.0919.2200 界面圆角美化 + 启动崩溃修复）：`r`n• 修复「启动后看不到窗口」：上一版误写入一处未定义的 Set-Rounded 调用，PowerShell 遇到未定义命令会直接中断脚本；现补齐圆角/双缓冲辅助函数并加静态检查，确保无其它未定义调用`r`n• 界面圆角化：侧栏导航改为圆角高亮药丸、卡片改为圆角白底浅描边、首页「一键全面优化」大按钮圆角，整体观感不再方硬`r`n`r`n本次新增（v2026.0919.2100 回收站修复）：`r`n• 重写清空回收站逻辑：彻底移除对 Add-Type/P/Invoke(SHEmptyRecycleBin) 的硬依赖（受限语言模式/加固环境下 Add-Type 会抛错，导致整段失效、按钮像「没反应」）`r`n• 改为主用 Clear-RecycleBin cmdlet + 逐盘强制删除当前用户 SID 回收站目录（剥离只读/系统/隐藏属性）双重兜底，任一路径可用即可清空`r`n• 每次清空把各方法结果、前后项数与仍残留项写入 %LOCALAPPDATA%\CleanOpt\recycle_debug.log / recycle_residue.log，便于定位「仍删不掉」的占用程序`r`n`r`n本次新增（v2026.0919.1830 自定义图标）：`r`n• 应用自带专属图标：弃用系统「磁盘清理」扫帚图标，改用 CleanOpt.ico（蓝底白对勾，多尺寸 16–256）`r`n• 任务栏/系统托盘、桌面快捷方式、安装包内托盘快捷方式图标均指向 CleanOpt.ico，不再与 PowerShell/系统图标混同`r`n`r`n本次新增（v2026.0906.1813 视觉美化 + 缺陷修复）：`r`n• 视觉美化：导航项改为圆角药丸样式、选中态用主色高亮；卡片改为圆角白卡(自绘边框)；主按钮「一键全面优化」圆角化并移除乱码火箭 emoji`r`n• 修复「运行概况」卡片空白：窗体 Shown 后显式刷新统计，确保上次清理/累计释放/上次优化正常显示`r`n• 修复「上次优化: A」：Get-LastLogLine 误用字符串[-1]取最后一个字符，改为取最后一行文本；头部标签改为只显示时间戳`r`n• 修复「一键全面优化」前乱码方块：移除 WinForms 字体无法渲染的 emoji`r`n`r`n本次新增（v2026.0905.1727 清理缓存 + 清理历史记录）：`r`n• 修复「无法启动」：关于框变更日志中的弯引号会导致脚本整体解析失败，已改为转义直引号`r`n• 新增「缓存清理」页：自动检测微信/QQ/TIM/钉钉/企业微信/飞书/Telegram/Chrome/Edge 等已装软件，按`"软件·账号·类型`"列出缓存并附估算大小，可多选勾选后一键清理（缓存可再生，直接删安全）`r`n• 新增「历史记录」页：选软件 → 多选账号清空聊天记录；因微信/QQ 等聊天库加密(读不到群聊名)，以【账号】为最小可选单元，删除前默认备份到隔离区(可还原)`r`n• 历史清理提供`"直接删除(立即释放空间, 不可还原)`"选项，默认走安全备份；钉钉/企业微信/飞书本地加密，提示用软件内`"清空聊天记录`"`r`n• 两页均在打开时自动重新检测；支持刷新/全选/全不选`r`n`r`n历史新增（v2026.0903.1918 回收站清空修复）：`r`n• 修「清空回收站过慢、不一定有效」bug：旧实现用 Clear-RecycleBin(Shell COM) 易卡慢，且 Remove-Item 遍历全部 SID 因跨用户 ACL 而失败`r`n• 改为仅清空【当前用户 SID】回收站，用原生 cmd rd /s /q（内核级、快、可处理受保护目录）`r`n• 先用 \\?\ 长路径前缀避免超长路径报错；删除后仍残留(被占用项)逐条补删并诚实上报「部分失败」`r`n• 仅处理本地固定磁盘(DriveType=3)，避开网络/光驱/软驱防止卡顿`r`n`r`n历史新增（v2026.0901.1934 显示与工作方法优化）：`r`n• 导航：按「清理优化 / 系统工具」分组 + 悬停高亮，层次更清晰`r`n• 首页：新增「运行概况」卡片（上次清理 / 累计释放 / 上次自动优化一目了然）`r`n• 新增 New-Card 统一分区视觉（白卡+浅边框+标题）`r`n• 后台：低盘不足时先估算可释放空间(<30MB 跳过)，不再无意义拉进程`r`n• 更新提示新增「稍后提醒」(取消键)，避免反复弹窗`r`n• 清理结束写 stat.json，首页概况实时读取`r`n`r`n版本号规则：年.月日.时分（月日/时分补零，如 2026.0903.1918）`r`n`r`n历史新增（v2026.0831.1813 版本号格式调整）：`r`n• 版本号由 5段(年.月.日.时.分) 改为 3段(年.月日.时分)`r`n• Get-VersionKey 改 [datetime] Ticks 比较（打包格式跨年比较修正）`r`n`r`n历史新增（v1.22 UI 修复）：`r`n• 进度条配色真正生效（P/Invoke 禁用 Visual Styles）`r`n• 「一键全面优化」大按钮改 Panel+Label 自绘（之前不可见）`r`n`r`n历史新增（v1.16 第三阶段·功能扩展）：`r`n• 强力卸载 / C盘大文件 / 自定义清理规则 / 操作审计`r`n• 导航增至 9 项`r`n`r`n功能一览：`r`n" + ($feats -join "`r`n")
    $btnClose.Add_Click({ $ad.DialogResult = 'Cancel'; $ad.Close() })
    $ad.ShowDialog() | Out-Null
}

# ---- 自动更新 (下一代起生效) ----
function Get-RemoteVersionInfo {
    param([string]$Url)
    try {
        if ($Url -match '^https?://') {
            return Invoke-RestMethod -Uri $Url -UseBasicParsing -ErrorAction Stop
        }
        if (Test-Path $Url) {
            $p = Get-Item $Url
            if ($p.PSIsContainer) { $Url = Join-Path $Url 'version.json' }
            if (Test-Path $Url) { return Get-Content $Url -Raw -Encoding UTF8 | ConvertFrom-Json }
        }
    } catch { }
    return $null
}

function Get-VersionKey {
    # 将版本号转为可比较的 [datetime] Ticks; 兼容以下格式:
    #   - 年.月日.时分 (3段打包, 如 2026.0831.1813)  ← 当前格式
    #   - 年.月.日.时.分 (5段, 如 2026.8.31.18.07)
    #   - 旧式 1.22 (2段) → 映射到一个很老的日期, 保证任何日期版本都判定为更新
    # 注意: 不能用简单的整数乘法键, 否则打包格式的"月日"一档会超过"年"一档, 导致跨年比较错误
    param([string]$v)
    $p = @($v -split '\.') | ForEach-Object { $n = 0; if ([int]::TryParse($_, [ref]$n)) { $n } else { 0 } }
    try {
        if ($p.Count -ge 5) {
            $dt = [datetime]::new($p[0], [math]::Max(1, $p[1]), [math]::Max(1, $p[2]), $p[3], $p[4], 0)
            return $dt.Ticks
        }
        elseif ($p.Count -eq 3) {
            # 年.月日.时分: 月日 = 831 → 月8日31; 时分 = 1813 → 时18分13
            $mon = [math]::Max(1, [math]::Min(12, [int]($p[1] / 100)))
            $day = [math]::Max(1, [math]::Min(31, $p[1] % 100))
            $hr  = [int]($p[2] / 100); $mn = $p[2] % 100
            $dt = [datetime]::new($p[0], $mon, $day, $hr, $mn, 0)
            return $dt.Ticks
        }
        elseif ($p.Count -eq 2) {
            # 旧式 1.22: 映射到一个很老的日期, 保证任何日期版本都更新; 旧版之间用 version 比较
            $ver = [version]::new($p[0], $p[1])
            return ([datetime]::new(1900 + $ver.Major, [math]::Max(1, ($ver.Minor % 12) + 1), 1)).Ticks
        }
    } catch { }
    return 0
}

function Test-UpdateAvailable {
    param([string]$Url)
    $vi = Get-RemoteVersionInfo $Url
    # 用 [datetime] Ticks 比较, 兼容日期格式与旧式 1.xx
    if ($vi -and $vi.version -and (Get-VersionKey $vi.version) -gt (Get-VersionKey $script:AppVersion)) {
        return $vi
    }
    return $null
}

function Invoke-ApplyUpdate {
    # 后台静默下载+应用更新, 应用完成后由 update.ps1 拉起新版, 当前实例退出(释放单实例锁)
    $script:lblStatus.Text = '正在下载并应用更新…（后台，无窗口）'
    $arg = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\update.ps1`"" +
           " -CurrentVersion $($script:AppVersion) -UpdateUrl `"$($script:updateUrl)`"" +
           " -InstallDir `"$root`" -Restart -OldPid $pid"
    Start-Process -FilePath 'powershell.exe' -ArgumentList $arg -WindowStyle Hidden
    $global:forceExit = $true
    try { if ($notifyIcon) { $notifyIcon.Icon = $null; $notifyIcon.Dispose() } } catch { }
    Dispose-BandIcons
    $form.Close()
}

# 内存大户 Top 视图 (最有用的诊断之一: 看谁在吃内存)
function Show-MemHogs {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = '内存大户 (Top 进程)'
    $dlg.Size = New-Object System.Drawing.Size(460, 430)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.Icon = $script:appIcon
    $dlg.Owner = $form
    $lv = New-Object System.Windows.Forms.ListView
    $lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.GridLines = $true; $lv.HeaderStyle = 'Nonclickable'
    $lv.Location = New-Object System.Drawing.Point(12, 12); $lv.Size = New-Object System.Drawing.Size(424, 350)
    $lv.Columns.Add('进程', 150) | Out-Null
    $lv.Columns.Add('PID', 64) | Out-Null
    $lv.Columns.Add('私有_MB', 100) | Out-Null
    $lv.Columns.Add('工作集_MB', 100) | Out-Null
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(346, 374); $btnClose.Size = New-Object System.Drawing.Size(90, 28)
    $dlg.Controls.AddRange(@($lv, $btnClose))
    try {
        $procs = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -ne 'Idle' } |
            Sort-Object { $_.PrivateMemorySize64 } -Descending | Select-Object -First 15
        foreach ($p in $procs) {
            $it = New-Object System.Windows.Forms.ListViewItem($p.ProcessName)
            $it.SubItems.Add([string]$p.Id) | Out-Null
            $it.SubItems.Add([math]::Round($p.PrivateMemorySize64 / 1MB, 1)) | Out-Null
            $it.SubItems.Add([math]::Round($p.WorkingSet64 / 1MB, 1)) | Out-Null
            $lv.Items.Add($it) | Out-Null
        }
    } catch { }
    $btnClose.Add_Click({ $dlg.Close() })
    $dlg.ShowDialog() | Out-Null
}

# 内存诊断: 分析"为什么占这么多"——按进程类别(浏览器 / WorkBuddy 会话 / 预热带 / 杀毒等)分类并给出结论
function Show-MemDiag {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = '内存诊断 · 为什么占这么多'
    $dlg.Size = New-Object System.Drawing.Size(620, 520)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.Icon = $script:appIcon
    $dlg.Owner = $form

    $lblSum = New-Object System.Windows.Forms.Label
    $lblSum.Location = New-Object System.Drawing.Point(12, 10)
    $lblSum.Size = New-Object System.Drawing.Size(584, 38)
    $lblSum.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $dlg.Controls.Add($lblSum)

    $lv = New-Object System.Windows.Forms.ListView
    $lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.GridLines = $true; $lv.HeaderStyle = 'Nonclickable'
    $lv.Location = New-Object System.Drawing.Point(12, 54); $lv.Size = New-Object System.Drawing.Size(584, 296)
    $lv.Columns.Add('进程', 150) | Out-Null
    $lv.Columns.Add('PID', 64) | Out-Null
    $lv.Columns.Add('工作集_MB', 92) | Out-Null
    $lv.Columns.Add('私有_MB', 92) | Out-Null
    $lv.Columns.Add('类别', 174) | Out-Null
    $dlg.Controls.Add($lv)

    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Location = New-Object System.Drawing.Point(12, 358)
    $tb.Size = New-Object System.Drawing.Size(584, 86)
    $tb.Multiline = $true; $tb.ScrollBars = 'Vertical'; $tb.ReadOnly = $true
    $tb.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $dlg.Controls.Add($tb)

    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(506, 452); $btnClose.Size = New-Object System.Drawing.Size(90, 28)
    $dlg.Controls.Add($btnClose)

    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        $total = $os.TotalVisibleMemorySize; $free = $os.FreePhysicalMemory
        $pct = [math]::Round(($total - $free) / $total * 100, 1)
        $lblSum.Text = ('内存: 已用 {0}GB / 共 {1}GB ({2}%)，剩余 {3}GB' -f [math]::Round(($total-$free)/1MB,1), [math]::Round($total/1MB,1), $pct, [math]::Round($free/1MB,1))
        $lblSum.ForeColor = if ($pct -ge 85) { [System.Drawing.Color]::FromArgb(200,60,60) } else { [System.Drawing.Color]::FromArgb(40,120,60) }

        $cim = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue
        $wb = $cim | Where-Object { $_.Name -like 'WorkBuddy*' }
        $wbSet = @{}; foreach ($w in $wb) { $wbSet[$w.ProcessId] = $w }
        $notes = @()

        $procs = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -ne 'Idle' -and $_.WorkingSet64 -gt 0 } |
            Sort-Object { $_.WorkingSet64 } -Descending | Select-Object -First 22
        foreach ($p in $procs) {
            $role = '应用'
            if ($p.ProcessName -like 'WorkBuddy*' -and $wbSet.ContainsKey($p.Id)) {
                $cmd = $wbSet[$p.Id].CommandLine
                if ($cmd -match '--type=renderer') { $role = 'WB·渲染(会话UI)' }
                elseif ($cmd -match '--type=gpu-process') { $role = 'WB·GPU' }
                elseif ($cmd -match '--type=utility') { $role = 'WB·工具进程' }
                elseif ($cmd -match '--type=zygote') { $role = 'WB·Zygote' }
                elseif ($cmd -match '--type=crashpad') { $role = 'WB·崩溃报告' }
                elseif ($cmd -match '--prewarm') { $role = 'WB·预热带(可清)' }
                elseif ($cmd -match 'daemon-app-server') { $role = 'WB·后端' }
                else { $role = 'WB·主/会话进程' }
            } elseif ($p.ProcessName -match '^(msedge|chrome|brave|firefox|iexplore)') { $role = '浏览器' }
            elseif ($p.ProcessName -match '^(MsMpEng|MsSense|Antimalware)') { $role = '杀毒/防护' }
            else { $role = '应用' }

            $it = New-Object System.Windows.Forms.ListViewItem($p.ProcessName)
            $it.SubItems.Add([string]$p.Id) | Out-Null
            $it.SubItems.Add([math]::Round($p.WorkingSet64 / 1MB, 1)) | Out-Null
            $it.SubItems.Add([math]::Round($p.PrivateMemorySize64 / 1MB, 1)) | Out-Null
            $it.SubItems.Add($role) | Out-Null
            $lv.Items.Add($it) | Out-Null
        }

        $wbTotal = ($wb | Measure-Object WorkingSetSize -Sum).Sum
        $notes += ('• WorkBuddy 共 {0} 个进程，占用约 {1}GB。' -f $wb.Count, [math]::Round($wbTotal/1GB,2))
        $pre = $wb | Where-Object { $_.CommandLine -match '--prewarm' }
        if ($pre.Count -gt 0) {
            $preMB = [math]::Round(($pre | Measure-Object WorkingSetSize -Sum).Sum / 1MB, 0)
            $notes += ('• 其中 {0} 个「预热带」约 {1}MB，是空闲缓存（daemon 按需重建），点「内存优化」或「结束进程」可释放，不影响当前会话。' -f $pre.Count, $preMB)
        }
        $notes += '• 浏览器、杀毒软件也会稳定占用数百 MB，属正常。'
        $notes += '• 若长期 >85%：减少同时打开的 WorkBuddy 会话/窗口，或考虑加内存条。'
        $tb.Text = ($notes -join "`n")
    } catch { $tb.Text = '诊断失败: ' + $_.Exception.Message }

    $btnClose.Add_Click({ $dlg.Close() })
    $dlg.ShowDialog() | Out-Null
}

# 结束进程: 进程选择器 (按内存排序), 选中后需确认再结束
function Show-ProcessKiller {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = '结束进程'
    $dlg.Size = New-Object System.Drawing.Size(460, 448)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.Icon = $script:appIcon
    $dlg.Owner = $form
    $lv = New-Object System.Windows.Forms.ListView
    $lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.GridLines = $true; $lv.HeaderStyle = 'Nonclickable'
    $lv.Location = New-Object System.Drawing.Point(12, 12); $lv.Size = New-Object System.Drawing.Size(424, 360)
    $lv.Columns.Add('进程', 150) | Out-Null
    $lv.Columns.Add('PID', 64) | Out-Null
    $lv.Columns.Add('内存_MB', 108) | Out-Null
    $btnKill = New-Object System.Windows.Forms.Button; $btnKill.Text = '结束选中'; $btnKill.Location = New-Object System.Drawing.Point(150, 380); $btnKill.Size = New-Object System.Drawing.Size(100, 28)
    $btnRefresh = New-Object System.Windows.Forms.Button; $btnRefresh.Text = '刷新'; $btnRefresh.Location = New-Object System.Drawing.Point(256, 380); $btnRefresh.Size = New-Object System.Drawing.Size(80, 28)
    $dlg.Controls.AddRange(@($lv, $btnKill, $btnRefresh))
    function Fill-Procs {
        $lv.Items.Clear()
        try {
            $procs = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -ne 'Idle' } |
                Sort-Object { $_.WorkingSet64 } -Descending | Select-Object -First 50
            foreach ($p in $procs) {
                $it = New-Object System.Windows.Forms.ListViewItem($p.ProcessName)
                $it.SubItems.Add([string]$p.Id) | Out-Null
                $it.SubItems.Add([math]::Round($p.WorkingSet64 / 1MB, 1)) | Out-Null
                $lv.Items.Add($it) | Out-Null
            }
        } catch { }
    }
    Fill-Procs
    $btnRefresh.Add_Click({ Fill-Procs })
    $btnKill.Add_Click({
        if ($lv.SelectedItems.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show('请先选中一个进程', '提示', 'OK', 'Warning'); return }
        $name = $lv.SelectedItems[0].Text
        $pid = [int]$lv.SelectedItems[0].SubItems[1].Text
        if ([System.Windows.Forms.MessageBox]::Show("确定结束进程: $name (PID $pid)？", '确认结束进程', 'YesNo', 'Warning') -eq 'Yes') {
            try { Stop-Process -Id $pid -Force -ErrorAction Stop; Fill-Procs; $script:lblStatus.Text = "已结束进程 $name (PID $pid)" }
            catch { [System.Windows.Forms.MessageBox]::Show('结束失败: ' + $_.Exception.Message, '错误', 'OK', 'Error') }
        }
    })
    $dlg.ShowDialog() | Out-Null
}

# 网络修复: 刷新 DNS 缓存; 管理员下再重置 Winsock / TCP/IP
function Repair-Network {
    $script:lblStatus.Text = '正在修复网络（刷新 DNS 缓存）…'
    try {
        ipconfig /flushdns | Out-Null
        $msg = '已刷新 DNS 缓存'
        if (Test-Admin) {
            try { netsh winsock reset | Out-Null; netsh int ip reset | Out-Null; $msg += '；已重置 Winsock 与 TCP/IP（建议重启生效）' } catch { }
        } else {
            $msg += '；重置网络栈需管理员权限（当前未以管理员运行 CleanOpt）'
        }
        $script:lblStatus.Text = $msg
        [System.Windows.Forms.MessageBox]::Show($msg, '网络修复', 'OK', 'Information')
    } catch {
        [System.Windows.Forms.MessageBox]::Show('修复失败: ' + $_.Exception.Message, '错误', 'OK', 'Error')
    }
}

# 清空剪贴板
function Clear-ClipboardSafe {
    try { [System.Windows.Forms.Clipboard]::Clear(); $script:lblStatus.Text = '剪贴板已清空' }
    catch { [System.Windows.Forms.MessageBox]::Show('清空失败: ' + $_.Exception.Message, '错误', 'OK', 'Error') }
}

# 锁屏
function Lock-WorkStation {
    try { rundll32.exe user32.dll,LockWorkStation; $script:lblStatus.Text = '已锁定屏幕' }
    catch { [System.Windows.Forms.MessageBox]::Show('锁定失败: ' + $_.Exception.Message, '错误', 'OK', 'Error') }
}

# 检查更新对话框 (当前/最新版本 + 更新说明 + 立即更新)
function Show-UpdateDialog {
    $ud = New-Object System.Windows.Forms.Form
    $ud.Text = '检查更新'
    $ud.Size = New-Object System.Drawing.Size(440, 320)
    $ud.StartPosition = 'CenterParent'
    $ud.FormBorderStyle = 'FixedDialog'
    $ud.MaximizeBox = $false; $ud.MinimizeBox = $false
    $ud.Icon = $script:appIcon
    $ud.Owner = $form
    $lblCur = New-Object System.Windows.Forms.Label; $lblCur.Location = New-Object System.Drawing.Point(12, 14); $lblCur.Size = New-Object System.Drawing.Size(400, 20)
    $lblCur.Text = "当前版本: v$($script:AppVersion)"
    $lblNew = New-Object System.Windows.Forms.Label; $lblNew.Location = New-Object System.Drawing.Point(12, 40); $lblNew.Size = New-Object System.Drawing.Size(400, 20); $lblNew.ForeColor = [System.Drawing.Color]::FromArgb(0, 110, 60)
    $tbNotes = New-Object System.Windows.Forms.TextBox; $tbNotes.Multiline = $true; $tbNotes.ReadOnly = $true; $tbNotes.ScrollBars = 'Vertical'
    $tbNotes.Location = New-Object System.Drawing.Point(12, 70); $tbNotes.Size = New-Object System.Drawing.Size(404, 160); $tbNotes.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $btnUpdate = New-Object System.Windows.Forms.Button; $btnUpdate.Text = '立即更新'; $btnUpdate.Location = New-Object System.Drawing.Point(120, 244); $btnUpdate.Size = New-Object System.Drawing.Size(90, 30)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(224, 244); $btnClose.Size = New-Object System.Drawing.Size(90, 30)
    $ud.Controls.AddRange(@($lblCur, $lblNew, $tbNotes, $btnUpdate, $btnClose))

    $vi = $null
    if ($script:updateUrl) { $vi = Test-UpdateAvailable $script:updateUrl }
    if ($vi) {
        $lblNew.Text = "发现新版本: v$($vi.version)"
        $notes = if ($vi.notes) { $vi.notes } else { '(无更新说明)' }
        $tbNotes.Text = "更新说明:`r`n$notes"
        $btnUpdate.Enabled = $true
    } else {
        $lblNew.Text = if ($script:updateUrl) { '当前已是最新版本' } else { '未配置更新源（请在“设置”中填写 version.json 地址）' }
        $tbNotes.Text = '自动更新需要配置“更新源”。`r`n将 version.json（指向 CleanOpt.zip 的地址）放到一个可访问的 URL 或本地文件夹，`r`n然后在“设置”里填写该地址即可开启自动更新。'
        $btnUpdate.Enabled = $false
    }
    $btnUpdate.Add_Click({
        if (-not $script:updateUrl) { return }
        $ud.DialogResult = 'OK'; $ud.Close()
        Invoke-ApplyUpdate
    })
    $btnClose.Add_Click({ $ud.DialogResult = 'Cancel'; $ud.Close() })
    $ud.ShowDialog() | Out-Null
}

# 还原区过期清理 (主窗口用, 读取 $script:restoreKeepDays)
function Invoke-PurgeRestore {
    try {
        $root = Join-Path $env:LOCALAPPDATA 'CleanOpt\Restore'
        if (-not (Test-Path $root)) { return }
        $cutoff = (Get-Date).AddDays(-$script:restoreKeepDays)
        Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $dt = [datetime]::ParseExact($_.Name, 'yyyyMMdd-HHmmss', $null)
                if ($dt -lt $cutoff) { $_ | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue }
            } catch { }
        }
    } catch { }
}

# 还原清理: 列出隔离区批次, 可一键还原 / 永久删除
function Show-RestoreDialog {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = '还原清理（隔离区）'
    $dlg.Size = New-Object System.Drawing.Size(560, 460)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.Icon = $script:appIcon
    $dlg.Owner = $form
    $lv = New-Object System.Windows.Forms.ListView
    $lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.GridLines = $true; $lv.HeaderStyle = 'Nonclickable'; $lv.CheckBoxes = $true
    $lv.Location = New-Object System.Drawing.Point(12, 12); $lv.Size = New-Object System.Drawing.Size(524, 330)
    $lv.Columns.Add('批次', 150) | Out-Null
    $lv.Columns.Add('清理时间', 150) | Out-Null
    $lv.Columns.Add('文件数', 70) | Out-Null
    $lv.Columns.Add('大小', 120) | Out-Null
    $btnRestoreSel = New-Object System.Windows.Forms.Button; $btnRestoreSel.Text = '还原选中'; $btnRestoreSel.Location = New-Object System.Drawing.Point(12, 354); $btnRestoreSel.Size = New-Object System.Drawing.Size(120, 28)
    $btnPurgeSel = New-Object System.Windows.Forms.Button; $btnPurgeSel.Text = '永久删除'; $btnPurgeSel.Location = New-Object System.Drawing.Point(142, 354); $btnPurgeSel.Size = New-Object System.Drawing.Size(120, 28)
    $btnRefresh = New-Object System.Windows.Forms.Button; $btnRefresh.Text = '刷新'; $btnRefresh.Location = New-Object System.Drawing.Point(272, 354); $btnRefresh.Size = New-Object System.Drawing.Size(90, 28)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(372, 354); $btnClose.Size = New-Object System.Drawing.Size(90, 28)
    $dlg.Controls.AddRange(@($lv, $btnRestoreSel, $btnPurgeSel, $btnRefresh, $btnClose))
    function Format-Bytes($n) {
        if ($n -ge 1GB) { return [math]::Round($n / 1GB, 2).ToString() + ' GB' }
        if ($n -ge 1MB) { return [math]::Round($n / 1MB, 1).ToString() + ' MB' }
        if ($n -ge 1KB) { return [math]::Round($n / 1KB, 1).ToString() + ' KB' }
        return [string]$n + ' B'
    }
    function Get-Batches {
        $root = Join-Path $env:LOCALAPPDATA 'CleanOpt\Restore'
        $list = @()
        if (Test-Path $root) {
            Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                $mPath = Join-Path $_.FullName 'manifest.json'
                $files = 0; $bytes = 0; $cleanedAt = $_.Name
                if (Test-Path $mPath) {
                    try {
                        $m = Get-Content $mPath -Raw -Encoding UTF8 | ConvertFrom-Json
                        $files = if ($m.files) { @($m.files).Count } else { 0 }
                        $bytes = if ($null -ne $m.totalBytes) { [long]$m.totalBytes } else { 0 }
                        if ($m.cleanedAt) { $cleanedAt = $m.cleanedAt }
                    } catch { }
                }
                $list += [PSCustomObject]@{ dir = $_.FullName; runId = $_.Name; cleanedAt = $cleanedAt; files = $files; bytes = $bytes }
            }
        }
        return $list | Sort-Object cleanedAt -Descending
    }
    function Refresh-Restore {
        $lv.Items.Clear()
        $global:restoreBatches = @(Get-Batches)
        foreach ($b in $global:restoreBatches) {
            $it = New-Object System.Windows.Forms.ListViewItem($b.runId)
            $it.SubItems.Add($b.cleanedAt) | Out-Null
            $it.SubItems.Add([string]$b.files) | Out-Null
            $it.SubItems.Add((Format-Bytes $b.bytes)) | Out-Null
            $it.Checked = $true
            $lv.Items.Add($it) | Out-Null
        }
        if ($lv.Items.Count -eq 0) { $script:lblStatus.Text = '隔离区为空（没有可还原的清理结果）' }
    }
    $btnRefresh.Add_Click({ Refresh-Restore })
    $btnRestoreSel.Add_Click({
        $sel = @()
        for ($i = 0; $i -lt $lv.Items.Count; $i++) { if ($lv.Items[$i].Checked) { $sel += $global:restoreBatches[$i] } }
        if ($sel.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show('请勾选要还原的批次', '提示', 'OK', 'Warning'); return }
        $total = 0; $fail = 0
        foreach ($b in $sel) {
            $mPath = Join-Path $b.dir 'manifest.json'
            if (-not (Test-Path $mPath)) { continue }
            try {
                $m = Get-Content $mPath -Raw -Encoding UTF8 | ConvertFrom-Json
                foreach ($f in @($m.files)) {
                    try {
                        if (Test-Path $f.orig) { $fail++; continue }   # 原路径已被占用, 跳过避免覆盖
                        $pd = Split-Path $f.orig -Parent
                        if ($pd -and -not (Test-Path $pd)) { New-Item -ItemType Directory -Path $pd -Force | Out-Null }
                        Move-Item -Path (Join-Path $b.dir $f.rel) -Destination $f.orig -Force -ErrorAction Stop
                        $total++
                    } catch { $fail++ }
                }
                try { if ((Get-ChildItem -Path $b.dir -Recurse -Force -ErrorAction SilentlyContinue).Count -eq 0) { Remove-Item -Path $b.dir -Recurse -Force -ErrorAction SilentlyContinue } } catch { }
            } catch { }
        }
        [System.Windows.Forms.MessageBox]::Show("已还原 $total 个文件$(if ($fail -gt 0) { '，跳过 ' + $fail + ' 个（原路径已被占用）' } else { '' })", '还原完成', 'OK', 'Information')
        Refresh-Restore
    })
    $btnPurgeSel.Add_Click({
        $sel = @()
        for ($i = 0; $i -lt $lv.Items.Count; $i++) { if ($lv.Items[$i].Checked) { $sel += $global:restoreBatches[$i] } }
        if ($sel.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show('请勾选要删除的批次', '提示', 'OK', 'Warning'); return }
        if ([System.Windows.Forms.MessageBox]::Show("确定永久删除选中的 $($sel.Count) 个批次？此操作不可还原。", '确认永久删除', 'YesNo', 'Warning') -ne 'Yes') { return }
        foreach ($b in $sel) { try { Remove-Item -Path $b.dir -Recurse -Force -ErrorAction SilentlyContinue } catch { } }
        [System.Windows.Forms.MessageBox]::Show('已永久删除选中批次', '完成', 'OK', 'Information')
        Refresh-Restore
    })
    $btnClose.Add_Click({ $dlg.Close() })
    Refresh-Restore
    $dlg.ShowDialog() | Out-Null
}

# ---- form ----
$form = New-Object System.Windows.Forms.Form
# ---- auto-on / auto-off 指示：贴在“可自动保持运行”的功能按钮右侧 ----
function Update-AutoButtons {
    $map = @(
        [PSCustomObject]@{ btn = $btnRecycle;  on = $script:dailyEmptyRecycle }
        [PSCustomObject]@{ btn = $btnUpdate;   on = ($script:autoUpdate -and $script:updateUrl) }
        [PSCustomObject]@{ btn = $btnClean;    on = $true }   # 磁盘低余量自动清理（随监控常驻）
        [PSCustomObject]@{ btn = $btnOptimize; on = $true }   # 内存紧张自动优化（随监控常驻）
    )
    foreach ($m in $map) {
        if (-not $m.btn) { continue }
        $base = if ($m.btn.Tag) { $m.btn.Tag } else { $m.btn.Text }
        $m.btn.Tag = $base
        $m.btn.Text = $base + '  [' + (if ($m.on) { 'auto-on' } else { 'auto-off' }) + ']'
    }
}

$form.Text = 'CleanOpt · 清理优化'
$form.Icon = $script:appIcon
$form.ShowIcon = $true              # v1.20: 确保任务栏显示图标（与托盘图标一致）
$form.Size = New-Object System.Drawing.Size(900, 620)
$form.StartPosition = 'CenterScreen'
$form.MinimizeBox = $true
$form.FormBorderStyle = 'Sizable'
$form.MaximizeBox = $true
$form.AutoScaleMode = 'Dpi'          # 高 DPI 自适应: 界面随系统缩放清晰渲染
$form.MinimumSize = New-Object System.Drawing.Size(760, 480)

# ---- 配色 ----
$script:cSide   = [System.Drawing.Color]::FromArgb(38, 50, 66)    # 侧栏深色
$script:cSideHi = [System.Drawing.Color]::FromArgb(60, 80, 104)   # 选中高亮
$script:cBg     = [System.Drawing.Color]::FromArgb(247, 249, 251) # 内容背景
$script:cPanel  = [System.Drawing.Color]::FromArgb(255, 255, 255)
$script:cAccent = [System.Drawing.Color]::FromArgb(0, 120, 215)   # 主色蓝
$script:cGray   = [System.Drawing.Color]::FromArgb(120, 130, 140)
$script:cGreen  = [System.Drawing.Color]::FromArgb(0, 120, 60)

# ---- v2026.0919.2200: 圆角 / 双缓冲 绘制辅助（必须定义在任何调用之前，否则脚本启动即中断）----
function Set-Rounded {
    param($ctrl, [int]$radius = 10)
    if ($null -eq $ctrl) { return }
    try {
        $w = [int]$ctrl.Width; $h = [int]$ctrl.Height
        if ($w -le 0 -or $h -le 0) { return }
        $d = [int]($radius * 2)
        if ($d -gt $w) { $d = $w }
        if ($d -gt $h) { $d = $h }
        $gp = New-Object System.Drawing.Drawing2D.GraphicsPath
        $gp.AddArc(0, 0, $d, $d, 180, 90)
        $gp.AddArc(($w - $d - 1), 0, $d, $d, 270, 90)
        $gp.AddArc(($w - $d - 1), ($h - $d - 1), $d, $d, 0, 90)
        $gp.AddArc(0, ($h - $d - 1), $d, $d, 90, 90)
        $gp.CloseFigure()
        $ctrl.Region = New-Object System.Drawing.Region($gp)
        $gp.Dispose()
    } catch { }
}

function Enable-DoubleBuffer {
    param($ctrl)
    if ($null -eq $ctrl) { return }
    try {
        $fl = [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic -bor [System.Reflection.BindingFlags]::Public
        $prop = $ctrl.GetType().GetProperty('DoubleBuffered', $fl)
        if ($prop) { $prop.SetValue($ctrl, $true, $null) }
    } catch { }
}

# 工具提示: 提升可发现性
$script:tipMain = New-Object System.Windows.Forms.ToolTip
$script:tipMain.AutoPopDelay = 4000
$script:tipMain.InitialDelay = 300

# 统一按钮样式 + 悬停高亮 + 工具提示
function New-ActionButton {
    param([string]$Text, [int]$X, [int]$Y, [string]$Tip)
    $b = New-Object System.Windows.Forms.Button
    $b.Location = New-Object System.Drawing.Point($X, $Y)
    $b.Size = New-Object System.Drawing.Size(200, 36)
    $b.Text = $Text
    $b.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 0
    $b.BackColor = [System.Drawing.Color]::FromArgb(244, 247, 250)
    $b.UseVisualStyleBackColor = $false
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $b.Anchor = if ($X -ge 236) { 'Top, Right' } else { 'Top, Left' }
    if ($Tip) { $script:tipMain.SetToolTip($b, $Tip) }
    $b.Add_MouseEnter({ param($s, $e) $s.BackColor = [System.Drawing.Color]::FromArgb(222, 234, 246) })
    $b.Add_MouseLeave({ param($s, $e) $s.BackColor = [System.Drawing.Color]::FromArgb(244, 247, 250) })
    Set-Rounded $b 18
    return $b
}

# 分组标题 (页面内)
function New-SectionHeader {
    param([string]$Text, [int]$Y)
    $h = New-Object System.Windows.Forms.Label
    $h.Text = $Text
    # v1.20: X 改为 0（pnlContent 已提供 16px Padding，合计足够边距）
    $h.Location = New-Object System.Drawing.Point(0, $Y)
    $h.Size = New-Object System.Drawing.Size(640, 20)
    $h.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
    $h.ForeColor = [System.Drawing.Color]::FromArgb(0, 90, 160)
    return $h
}

# 页面内按钮（左上锚定）
function New-PageButton {
    param([string]$Text, [int]$X, [int]$Y, [int]$W = 200, [string]$Tip = '')
    $b = New-ActionButton $Text $X $Y $Tip
    $b.Size = New-Object System.Drawing.Size($W, 36)
    $b.Anchor = 'Top, Left'
    return $b
}

# 白底卡片容器: 统一分区视觉（浅边框 + 可选标题），内部控件用相对坐标 (12, 标题高 起)
function New-Card {
    param([string]$Title, [int]$X, [int]$Y, [int]$W, [int]$H)
    $c = New-Object System.Windows.Forms.Panel
    $c.Location = New-Object System.Drawing.Point($X, $Y)
    $c.Size = New-Object System.Drawing.Size($W, $H)
    $c.BackColor = $script:cPanel
    $c.BorderStyle = 'None'
    Enable-DoubleBuffer $c
    Set-Rounded $c 10
    $c.Add_Paint({
        param($s, $e)
        try {
            $g = $e.Graphics
            $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $d = 20
            $w = $s.Width - 1; $h = $s.Height - 1
            if ($w -le $d -or $h -le $d) { return }
            $gp = New-Object System.Drawing.Drawing2D.GraphicsPath
            $gp.AddArc(0, 0, $d, $d, 180, 90)
            $gp.AddArc(($w - $d), 0, $d, $d, 270, 90)
            $gp.AddArc(($w - $d), ($h - $d), $d, $d, 0, 90)
            $gp.AddArc(0, ($h - $d), $d, $d, 90, 90)
            $gp.CloseFigure()
            $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(224, 228, 234), 1)
            $g.DrawPath($pen, $gp)
            $pen.Dispose(); $gp.Dispose()
        } catch { }
    })
    if ($Title) {
        $ct = New-Object System.Windows.Forms.Label
        $ct.Text = $Title
        $ct.Location = New-Object System.Drawing.Point(12, 8)
        $ct.Size = New-Object System.Drawing.Size($W - 24, 20)
        $ct.Font = New-Object System.Drawing.Font('Segoe UI', 10.5, [System.Drawing.FontStyle]::Bold)
        $ct.ForeColor = [System.Drawing.Color]::FromArgb(0, 90, 160)
        $c.Controls.Add($ct)
    }
    return $c
}

# ===== 框架: 左侧导航 + 顶部仪表 + 底部状态 + 右侧内容 =====
$pnlSide = New-Object System.Windows.Forms.Panel
$pnlSide.Dock = 'Left'
$pnlSide.Width = 152
$pnlSide.BackColor = $script:cSide
$pnlSide.Padding = New-Object System.Windows.Forms.Padding(0, 10, 0, 0)

$pnlHeader = New-Object System.Windows.Forms.Panel
$pnlHeader.Dock = 'Top'
$pnlHeader.Height = 92
$pnlHeader.BackColor = $script:cPanel
$pnlHeader.BorderStyle = 'FixedSingle'

$pnlStatus = New-Object System.Windows.Forms.Panel
$pnlStatus.Dock = 'Bottom'
$pnlStatus.Height = 26
$pnlStatus.BackColor = [System.Drawing.Color]::FromArgb(240, 242, 245)
$pnlStatus.BorderStyle = 'FixedSingle'
$script:lblStatus = New-Object System.Windows.Forms.Label
$script:lblStatus.Dock = 'Fill'
$script:lblStatus.Text = '就绪'
$script:lblStatus.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$script:lblStatus.ForeColor = $script:cGreen
$script:lblStatus.TextAlign = 'MiddleLeft'
$script:lblStatus.Padding = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
$pnlStatus.Controls.Add($script:lblStatus)
$lblVer = New-Object System.Windows.Forms.Label
$lblVer.Text = "v$script:AppVersion"
$lblVer.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$lblVer.ForeColor = $script:cGray
$lblVer.Anchor = 'Top, Right'
$lblVer.Location = New-Object System.Drawing.Point(0, 5)
$lblVer.AutoSize = $true
$pnlStatus.Controls.Add($lblVer)

$pnlContent = New-Object System.Windows.Forms.Panel
$pnlContent.Dock = 'Fill'
$pnlContent.BackColor = $script:cBg
# v1.19: 给内容区加内边距，确保所有页面内容不贴边、不被导航栏遮挡
$pnlContent.Padding = New-Object System.Windows.Forms.Padding(16, 12, 12, 12)

# ---- 顶部仪表 (内存 + 磁盘) ----
$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = 'CleanOpt · 清理优化'
$lblTitle.Location = New-Object System.Drawing.Point(12, 8)
$lblTitle.Size = New-Object System.Drawing.Size(360, 22)
$lblTitle.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
$lblTitle.ForeColor = [System.Drawing.Color]::FromArgb(20, 40, 70)

$script:pbRam = New-Object System.Windows.Forms.ProgressBar
$script:pbRam.Location = New-Object System.Drawing.Point(12, 38)
$script:pbRam.Size = New-Object System.Drawing.Size(340, 14)
$script:pbRam.Minimum = 0; $script:pbRam.Maximum = 100; $script:pbRam.Value = 0
$script:pbRam.Style = 'Continuous'
# v1.22: 禁用 Visual Styles 使 ForeColor 生效（Windows Vista+ 默认忽略 ProgressBar.ForeColor）
$script:pbRam.ForeColor = $script:cAccent

$script:lblRam = New-Object System.Windows.Forms.Label
$script:lblRam.Location = New-Object System.Drawing.Point(12, 54)
$script:lblRam.Size = New-Object System.Drawing.Size(340, 18)
$script:lblRam.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)

$script:pbDisk = New-Object System.Windows.Forms.ProgressBar
$script:pbDisk.Location = New-Object System.Drawing.Point(372, 38)
$script:pbDisk.Size = New-Object System.Drawing.Size(320, 14)
$script:pbDisk.Minimum = 0; $script:pbDisk.Maximum = 100; $script:pbDisk.Value = 0
$script:pbDisk.Style = 'Continuous'
# v1.21: 进度条默认蓝色
$script:pbDisk.ForeColor = $script:cAccent

$script:lblDisk = New-Object System.Windows.Forms.Label
$script:lblDisk.Location = New-Object System.Drawing.Point(372, 54)
$script:lblDisk.Size = New-Object System.Drawing.Size(320, 18)
$script:lblDisk.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)

$script:lblClean = New-Object System.Windows.Forms.Label
$script:lblClean.Location = New-Object System.Drawing.Point(12, 74)
$script:lblClean.Size = New-Object System.Drawing.Size(360, 16)
$script:lblClean.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$script:lblClean.ForeColor = $script:cGray

$script:lblOpt = New-Object System.Windows.Forms.Label
$script:lblOpt.Location = New-Object System.Drawing.Point(372, 74)
$script:lblOpt.Size = New-Object System.Drawing.Size(320, 16)
$script:lblOpt.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$script:lblOpt.ForeColor = $script:cGray

$pnlHeader.Controls.AddRange(@($lblTitle, $script:pbRam, $script:lblRam, $script:pbDisk, $script:lblDisk, $script:lblClean, $script:lblOpt))

# ---- 页面容器 ----
$script:pagePanels = @{}
function New-Page {
    param([string]$Key)
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'
    $p.AutoScroll = $true
    $p.BackColor = $script:cBg
    $p.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
    $p.Visible = $false
    $script:pagePanels[$Key] = $p
    $pnlContent.Controls.Add($p)
    return $p
}
$pnlHome     = New-Page 'home'
$pnlClean    = New-Page 'clean'
$pnlMemory   = New-Page 'memory'
$pnlStartup  = New-Page 'startup'
$pnlPrivacy  = New-Page 'privacy'
$pnlTools    = New-Page 'tools'
$pnlUninstall = New-Page 'uninstall'
$pnlBigFiles  = New-Page 'bigfiles'
$pnlSettings = New-Page 'settings'
$pnlCache   = New-Page 'cache'
$pnlHistory = New-Page 'history'

# ---- 左侧导航 ----
$script:navBtns = @{}
$navDefs = @(
    @{ key='home';      name='首   页';     group='' }
    @{ key='clean';     name='垃 圾 清 理'; group='清理优化' }
    @{ key='cache';     name='缓 存 清 理'; group='' }
    @{ key='memory';    name='内 存 优 化'; group='' }
    @{ key='startup';   name='启 动 项';     group='系统工具' }
    @{ key='privacy';   name='隐 私 痕 迹'; group='' }
    @{ key='history';   name='历 史 记 录'; group='' }
    @{ key='uninstall'; name='强 力 卸 载'; group='' }
    @{ key='bigfiles';  name='大 文 件';     group='' }
    @{ key='tools';     name='工 具 箱';     group='' }
    @{ key='settings';  name='设   置';      group='' }
)
$navY = 8
$lastGroup = $null
foreach ($nd in $navDefs) {
    # 分组标题: 用不可点 label 分隔, 提升导航层次感
    if ($nd.group -and $nd.group -ne $lastGroup) {
        $gh = New-Object System.Windows.Forms.Label
        $gh.Text = $nd.group
        $gh.Location = New-Object System.Drawing.Point(14, $navY)
        $gh.Size = New-Object System.Drawing.Size(124, 16)
        $gh.Font = New-Object System.Drawing.Font('Segoe UI', 8, [System.Drawing.FontStyle]::Bold)
        $gh.ForeColor = [System.Drawing.Color]::FromArgb(120, 138, 160)
        $pnlSide.Controls.Add($gh)
        $navY += 20
        $lastGroup = $nd.group
    }
    $nb = New-Object System.Windows.Forms.Button
    $nb.Text = $nd.name
    $nb.Location = New-Object System.Drawing.Point(8, $navY)
    $nb.Size = New-Object System.Drawing.Size(136, 38)
    $nb.FlatStyle = 'Flat'
    $nb.FlatAppearance.BorderSize = 0
    $nb.BackColor = $script:cSide
    $nb.ForeColor = [System.Drawing.Color]::FromArgb(200, 210, 222)
    $nb.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $nb.Cursor = [System.Windows.Forms.Cursors]::Hand
    $nb.Tag = $nd.key
    $nb.Add_Click({ param($s, $e) Show-Page $s.Tag })
    # 悬停高亮（仅非选中态变浅，选中态保持高亮）
    $nb.Add_MouseEnter({ param($s, $e) if ($s.Tag -ne $script:_curPage) { $s.BackColor = $script:cSideHi } })
    $nb.Add_MouseLeave({ param($s, $e) if ($s.Tag -ne $script:_curPage) { $s.BackColor = $script:cSide } })
    Set-Rounded $nb 19
    $script:navBtns[$nd.key] = $nb
    $pnlSide.Controls.Add($nb)
    $navY += 42
}
function Show-Page {
    param([string]$Key)
    $script:_curPage = $Key
    foreach ($kv in $script:pagePanels.GetEnumerator()) {
        $kv.Value.Visible = ($kv.Key -eq $Key)
        # v1.20: 用 BeginInvoke 确保滚动重置在 Handle 创建后的消息循环中执行
        if ($kv.Key -eq $Key) {
            $targetPanel = $kv.Value
            $targetPanel.BeginInvoke({
                $targetPanel.AutoScrollPosition = New-Object System.Drawing.Point(0, 0)
            })
            # 切到首页时刷新运行概况卡片
            if ($Key -eq 'home') { $targetPanel.BeginInvoke({ Refresh-HomeStat }) }
            # 切到缓存/历史页时重新检测已装软件与可清理项
            if ($Key -eq 'cache' -or $Key -eq 'history') { $targetPanel.BeginInvoke({ Refresh-Targets }) }
        }
    }
    foreach ($kv in $script:navBtns.GetEnumerator()) {
        $sel = ($kv.Key -eq $Key)
        $kv.Value.BackColor = if ($sel) { $script:cAccent } else { $script:cSide }
        $kv.Value.ForeColor = if ($sel) { [System.Drawing.Color]::White } else { [System.Drawing.Color]::FromArgb(200, 210, 222) }
        $kv.Value.Font = New-Object System.Drawing.Font('Segoe UI', 10, $(if ($sel) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }))
    }
}

# ===== 首页 =====
# v1.19 彻底修复: pnlContent 已设 Padding(16,12,12,12)，所有页面自动获得内边距
# 首页关闭 AutoScroll（内容少无需滚动），用相对坐标定位
$pnlHome.AutoScroll = $false
$pnlHome.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$mx = 16   # 内容区内左边距（pnlContent 已提供 16px Padding，合计 ~32px 从内容区边缘）
$my = 8    # 内容区内上边距

$lblHome = New-Object System.Windows.Forms.Label
$lblHome.Text = '欢迎使用 CleanOpt · 一键清理优化，清理结果可安全还原'
$lblHome.Location = New-Object System.Drawing.Point($mx, $my)
$lblHome.Size = New-Object System.Drawing.Size(620, 28)
$lblHome.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
$lblHome.ForeColor = [System.Drawing.Color]::FromArgb(20, 40, 70)
$pnlHome.Controls.Add($lblHome)

# 一键全面优化（主按钮，醒目）—— v1.22: 用 Panel+Label 自绘，避免 Button 渲染兼容性问题
$pnlRunAll = New-Object System.Windows.Forms.Panel
$pnlRunAll.Location = New-Object System.Drawing.Point($mx, $my + 38)
$pnlRunAll.Size = New-Object System.Drawing.Size(620, 52)
$pnlRunAll.BackColor = $script:cAccent
$pnlRunAll.Cursor = [System.Windows.Forms.Cursors]::Hand
$pnlRunAll.Anchor = 'Top, Left, Right'
Set-Rounded $pnlRunAll 14

$lblRunAll = New-Object System.Windows.Forms.Label
$lblRunAll.Text = '一键全面优化'
$lblRunAll.Location = New-Object System.Drawing.Point(0, 0)
$lblRunAll.Size = New-Object System.Drawing.Size(620, 52)
$lblRunAll.Font = New-Object System.Drawing.Font('Segoe UI', 13, [System.Drawing.FontStyle]::Bold)
$lblRunAll.ForeColor = [System.Drawing.Color]::White
$lblRunAll.TextAlign = 'MiddleCenter'
$lblRunAll.Cursor = [System.Windows.Forms.Cursors]::Hand
$pnlRunAll.Controls.Add($lblRunAll)

# 悬停效果
$pnlRunAll.Add_MouseEnter({ param($s, $e) $s.BackColor = [System.Drawing.Color]::FromArgb(0, 100, 185) })
$pnlRunAll.Add_MouseLeave({ param($s, $e) $s.BackColor = $script:cAccent })
$pnlRunAll.Add_Click({ Invoke-RunAll })
$lblRunAll.Add_Click({ Invoke-RunAll })
$pnlHome.Controls.Add($pnlRunAll)
# 确保大按钮在最上层
$pnlRunAll.BringToFront()

# 分隔说明
$lblHomeSub = New-Object System.Windows.Forms.Label
$lblHomeSub.Text = '清理垃圾 + 优化内存 + 清空回收站（后台执行，可还原）'
$lblHomeSub.Location = New-Object System.Drawing.Point($mx, $my + 96)
$lblHomeSub.Size = New-Object System.Drawing.Size(620, 18)
$lblHomeSub.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$lblHomeSub.ForeColor = $script:cGray
$pnlHome.Controls.Add($lblHomeSub)

# 四个操作按钮 (2×2 网格)
$row3 = $my + 128
$btnClean    = New-PageButton '立即清理垃圾'   $mx $row3 296 '清理系统垃圾（后台无窗口）'
$btnOptimize = New-PageButton '立即优化内存' ($mx + 308) $row3 296 '强力优化内存占用（后台无窗口）'
$row4 = $my + 172
$btnRecycle  = New-PageButton '清空回收站'     $mx $row4 296 '清空系统回收站'
$btnRestore  = New-PageButton '还原清理'       ($mx + 308) $row4 296 '查看并一键还原被隔离的清理结果'
$pnlHome.Controls.AddRange(@($btnClean, $btnOptimize, $btnRecycle, $btnRestore))

# 安全提示
$lblHomeNote = New-Object System.Windows.Forms.Label
$lblHomeNote.Text = '安全机制：默认开启「清理结果可还原」，删除前移入隔离区，可随时一键还原。'
$lblHomeNote.Location = New-Object System.Drawing.Point($mx, $my + 218)
$lblHomeNote.Size = New-Object System.Drawing.Size(620, 36)
$lblHomeNote.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$lblHomeNote.ForeColor = $script:cGray
$pnlHome.Controls.Add($lblHomeNote)

# 运行概况卡片（一眼可见的上次清理 / 累计释放 / 上次优化）
$cardStat = New-Card -Title '运行概况' -X $mx -Y ($my + 270) -W 620 -H 96
$lblStatLast = New-Object System.Windows.Forms.Label
$lblStatLast.Location = New-Object System.Drawing.Point(12, 34); $lblStatLast.Size = New-Object System.Drawing.Size(584, 18)
$lblStatLast.Font = New-Object System.Drawing.Font('Segoe UI', 9.5); $lblStatLast.ForeColor = $script:cGray
$lblStatFreed = New-Object System.Windows.Forms.Label
$lblStatFreed.Location = New-Object System.Drawing.Point(12, 58); $lblStatFreed.Size = New-Object System.Drawing.Size(584, 18)
$lblStatFreed.Font = New-Object System.Drawing.Font('Segoe UI', 9.5); $lblStatFreed.ForeColor = $script:cGray
$lblStatOpt = New-Object System.Windows.Forms.Label
$lblStatOpt.Location = New-Object System.Drawing.Point(12, 82); $lblStatOpt.Size = New-Object System.Drawing.Size(584, 18)
$lblStatOpt.Font = New-Object System.Drawing.Font('Segoe UI', 9.5); $lblStatOpt.ForeColor = $script:cGray
$cardStat.Controls.AddRange(@($lblStatLast, $lblStatFreed, $lblStatOpt))
$pnlHome.Controls.Add($cardStat)

function Refresh-HomeStat {
    try {
        $st = Get-CleanStat
        $lblStatLast.Text  = if ($st -and $st.lastRun) { "上次清理: $($st.lastRun)" } else { '上次清理: 从未' }
        $lblStatFreed.Text = if ($st -and $st.freedBytes) { "累计释放空间: $(Format-Bytes ([long]$st.freedBytes))" } else { '累计释放空间: 暂无数据' }
        $opt = if ($script:_lastAutoOptimize) { $script:_lastAutoOptimize.ToString('MM-dd HH:mm') } else { '尚未自动优化' }
        $lblStatOpt.Text = "上次自动优化: $opt"
    } catch { }
}

# ===== 垃圾清理页（扫描 → 选择 → 执行）=====
$pnlClean.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$cx = 20; $cy = 10
$hClean = New-SectionHeader '垃圾清理（先扫描，勾选后执行）' $cy
$pnlClean.Controls.Add($hClean)
$btnScan = New-PageButton '扫描垃圾' $cx ($cy + 30) 150 '扫描各安全目录的垃圾体积'
$btnExecClean = New-PageButton '执行清理（已勾选）' ($cx + 162) ($cy + 30) 210 '将勾选项移入隔离区后删除（可还原）'
$btnExecClean.Enabled = $false
$btnCustomRules = New-PageButton '自定义规则…' ($cx + 384) ($cy + 30) 150 '管理自定义清理路径/通配符（清理时一并处理）'
$pnlClean.Controls.AddRange(@($btnScan, $btnExecClean, $btnCustomRules))
$lblCustomNote = New-Object System.Windows.Forms.Label
$lblCustomNote.Location = New-Object System.Drawing.Point($cx, $cy + 448)
$lblCustomNote.Size = New-Object System.Drawing.Size(640, 30)
$lblCustomNote.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$lblCustomNote.ForeColor = $script:cGray
$lblCustomNote.Text = '可在「自定义规则…」中添加任意路径或通配符（如 C:\Temp 或 D:\Build\*.tmp），清理时一并处理并走隔离（可还原）。'
$pnlClean.Controls.Add($lblCustomNote)

$lvScan = New-Object System.Windows.Forms.ListView
$lvScan.Location = New-Object System.Drawing.Point($cx, $cy + 78)
$lvScan.Size = New-Object System.Drawing.Size(640, 300)
$lvScan.View = 'Details'
$lvScan.FullRowSelect = $true
$lvScan.CheckBoxes = $true
$lvScan.GridLines = $true
$lvScan.Columns.Add('类别', 220) | Out-Null
$lvScan.Columns.Add('预估可清理', 145) | Out-Null
$lvScan.Columns.Add('文件数', 95) | Out-Null
$lvScan.Columns.Add('说明', 170) | Out-Null
$pnlClean.Controls.Add($lvScan)

$lblScanInfo = New-Object System.Windows.Forms.Label
$lblScanInfo.Location = New-Object System.Drawing.Point($cx, $cy + 388)
$lblScanInfo.Size = New-Object System.Drawing.Size(640, 50)
$lblScanInfo.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$lblScanInfo.ForeColor = $script:cGray
$lblScanInfo.Text = '仅清理绝对安全的临时/缓存目录（系统+用户 TEMP、Prefetch、缩略图缓存、Delivery Optimization、浏览器缓存）。执行前会先移入隔离区，可一键还原。'
$pnlClean.Controls.Add($lblScanInfo)

# ===== 内存页 =====
$pnlMemory.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$hMem = New-SectionHeader '内存优化' 10
$pnlMemory.Controls.Add($hMem)
$btnMemOpt = New-PageButton '立即优化内存' 18 38 200 '强力优化内存占用（后台无窗口）'
$btnMem = New-PageButton '内存大户' 238 38 200 '查看占用内存最多的前 15 个进程'
$pnlMemory.Controls.AddRange(@($btnMemOpt, $btnMem))
$lblMemNote = New-Object System.Windows.Forms.Label
$lblMemNote.Location = New-Object System.Drawing.Point(18, 90)
$lblMemNote.Size = New-Object System.Drawing.Size(640, 60)
$lblMemNote.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$lblMemNote.ForeColor = $script:cGray
$lblMemNote.Text = "后台监控：当内存占用超过阈值（当前 $RamPressureUsedPct%）且系统空闲时，自动静默优化。游戏/全屏免打扰开启时自动跳过。"
$pnlMemory.Controls.Add($lblMemNote)

# ===== 启动项页 =====
$pnlStartup.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$hStart = New-SectionHeader '启动项管理' 10
$pnlStartup.Controls.Add($hStart)
$btnStartup = New-PageButton '管理启动项' 18 38 220 '查看并禁用/启用开机启动项（注册表/启动文件夹/计划任务）'
$pnlStartup.Controls.Add($btnStartup)
$lblStartNote = New-Object System.Windows.Forms.Label
$lblStartNote.Location = New-Object System.Drawing.Point(18, 90)
$lblStartNote.Size = New-Object System.Drawing.Size(640, 60)
$lblStartNote.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$lblStartNote.ForeColor = $script:cGray
$lblStartNote.Text = '禁用不必要的启动项可加快开机速度。禁用项会被备份，可随时恢复。'
$pnlStartup.Controls.Add($lblStartNote)

# ===== 隐私页 =====
$pnlPrivacy.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$hPriv = New-SectionHeader '隐私痕迹清理' 10
$pnlPrivacy.Controls.Add($hPriv)
$btnPrivacy = New-PageButton '清理隐私痕迹' 18 38 220 '清理最近使用/跳转列表/运行记录（可设随常规清理自动执行）'
$pnlPrivacy.Controls.Add($btnPrivacy)
$chkPrivacyAuto = New-Object System.Windows.Forms.CheckBox
$chkPrivacyAuto.Location = New-Object System.Drawing.Point(18, 90)
$chkPrivacyAuto.Size = New-Object System.Drawing.Size(440, 24)
$chkPrivacyAuto.Text = '随常规清理自动执行隐私痕迹清理'
$chkPrivacyAuto.Checked = $script:privacyClean
$chkPrivacyAuto.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$pnlPrivacy.Controls.Add($chkPrivacyAuto)
$lblPrivNote = New-Object System.Windows.Forms.Label
$lblPrivNote.Location = New-Object System.Drawing.Point(18, 122)
$lblPrivNote.Size = New-Object System.Drawing.Size(640, 60)
$lblPrivNote.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$lblPrivNote.ForeColor = $script:cGray
$lblPrivNote.Text = '仅清除使用痕迹（最近文档、跳转列表、运行记录），不删除任何用户文件；开启还原时同样先隔离。'
$pnlPrivacy.Controls.Add($lblPrivNote)

# ===== 缓存清理页 =====
$pnlCache.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$hCache = New-SectionHeader '缓存清理' 10
$pnlCache.Controls.Add($hCache)
$lblCacheNote = New-Object System.Windows.Forms.Label
$lblCacheNote.Location = New-Object System.Drawing.Point(18, 38)
$lblCacheNote.Size = New-Object System.Drawing.Size(660, 36)
$lblCacheNote.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$lblCacheNote.ForeColor = $script:cGray
$lblCacheNote.Text = '勾选要清理的应用缓存（缓存可自动再生，删除安全）。按“软件·账号·类型”列出，并附估算大小。'
$pnlCache.Controls.Add($lblCacheNote)
$btnCacheRefresh = New-PageButton '刷 新' 18 82 90 '重新检测已装软件与缓存大小'
$btnCacheAll = New-PageButton '全 选' 118 82 90 '勾选全部缓存项'
$btnCacheNone = New-PageButton '全 不 选' 218 82 110 '取消全部勾选'
$btnCacheClean = New-PageButton '清理选中缓存' 430 82 220 '删除勾选的缓存目录（后台执行）'
$btnCacheClean.BackColor = $script:cAccent; $btnCacheClean.ForeColor = [System.Drawing.Color]::White
$pnlCache.Controls.AddRange(@($btnCacheRefresh, $btnCacheAll, $btnCacheNone, $btnCacheClean))
$clbCache = New-Object System.Windows.Forms.CheckedListBox
$clbCache.Location = New-Object System.Drawing.Point(18, 126)
$clbCache.Size = New-Object System.Drawing.Size(660, 360)
$clbCache.CheckOnClick = $true
$clbCache.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$clbCache.Anchor = 'Top, Left, Right'
$pnlCache.Controls.Add($clbCache)
$lblCacheStatus = New-Object System.Windows.Forms.Label
$lblCacheStatus.Location = New-Object System.Drawing.Point(18, 492)
$lblCacheStatus.Size = New-Object System.Drawing.Size(660, 20)
$lblCacheStatus.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$lblCacheStatus.ForeColor = [System.Drawing.Color]::FromArgb(0, 120, 60)
$lblCacheStatus.Text = '未清理'
$pnlCache.Controls.Add($lblCacheStatus)

# ===== 清理历史记录页 =====
$pnlHistory.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$hHist = New-SectionHeader '清理历史记录' 10
$pnlHistory.Controls.Add($hHist)
$lblHistNote = New-Object System.Windows.Forms.Label
$lblHistNote.Location = New-Object System.Drawing.Point(18, 38)
$lblHistNote.Size = New-Object System.Drawing.Size(660, 54)
$lblHistNote.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$lblHistNote.ForeColor = $script:cGray
$lblHistNote.Text = '微信/QQ 等聊天库已加密，读不到“群聊名称”，故按【账号】多选清空；默认先备份到隔离区(可还原)。钉钉/企业微信/飞书本地加密，建议用软件内“设置→清空聊天记录”。'
$pnlHistory.Controls.Add($lblHistNote)
$lblHistApp = New-Object System.Windows.Forms.Label
$lblHistApp.Location = New-Object System.Drawing.Point(18, 98)
$lblHistApp.Size = New-Object System.Drawing.Size(60, 22)
$lblHistApp.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$lblHistApp.ForeColor = [System.Drawing.Color]::FromArgb(20, 40, 70)
$lblHistApp.Text = '软件：'
$pnlHistory.Controls.Add($lblHistApp)
$cboHistApp = New-Object System.Windows.Forms.ComboBox
$cboHistApp.Location = New-Object System.Drawing.Point(78, 96)
$cboHistApp.Size = New-Object System.Drawing.Size(220, 24)
$cboHistApp.DropDownStyle = 'DropDownList'
$cboHistApp.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$pnlHistory.Controls.Add($cboHistApp)
$clbHist = New-Object System.Windows.Forms.CheckedListBox
$clbHist.Location = New-Object System.Drawing.Point(18, 132)
$clbHist.Size = New-Object System.Drawing.Size(660, 320)
$clbHist.CheckOnClick = $true
$clbHist.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$clbHist.Anchor = 'Top, Left, Right'
$pnlHistory.Controls.Add($clbHist)
$chkHistDirect = New-Object System.Windows.Forms.CheckBox
$chkHistDirect.Location = New-Object System.Drawing.Point(18, 462)
$chkHistDirect.Size = New-Object System.Drawing.Size(440, 22)
$chkHistDirect.Text = '直接删除（立即释放空间，但不可还原）'
$chkHistDirect.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$pnlHistory.Controls.Add($chkHistDirect)
$btnHistClean = New-PageButton '清空所选聊天记录' 470 458 200 '备份(或直删)并清除勾选账号的聊天记录'
$btnHistClean.BackColor = $script:cAccent; $btnHistClean.ForeColor = [System.Drawing.Color]::White
$pnlHistory.Controls.Add($btnHistClean)
$lblHistStatus = New-Object System.Windows.Forms.Label
$lblHistStatus.Location = New-Object System.Drawing.Point(18, 492)
$lblHistStatus.Size = New-Object System.Drawing.Size(660, 20)
$lblHistStatus.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$lblHistStatus.ForeColor = [System.Drawing.Color]::FromArgb(0, 120, 60)
$lblHistStatus.Text = '未清理'
$pnlHistory.Controls.Add($lblHistStatus)

# 目标引擎（扫描/刷新）
$script:_allTargets = @()
$script:_cacheList = @()
$script:_histList = @()
function Refresh-Targets {
    $script:_allTargets = @(Get-CleanTargets)
    $script:_cacheList = @($script:_allTargets | Where-Object { $_.Kind -eq 'cache' })
    $clbCache.Items.Clear()
    foreach ($t in $script:_cacheList) { [void]$clbCache.Items.Add(($t.Label + '   ' + (Format-Bytes $t.Size))) }
    $apps = @($script:_allTargets | Where-Object { $_.Kind -eq 'history' } | ForEach-Object { $_.App } | Sort-Object -Unique)
    $cboHistApp.Items.Clear()
    foreach ($a in $apps) { [void]$cboHistApp.Items.Add($a) }
    if ($cboHistApp.Items.Count -gt 0) { $cboHistApp.SelectedIndex = 0 } else { Populate-HistList }
}
function Populate-HistList {
    $app = $cboHistApp.Text
    $script:_histList = @($script:_allTargets | Where-Object { $_.Kind -eq 'history' -and $_.App -eq $app })
    $clbHist.Items.Clear()
    foreach ($t in $script:_histList) { [void]$clbHist.Items.Add(($t.Label + '   ' + (Format-Bytes $t.Size))) }
}
$cboHistApp.Add_SelectedIndexChanged({ Populate-HistList })

# 缓存清理按钮
$btnCacheRefresh.Add_Click({ Refresh-Targets; $script:lblCacheStatus.Text = '已刷新检测' })
$btnCacheAll.Add_Click({ for ($i = 0; $i -lt $clbCache.Items.Count; $i++) { $clbCache.SetItemChecked($i, $true) } })
$btnCacheNone.Add_Click({ for ($i = 0; $i -lt $clbCache.Items.Count; $i++) { $clbCache.SetItemChecked($i, $false) } })
$bwCacheClean = New-Object System.ComponentModel.BackgroundWorker
$bwCacheClean.Add_DoWork({
    param($s, $e)
    $paths = $e.Argument
    $freed = 0; $ok = 0; $fail = 0
    foreach ($p in $paths) {
        try { $sz = (Get-FolderSize $p); Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop; $freed += $sz; $ok++ }
        catch { $fail++ }
    }
    $global:cacheCleanResult = @{ Freed = $freed; Ok = $ok; Fail = $fail }
})
$bwCacheClean.Add_RunWorkerCompleted({
    $r = $global:cacheCleanResult
    $script:lblCacheStatus.Text = "已清理 $($r.Ok) 项缓存，释放 $(Format-Bytes $r.Freed)" + $(if ($r.Fail -gt 0) { "，跳过 $($r.Fail) 项(被占用)" } else { '' }) + "（$(Get-Date -Format 'HH:mm:ss')）"
    Update-Status
    Refresh-Targets
})
$btnCacheClean.Add_Click({
    $sel = @()
    for ($i = 0; $i -lt $clbCache.Items.Count; $i++) { if ($clbCache.GetItemChecked($i)) { $sel += $script:_cacheList[$i].Path } }
    if ($sel.Count -eq 0) { $script:lblCacheStatus.Text = '请先勾选要清理的缓存项'; return }
    $bwCacheClean.RunWorkerAsync($sel)
    $script:lblCacheStatus.Text = "正在清理 $($sel.Count) 项缓存…"
})

# 历史记录清理按钮
$bwHistClean = New-Object System.ComponentModel.BackgroundWorker
$bwHistClean.Add_DoWork({
    param($s, $e)
    $arg = $e.Argument
    $ok = 0; $fail = 0; $backed = 0
    foreach ($p in $arg.Paths) {
        $r = Backup-And-Delete -Path $p -Tag $p -Direct $arg.Direct
        if ($r.Ok) { $ok++; if ($r.Backup) { $backed++ } } else { $fail++ }
    }
    $global:histCleanResult = @{ Ok = $ok; Fail = $fail; Backed = $backed; Direct = $arg.Direct }
})
$bwHistClean.Add_RunWorkerCompleted({
    $r = $global:histCleanResult
    if ($r.Direct) {
        $script:lblHistStatus.Text = "已直接清空 $($r.Ok) 个账号聊天记录（释放空间，不可还原）" + $(if ($r.Fail -gt 0) { "，失败 $($r.Fail)" } else { '' }) + "（$(Get-Date -Format 'HH:mm:ss')）"
    } else {
        $script:lblHistStatus.Text = "已清空 $($r.Ok) 个账号聊天记录（已备份到隔离区，可还原）" + $(if ($r.Fail -gt 0) { "，失败 $($r.Fail)" } else { '' }) + "（$(Get-Date -Format 'HH:mm:ss')）"
    }
    Update-Status
    Refresh-Targets
})
$btnHistClean.Add_Click({
    $sel = @()
    for ($i = 0; $i -lt $clbHist.Items.Count; $i++) { if ($clbHist.GetItemChecked($i)) { $sel += $script:_histList[$i].Path } }
    if ($sel.Count -eq 0) { $script:lblHistStatus.Text = '请先勾选要清空的账号'; return }
    $direct = $chkHistDirect.Checked
    $msg = "将清空 $($sel.Count) 个账号的聊天记录。" + $(if ($direct) { "直接删除不可还原！" } else { "删除前会备份到隔离区(可还原)，但需清理隔离区才释放空间。" }) + " 继续？"
    $ans = [System.Windows.Forms.MessageBox]::Show($msg, '确认清空聊天记录', 'YesNo', 'Warning')
    if ($ans -ne 'Yes') { return }
    $bwHistClean.RunWorkerAsync(@{ Paths = $sel; Direct = $direct })
    $script:lblHistStatus.Text = "正在清空 $($sel.Count) 个账号聊天记录…"
})

# ===== 工具箱页 =====
$pnlTools.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$hTools2 = New-SectionHeader '常用工具' 10
$pnlTools.Controls.Add($hTools2)
$flTools = New-Object System.Windows.Forms.FlowLayoutPanel
$flTools.Location = New-Object System.Drawing.Point(18, 38)
$flTools.Size = New-Object System.Drawing.Size(660, 460)
$flTools.FlowDirection = 'LeftToRight'
$flTools.WrapContents = $true
$flTools.AutoScroll = $true
$flTools.BackColor = $script:cBg
$btnKill  = New-PageButton '结束进程' 0 0 200 '选择并结束占用高/卡死的进程（需确认）'
$btnNet   = New-PageButton '网络修复' 0 0 200 '刷新 DNS 缓存并重置网络栈（需管理员）'
$btnClip  = New-PageButton '清空剪贴板' 0 0 200 '清除系统剪贴板内容'
$btnLock  = New-PageButton '锁屏'       0 0 200 '立即锁定屏幕'
$btnLaunch = New-PageButton '打开软件'   0 0 200 '打开常用软件（可管理列表）'
$btnDiag  = New-PageButton '导出诊断'   0 0 200 '导出系统/磁盘/设置诊断信息'
$btnLog   = New-PageButton '运行日志'    0 0 200 '查看清理/优化运行日志'
$btnAbout = New-PageButton '关于'        0 0 200 '关于 CleanOpt 与功能一览'
$btnRegister = New-PageButton '注册每日任务' 0 0 200 '注册每日 03:00 静默清理/优化任务'
$btnUpdate = New-PageButton '检查更新'   0 0 200 '检查并应用新版本（自动更新）'
$btnAudit = New-PageButton '操作审计'     0 0 200 '查看清理/卸载/迁移等操作的留痕记录'
$btnMemDiag = New-PageButton '内存诊断'   0 0 200 '分析内存为什么占这么多（按进程分类：浏览器 / WorkBuddy 会话 / 预热带等）'
$flTools.Controls.AddRange(@($btnKill, $btnNet, $btnClip, $btnLock, $btnLaunch, $btnDiag, $btnLog, $btnAbout, $btnRegister, $btnUpdate, $btnAudit, $btnMemDiag))
$pnlTools.Controls.Add($flTools)

# ===== 强力卸载页 =====
$pnlUninstall.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$hUninst = New-SectionHeader '强力卸载' 10
$pnlUninstall.Controls.Add($hUninst)
$btnScanApp = New-PageButton '扫描已安装程序' 18 38 200 '扫描注册表中所有已安装程序'
$pnlUninstall.Controls.Add($btnScanApp)

$lvUninstall = New-Object System.Windows.Forms.ListView
$lvUninstall.Location = New-Object System.Drawing.Point(18, 82)
$lvUninstall.Size = New-Object System.Drawing.Size(640, 320)
$lvUninstall.View = 'Details'
$lvUninstall.FullRowSelect = $true
$lvUninstall.GridLines = $true
$lvUninstall.Columns.Add('程序名称', 220) | Out-Null
$lvUninstall.Columns.Add('版本', 90) | Out-Null
$lvUninstall.Columns.Add('安装日期', 110) | Out-Null
$lvUninstall.Columns.Add('卸载命令', 210) | Out-Null
$pnlUninstall.Controls.Add($lvUninstall)

$btnDoUninstall = New-PageButton '标准卸载' 18 414 150 '执行选中程序的官方卸载程序（需确认）'
$btnForceRemove = New-PageButton '强制清除' 180 414 160 '删除注册表项+安装目录残留（危险，需二次确认）'
$btnForceRemove.Enabled = $false
$btnForceRemove.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(220, 150, 150)
$pnlUninstall.Controls.AddRange(@($btnDoUninstall, $btnForceRemove))

$lblUninstNote = New-Object System.Windows.Forms.Label
$lblUninstNote.Location = New-Object System.Drawing.Point(18, 460)
$lblUninstNote.Size = New-Object System.Drawing.Size(640, 36)
$lblUninstNote.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$lblUninstNote.ForeColor = $script:cGray
$lblUninstNote.Text = '标准卸载：运行程序自带的卸载程序。强制清除：删除注册表 Uninstall 键和安装目录（不可还原，谨慎使用）。'
$pnlUninstall.Controls.Add($lblUninstNote)

# ===== 大文件分析页 =====
$pnlBigFiles.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$hBig = New-SectionHeader 'C 盘大文件分析' 10
$pnlBigFiles.Controls.Add($hBig)

$rowA = 38
$btnScanBig = New-PageButton '扫描 C 盘大文件' 18 $rowA 200 '扫描 C 盘大文件（排除系统关键目录），按体积排序'
$txtBigTop = New-Object System.Windows.Forms.NumericUpDown
$txtBigTop.Location = New-Object System.Drawing.Point(232, $rowA + 6)
$txtBigTop.Size = New-Object System.Drawing.Size(60, 28)
$txtBigTop.Value = 50
$txtBigTop.Minimum = 10
$txtBigTop.Maximum = 500
$txtBigTop.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$lblBigTop = New-Object System.Windows.Forms.Label
$lblBigTop.Text = '条'
$lblBigTop.Location = New-Object System.Drawing.Point(298, $rowA + 8)
$lblBigTop.Size = New-Object System.Drawing.Size(30, 20)
$lblBigTop.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$pnlBigFiles.Controls.AddRange(@($btnScanBig, $txtBigTop, $lblBigTop))

$lvBigFiles = New-Object System.Windows.Forms.ListView
$lvBigFiles.Location = New-Object System.Drawing.Point(18, 80)
$lvBigFiles.Size = New-Object System.Drawing.Size(640, 330)
$lvBigFiles.View = 'Details'
$lvBigFiles.FullRowSelect = $true
$lvBigFiles.GridLines = $true
$lvBigFiles.Columns.Add('路径', 380) | Out-Null
$lvBigFiles.Columns.Add('大小', 100) | Out-Null
$lvBigFiles.Columns.Add('类型', 80) | Out-Null
$lvBigFiles.Columns.Add('修改时间', 140) | Out-Null
$pnlBigFiles.Controls.Add($lvBigFiles)

$btnOpenFolder = New-PageButton '打开所在文件夹' 18 422 180 '在资源管理器中选中该文件'
$btnMigrate = New-PageButton '迁移到其他盘' 210 422 180 '将文件移动到指定目录（需选择目标）'
$btnMigrate.Enabled = $false
$pnlBigFiles.Controls.AddRange(@($btnOpenFolder, $btnMigrate))

$lblBigNote = New-Object System.Windows.Forms.Label
$lblBigNote.Location = New-Object System.Drawing.Point(18, 468)
$lblBigNote.Size = New-Object System.Drawing.Size(640, 32)
$lblBigNote.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$lblBigNote.ForeColor = $script:cGray
$lblBigNote.Text = '扫描排除 Windows、Program Files、$Recycle.Bin 等系统关键目录。迁移前请确认目标盘有足够空间。'
$pnlBigFiles.Controls.Add($lblBigNote)
$pnlSettings.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
$hSet = New-SectionHeader '设置与自启' 10
$pnlSettings.Controls.Add($hSet)
$btnSettings = New-PageButton '打开设置' 18 38 220 '外部工具路径与行为设置'
$pnlSettings.Controls.Add($btnSettings)
$btnAutostart = New-PageButton '开机自启：关' 18 78 220 '切换登录后后台自启（修改计划任务）'
try { if (Get-ScheduledTask -TaskName 'CleanOpt-Logon' -ErrorAction SilentlyContinue) { $btnAutostart.Text = '开机自启：开' } } catch { }
$pnlSettings.Controls.Add($btnAutostart)
$lblSetNote = New-Object System.Windows.Forms.Label
$lblSetNote.Location = New-Object System.Drawing.Point(18, 130)
$lblSetNote.Size = New-Object System.Drawing.Size(640, 80)
$lblSetNote.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$lblSetNote.ForeColor = $script:cGray
$lblSetNote.Text = "在「设置」中可调整：内存紧张阈值、监控间隔、隔离区保留天数、还原开关、隐私随清、自动更新、游戏免打扰、外部工具路径等。`n更多高级选项见「设置」对话框。"
$pnlSettings.Controls.Add($lblSetNote)
$btnExit = New-PageButton '退出（完全关闭）' 18 226 220 '退出并停止后台监控'
$btnExit.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(220, 150, 150)
$btnExit.Add_MouseEnter({ param($s, $e) $s.BackColor = [System.Drawing.Color]::FromArgb(245, 222, 222) })
$btnExit.Add_MouseLeave({ param($s, $e) $s.BackColor = [System.Drawing.Color]::FromArgb(244, 247, 250) })
$pnlSettings.Controls.Add($btnExit)

# ---- 默认显示首页（必须在 Controls.Add 之后，否则 Dock=Fill + AutoScroll 滚动位置异常）----
# v1.18: 同时注册 Shown 事件，在窗体完全渲染后再次重置滚动（Handle 已创建，保证生效）

# ---- P/Invoke: 禁用 ProgressBar Visual Styles（使 ForeColor 生效）----
# Windows Vista+ 的 ProgressBar 使用主题渲染，忽略 ForeColor 属性
# 调用 SetWindowTheme("", "") 禁用主题后，回退到经典 GDI 渲染，ForeColor 即可控制颜色
try {
    $sig = @"
using System;
using System.Runtime.InteropServices;
public class Win32Helper {
    [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
    public static extern int SetWindowTheme(IntPtr hWnd, string pszSubAppName, string pszSubIdList);
}
"@
    $script:win32Helper = Add-Type -MemberDefinition $sig -Name "Win32Helper" -Namespace "CleanOpt" -PassThru
} catch { # 已定义则忽略
    $script:win32Helper = [CleanOpt.Win32Helper]
}

$form.Add_Shown({
    # 窗体首次显示后，确保首页滚动位置归零（AutoScrollPosition 在 Handle 创建前设置可能无效）
    if ($pnlHome.IsHandleCreated) { $pnlHome.AutoScrollPosition = New-Object System.Drawing.Point(0, 0) }
    # 修复「运行概况」卡片空白: 控件 Handle 未创建时 Show-Page 里的 BeginInvoke 刷新会失效, 这里补刷一次
    try { Refresh-HomeStat } catch { }
    # v1.22: 禁用进度条的视觉样式，使蓝色 ForeColor 生效（必须在 Handle 创建后调用）
    if ($script:win32Helper -and $script:pbRam.IsHandleCreated) {
        [void]$script:win32Helper::SetWindowTheme($script:pbRam.Handle, "", "")
        [void]$script:win32Helper::SetWindowTheme($script:pbDisk.Handle, "", "")
    }
})

$form.Controls.Add($pnlSide)
$form.Controls.Add($pnlHeader)
$form.Controls.Add($pnlStatus)
$form.Controls.Add($pnlContent)

# v1.19 关键修复：将内容区置于最顶层，防止被 Dock=Left 的导航栏遮挡
$pnlContent.BringToFront()

# 默认显示首页（面板已加入 Form，Dock 布局完成后再切换页面）
Show-Page 'home'
# 安全：重置首页滚动位置（v1.18: Show-Page 内部已含重置，此处保留作为兜底）
if ($pnlHome.IsHandleCreated) { $pnlHome.AutoScrollPosition = New-Object System.Drawing.Point(0, 0) }

# ---- tray ----
$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
$notifyIcon.Icon = $script:appIcon
$notifyIcon.Text = 'CleanOpt'
$notifyIcon.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$mShow = $menu.Items.Add('显示主窗口')
$mOpt  = $menu.Items.Add('立即优化内存')
$mRecycle = $menu.Items.Add('清空回收站')
$mLaunch = $menu.Items.Add('打开软件')
$mSettings = $menu.Items.Add('设置')
$mRunAll = $menu.Items.Add('一键全面优化')
$mLog = $menu.Items.Add('运行日志')
$mDiag = $menu.Items.Add('导出诊断')
$mUpdate = $menu.Items.Add('检查更新')
$mAbout = $menu.Items.Add('关于')
$mExit = $menu.Items.Add('退出')
$notifyIcon.ContextMenuStrip = $menu
$mShow.Add_Click({ $form.ShowInTaskbar = $true; $form.Show(); $form.WindowState = 'Normal'; $form.Activate() })
$mOpt.Add_Click({ Invoke-Optimize; $lblStatus.Text = '已触发内存优化（后台，无窗口）' })
$mRecycle.Add_Click({ $lblStatus.Text = '正在清空回收站…（后台，无窗口）'; $bwRecycle.RunWorkerAsync() })
$mLaunch.Add_Click({ Show-LauncherDialog })
$mSettings.Add_Click({ Show-SettingsDialog })
$mRunAll.Add_Click({ Invoke-RunAll })
$mLog.Add_Click({ Show-LogDialog })
$mDiag.Add_Click({ Export-Diagnostics })
$mUpdate.Add_Click({ Show-UpdateDialog })
$mAbout.Add_Click({ Show-AboutDialog })
$mExit.Add_Click({ $global:forceExit = $true; if ($notifyIcon) { $notifyIcon.Icon = $null }; Dispose-BandIcons; $notifyIcon.Dispose(); $form.Close() })
# v1.21: 托盘图标单击即可打开主窗口（更符合用户习惯）
$notifyIcon.Add_Click({
    # 区分左键单击 vs 右键（右键弹出菜单由系统自动处理）
    if ($_.Button -eq [System.Windows.Forms.MouseButtons]::Left) {
        $form.ShowInTaskbar = $true; $form.Show(); $form.WindowState = 'Normal'; $form.Activate()
    }
})

# ---- close -> hide to tray (no popup) ----
$form.Add_FormClosing({
    param($s, $e)
    if (-not $global:forceExit) {
        $e.Cancel = $true
        $form.Hide()
    }
})

# ---- program launcher (sub-window) ----
$appsFile = Join-Path $root 'apps.json'
function Load-Apps {
    if (Test-Path $appsFile) {
        try { return @(Get-Content $appsFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { }
    }
    return @()
}
function Save-Apps($list) {
    $list | ConvertTo-Json | Set-Content -Path $appsFile -Encoding UTF8
}
function Show-AddDialog {
    $ad = New-Object System.Windows.Forms.Form
    $ad.Text = '添加程序'
    $ad.Size = New-Object System.Drawing.Size(430, 180)
    $ad.StartPosition = 'CenterParent'
    $ad.FormBorderStyle = 'FixedDialog'
    $ad.MaximizeBox = $false
    $ad.MinimizeBox = $false
    $lName = New-Object System.Windows.Forms.Label; $lName.Text = '名称'; $lName.Location = New-Object System.Drawing.Point(12,16); $lName.Size = New-Object System.Drawing.Size(56,20)
    $tbName = New-Object System.Windows.Forms.TextBox; $tbName.Location = New-Object System.Drawing.Point(74,12); $tbName.Size = New-Object System.Drawing.Size(320,22)
    $lPath = New-Object System.Windows.Forms.Label; $lPath.Text = '路径'; $lPath.Location = New-Object System.Drawing.Point(12,48); $lPath.Size = New-Object System.Drawing.Size(56,20)
    $tbPath = New-Object System.Windows.Forms.TextBox; $tbPath.Location = New-Object System.Drawing.Point(74,44); $tbPath.Size = New-Object System.Drawing.Size(250,22)
    $btnBrowse = New-Object System.Windows.Forms.Button; $btnBrowse.Text = '浏览'; $btnBrowse.Location = New-Object System.Drawing.Point(330,42); $btnBrowse.Size = New-Object System.Drawing.Size(64,24)
    $btnOK = New-Object System.Windows.Forms.Button; $btnOK.Text = '确定'; $btnOK.Location = New-Object System.Drawing.Point(150,98); $btnOK.Size = New-Object System.Drawing.Size(110,28)
    $btnCancel = New-Object System.Windows.Forms.Button; $btnCancel.Text = '取消'; $btnCancel.Location = New-Object System.Drawing.Point(270,98); $btnCancel.Size = New-Object System.Drawing.Size(110,28)
    $ad.Controls.AddRange(@($lName,$tbName,$lPath,$tbPath,$btnBrowse,$btnOK,$btnCancel))
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = '可执行文件 (*.exe)|*.exe|所有文件 (*.*)|*.*'
    $ofd.Title = '选择要添加的程序'
    $btnBrowse.Add_Click({ if ($ofd.ShowDialog() -eq 'OK') { $tbPath.Text = $ofd.FileName; if (-not $tbName.Text) { $tbName.Text = [System.IO.Path]::GetFileNameWithoutExtension($ofd.FileName) } } })
    $btnOK.Add_Click({
        if (-not $tbName.Text -or -not $tbPath.Text) { [System.Windows.Forms.MessageBox]::Show('请填写名称和路径','提示','OK','Warning'); return }
        if (-not (Test-Path $tbPath.Text)) { [System.Windows.Forms.MessageBox]::Show('路径不存在: ' + $tbPath.Text,'提示','OK','Warning'); return }
        $ad.DialogResult = 'OK'; $ad.Close()
    })
    $btnCancel.Add_Click({ $ad.DialogResult = 'Cancel'; $ad.Close() })
    if ($ad.ShowDialog() -eq 'OK') { return [PSCustomObject]@{ name = $tbName.Text; path = $tbPath.Text } }
    return $null
}
function Show-LauncherDialog {
    $script:apps = @(Load-Apps)
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = '打开软件'
    $dlg.Size = New-Object System.Drawing.Size(420, 360)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.Owner = $form
    $lbl = New-Object System.Windows.Forms.Label; $lbl.Text = '选择一个程序打开（双击或点“打开”）'; $lbl.Location = New-Object System.Drawing.Point(12,10); $lbl.Size = New-Object System.Drawing.Size(384,20)
    $lb = New-Object System.Windows.Forms.ListBox; $lb.Location = New-Object System.Drawing.Point(12,36); $lb.Size = New-Object System.Drawing.Size(384,250)
    $btnOpen = New-Object System.Windows.Forms.Button; $btnOpen.Text = '打开'; $btnOpen.Location = New-Object System.Drawing.Point(12,298); $btnOpen.Size = New-Object System.Drawing.Size(116,28)
    $btnDel = New-Object System.Windows.Forms.Button; $btnDel.Text = '删除'; $btnDel.Location = New-Object System.Drawing.Point(138,298); $btnDel.Size = New-Object System.Drawing.Size(116,28)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(264,298); $btnClose.Size = New-Object System.Drawing.Size(116,28)
    $dlg.Controls.AddRange(@($lbl,$lb,$btnOpen,$btnDel,$btnClose))
    function Refresh-List {
        $lb.Items.Clear()
        foreach ($a in $script:apps) { $lb.Items.Add($a.name) }
        $lb.Items.Add('➕ 添加程序')
    }
    Refresh-List
    function Launch-ByIndex($idx) {
        if ($idx -lt 0 -or $idx -ge ($lb.Items.Count - 1)) { return }
        $a = $script:apps[$idx]
        try { Start-Process -FilePath $a.path -ErrorAction Stop; $dlg.Close() }
        catch { [System.Windows.Forms.MessageBox]::Show('无法打开: ' + $a.path,'错误','OK','Error') }
    }
    function Do-Select {
        $i = $lb.SelectedIndex
        if ($i -eq ($lb.Items.Count - 1)) {
            $na = Show-AddDialog
            if ($na) { $script:apps = @($script:apps) + $na; Save-Apps $script:apps; Refresh-List }
        } else { Launch-ByIndex $i }
    }
    $lb.Add_DoubleClick({ Do-Select })
    $btnOpen.Add_Click({ Do-Select })
    $btnDel.Add_Click({
        $i = $lb.SelectedIndex
        if ($i -ge 0 -and $i -ne ($lb.Items.Count - 1)) {
            $new = @()
            for ($k = 0; $k -lt $script:apps.Count; $k++) { if ($k -ne $i) { $new += $script:apps[$k] } }
            $script:apps = $new
            Save-Apps $script:apps
            Refresh-List
        }
    })
    $btnClose.Add_Click({ $dlg.Close() })
    $dlg.ShowDialog() | Out-Null
}

# ---- settings (external tool paths) ----
$settingsFile = Join-Path $root 'settings.json'
function Load-Settings {
    $s = [PSCustomObject]@{
        huorongPath          = ''
        pclPath              = ''
        ramPressurePct       = $RamPressureUsedPct
        monitorIntervalSec   = $MonitorIntervalSec
        trayNotify           = $script:trayNotify
        gndEnabled           = $script:gndEnabled
        gndProcesses         = $script:gndProcesses
        diskFreeThresholdPct = $script:diskFreeThresholdPct
        idleMinutes          = $script:idleMinutes
        optimizeStrength     = $script:optimizeStrength
        startupDelaySec      = $script:startupDelaySec
        dailyEmptyRecycle    = $script:dailyEmptyRecycle
        restoreEnabled       = $script:restoreEnabled
        restoreKeepDays      = $script:restoreKeepDays
        privacyClean         = $script:privacyClean
        autoUpdate           = $script:autoUpdate
        updateUrl            = $script:updateUrl
        updateIntervalDays   = $script:updateIntervalDays
    }
    if (Test-Path $settingsFile) {
        try {
            $j = Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($j.huorongPath) { $s.huorongPath = $j.huorongPath }
            if ($j.pclPath) { $s.pclPath = $j.pclPath }
            if ($j.ramPressurePct) { $s.ramPressurePct = $j.ramPressurePct }
            if ($j.monitorIntervalSec) { $s.monitorIntervalSec = $j.monitorIntervalSec }
            if ($null -ne $j.trayNotify) { $s.trayNotify = [bool]$j.trayNotify }
            if ($null -ne $j.gndEnabled) { $s.gndEnabled = [bool]$j.gndEnabled }
            if ($j.gndProcesses) { $s.gndProcesses = $j.gndProcesses }
            if ($j.diskFreeThresholdPct) { $s.diskFreeThresholdPct = $j.diskFreeThresholdPct }
            if ($null -ne $j.idleMinutes) { $s.idleMinutes = $j.idleMinutes }
            if ($j.optimizeStrength) { $s.optimizeStrength = $j.optimizeStrength }
            if ($null -ne $j.startupDelaySec) { $s.startupDelaySec = $j.startupDelaySec }
            if ($null -ne $j.dailyEmptyRecycle) { $s.dailyEmptyRecycle = [bool]$j.dailyEmptyRecycle }
            if ($null -ne $j.restoreEnabled) { $s.restoreEnabled = [bool]$j.restoreEnabled }
            if ($null -ne $j.restoreKeepDays) { $s.restoreKeepDays = [int]$j.restoreKeepDays }
            if ($null -ne $j.privacyClean) { $s.privacyClean = [bool]$j.privacyClean }
            if ($null -ne $j.autoUpdate) { $s.autoUpdate = [bool]$j.autoUpdate }
            if ($j.updateUrl) { $s.updateUrl = [string]$j.updateUrl }
            if ($null -ne $j.updateIntervalDays) { $s.updateIntervalDays = $j.updateIntervalDays }
        } catch { }
    }
    return $s
}
function Save-Settings($obj) {
    # 注意: ConvertTo-Json 在 Windows PowerShell 5.1 不支持 -Encoding, 加上会抛错导致设置静默不保存
    try { $obj | ConvertTo-Json | Set-Content -Path $settingsFile -Encoding UTF8 } catch { }
}

function Set-PathStatus($box) {
    $lab = $box.Tag
    if ($box.Text -and (Test-Path $box.Text)) {
        $lab.Text = '✓ 已找到'
        $lab.ForeColor = [System.Drawing.Color]::FromArgb(0, 140, 0)
    } elseif ($box.Text) {
        $lab.Text = '✗ 路径不存在，请检查'
        $lab.ForeColor = [System.Drawing.Color]::FromArgb(200, 0, 0)
    } else {
        $lab.Text = '留空 = 自动探测'
        $lab.ForeColor = [System.Drawing.Color]::Gray
    }
}

function Show-SettingsDialog {
    $cfg = Load-Settings
    $sd = New-Object System.Windows.Forms.Form
    $sd.Text = '设置 · 外部工具路径与行为'
    $sd.Size = New-Object System.Drawing.Size(560, 752)
    $sd.StartPosition = 'CenterParent'
    $sd.FormBorderStyle = 'FixedDialog'
    $sd.MaximizeBox = $false
    $sd.MinimizeBox = $false
    $sd.AutoScroll = $true
    $sd.Owner = $form

    $hint = New-Object System.Windows.Forms.Label
    $hint.Text = '若某工具未被自动找到，请点“浏览”指定其 .exe 路径（留空则自动探测）：'
    $hint.Location = New-Object System.Drawing.Point(12, 10)
    $hint.Size = New-Object System.Drawing.Size(490, 20)
    $hint.ForeColor = [System.Drawing.Color]::Gray
    $sd.Controls.Add($hint)

    $tools = @(
        [PSCustomObject]@{ key = 'huorongPath'; name = '火绒 (垃圾清理 sysclean.exe)'; desc = '用于垃圾清理的火绒主程序' },
        [PSCustomObject]@{ key = 'pclPath'; name = 'PCL (内存优化 PCL.exe)'; desc = '用于内存优化的启动器' }
    )

    $rows = @{}
    $y = 40
    foreach ($t in $tools) {
        $lblName = New-Object System.Windows.Forms.Label
        $lblName.Text = $t.name
        $lblName.Location = New-Object System.Drawing.Point(12, $y)
        $lblName.Size = New-Object System.Drawing.Size(490, 18)
        $tb = New-Object System.Windows.Forms.TextBox
        $tb.Name = $t.name
        $tb.Text = $cfg.($t.key)
        $tb.Location = New-Object System.Drawing.Point(12, ($y + 20))
        $tb.Size = New-Object System.Drawing.Size(370, 22)
        $btnBr = New-Object System.Windows.Forms.Button
        $btnBr.Text = '浏览'
        $btnBr.Location = New-Object System.Drawing.Point(390, ($y + 18))
        $btnBr.Size = New-Object System.Drawing.Size(60, 24)
        $btnBr.Tag = $tb   # 用 Tag 避免闭包捕获循环变量
        $lblSt = New-Object System.Windows.Forms.Label
        $lblSt.Location = New-Object System.Drawing.Point(12, ($y + 46))
        $lblSt.Size = New-Object System.Drawing.Size(490, 18)
        $tb.Tag = $lblSt
        Set-PathStatus $tb
        $tb.Add_TextChanged({ param($s, $e) Set-PathStatus $s })
        $btnBr.Add_Click({
            param($s, $e)
            $ofd = New-Object System.Windows.Forms.OpenFileDialog
            $ofd.Filter = '可执行文件 (*.exe)|*.exe|所有文件 (*.*)|*.*'
            $ofd.Title = '选择 ' + $s.Tag.Name
            if ($ofd.ShowDialog() -eq 'OK') { $s.Tag.Text = $ofd.FileName }
        })
        $sd.Controls.AddRange(@($lblName, $tb, $btnBr, $lblSt))
        $rows[$t.key] = $tb
        $y += 78
    }

    # ---- 行为设置 ----
    $y += 6
    $lblBeh = New-Object System.Windows.Forms.Label
    $lblBeh.Text = '行为设置'
    $lblBeh.Location = New-Object System.Drawing.Point(12, $y)
    $lblBeh.Size = New-Object System.Drawing.Size(490, 18)
    $lblBeh.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
    $sd.Controls.Add($lblBeh)
    $y += 22

    $cbGnd = New-Object System.Windows.Forms.CheckBox; $cbGnd.Text = '游戏/全屏免打扰（全屏或下列进程运行时暂停自动优化）'; $cbGnd.Location = New-Object System.Drawing.Point(12, $y); $cbGnd.Size = New-Object System.Drawing.Size(490, 20); $cbGnd.Checked = $cfg.gndEnabled; $sd.Controls.Add($cbGnd)
    $y += 24
    $lblGndP = New-Object System.Windows.Forms.Label; $lblGndP.Text = '免打扰进程名（分号分隔，如 javaw.exe;java.exe）'; $lblGndP.Location = New-Object System.Drawing.Point(12, $y); $lblGndP.Size = New-Object System.Drawing.Size(490, 18); $sd.Controls.Add($lblGndP)
    $y += 20
    $tbGndProc = New-Object System.Windows.Forms.TextBox; $tbGndProc.Text = $cfg.gndProcesses; $tbGndProc.Location = New-Object System.Drawing.Point(12, $y); $tbGndProc.Size = New-Object System.Drawing.Size(470, 22); $sd.Controls.Add($tbGndProc)
    $y += 30

    $lblT = New-Object System.Windows.Forms.Label; $lblT.Text = '内存紧张阈值 (%)'; $lblT.Location = New-Object System.Drawing.Point(12, $y); $lblT.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblT)
    $tbThresh = New-Object System.Windows.Forms.TextBox; $tbThresh.Text = [string]$cfg.ramPressurePct; $tbThresh.Location = New-Object System.Drawing.Point(260, $y); $tbThresh.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbThresh)
    $y += 30

    $lblD = New-Object System.Windows.Forms.Label; $lblD.Text = '磁盘剩余低于 (%) 自动清理'; $lblD.Location = New-Object System.Drawing.Point(12, $y); $lblD.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblD)
    $tbDisk = New-Object System.Windows.Forms.TextBox; $tbDisk.Text = [string]$cfg.diskFreeThresholdPct; $tbDisk.Location = New-Object System.Drawing.Point(260, $y); $tbDisk.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbDisk)
    $y += 30

    $lblIv = New-Object System.Windows.Forms.Label; $lblIv.Text = '监控间隔 (秒)'; $lblIv.Location = New-Object System.Drawing.Point(12, $y); $lblIv.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblIv)
    $tbInt = New-Object System.Windows.Forms.TextBox; $tbInt.Text = [string]$cfg.monitorIntervalSec; $tbInt.Location = New-Object System.Drawing.Point(260, $y); $tbInt.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbInt)
    $y += 30

    $lblIdle = New-Object System.Windows.Forms.Label; $lblIdle.Text = '空闲满 (分钟) 才自动优化 (0=不限)'; $lblIdle.Location = New-Object System.Drawing.Point(12, $y); $lblIdle.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblIdle)
    $tbIdle = New-Object System.Windows.Forms.TextBox; $tbIdle.Text = [string]$cfg.idleMinutes; $tbIdle.Location = New-Object System.Drawing.Point(260, $y); $tbIdle.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbIdle)
    $y += 30

    $lblStr = New-Object System.Windows.Forms.Label; $lblStr.Text = '优化强度'; $lblStr.Location = New-Object System.Drawing.Point(12, $y); $lblStr.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblStr)
    $cbStrength = New-Object System.Windows.Forms.ComboBox; $cbStrength.Items.AddRange(@('strong|强力（预热带清理+备用列表）', 'standard|标准（仅备用列表，最温和）')); $cbStrength.DropDownStyle = 'DropDownList'; $cbStrength.Location = New-Object System.Drawing.Point(260, $y); $cbStrength.Size = New-Object System.Drawing.Size(250, 22)
    if ($cfg.optimizeStrength -eq 'standard') { $cbStrength.SelectedIndex = 1 } else { $cbStrength.SelectedIndex = 0 }
    $sd.Controls.Add($cbStrength)
    $y += 30

    $lblDel = New-Object System.Windows.Forms.Label; $lblDel.Text = '启动后延迟 (秒) 再监控 (0=立即)'; $lblDel.Location = New-Object System.Drawing.Point(12, $y); $lblDel.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblDel)
    $tbDelay = New-Object System.Windows.Forms.TextBox; $tbDelay.Text = [string]$cfg.startupDelaySec; $tbDelay.Location = New-Object System.Drawing.Point(260, $y); $tbDelay.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbDelay)
    $y += 30

    $cbRecycle = New-Object System.Windows.Forms.CheckBox; $cbRecycle.Text = '每日任务包含“清空回收站”'; $cbRecycle.Location = New-Object System.Drawing.Point(12, $y); $cbRecycle.Size = New-Object System.Drawing.Size(490, 20); $cbRecycle.Checked = $cfg.dailyEmptyRecycle; $sd.Controls.Add($cbRecycle)
    $y += 26

    $cbNotify = New-Object System.Windows.Forms.CheckBox; $cbNotify.Text = '后台静默动作后显示托盘气泡提示（默认关）'; $cbNotify.Location = New-Object System.Drawing.Point(12, $y); $cbNotify.Size = New-Object System.Drawing.Size(470, 20); $cbNotify.Checked = $cfg.trayNotify; $sd.Controls.Add($cbNotify)
    $y += 32

    # ---- 自动更新设置 ----
    $lblUpd = New-Object System.Windows.Forms.Label; $lblUpd.Text = '自动更新（下一代起生效）'; $lblUpd.Location = New-Object System.Drawing.Point(12, $y); $lblUpd.Size = New-Object System.Drawing.Size(490, 18); $lblUpd.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold); $sd.Controls.Add($lblUpd)
    $y += 22
    $cbAutoUpdate = New-Object System.Windows.Forms.CheckBox; $cbAutoUpdate.Text = '自动检查更新（每周静默下载并应用新版本）'; $cbAutoUpdate.Location = New-Object System.Drawing.Point(12, $y); $cbAutoUpdate.Size = New-Object System.Drawing.Size(490, 20); $cbAutoUpdate.Checked = $cfg.autoUpdate; $sd.Controls.Add($cbAutoUpdate)
    $y += 24
    $lblUpdUrl = New-Object System.Windows.Forms.Label; $lblUpdUrl.Text = '更新源（version.json 地址或本地文件夹，留空则关闭自动更新）'; $lblUpdUrl.Location = New-Object System.Drawing.Point(12, $y); $lblUpdUrl.Size = New-Object System.Drawing.Size(490, 18); $sd.Controls.Add($lblUpdUrl)
    $y += 20
    $tbUpdUrl = New-Object System.Windows.Forms.TextBox; $tbUpdUrl.Text = $cfg.updateUrl; $tbUpdUrl.Location = New-Object System.Drawing.Point(12, $y); $tbUpdUrl.Size = New-Object System.Drawing.Size(470, 22); $sd.Controls.Add($tbUpdUrl)
    $y += 30
    $lblUpdDays = New-Object System.Windows.Forms.Label; $lblUpdDays.Text = '检查间隔 (天)'; $lblUpdDays.Location = New-Object System.Drawing.Point(12, $y); $lblUpdDays.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblUpdDays)
    $tbUpdDays = New-Object System.Windows.Forms.TextBox; $tbUpdDays.Text = [string]$cfg.updateIntervalDays; $tbUpdDays.Location = New-Object System.Drawing.Point(260, $y); $tbUpdDays.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbUpdDays)
    $y += 32

    # ---- 还原 / 安全设置 ----
    $lblRes = New-Object System.Windows.Forms.Label; $lblRes.Text = '清理结果可还原（安全）'; $lblRes.Location = New-Object System.Drawing.Point(12, $y); $lblRes.Size = New-Object System.Drawing.Size(490, 18); $lblRes.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold); $sd.Controls.Add($lblRes)
    $y += 22
    $cbRestore = New-Object System.Windows.Forms.CheckBox; $cbRestore.Text = '清理前移入隔离区（可一键还原，默认开）'; $cbRestore.Location = New-Object System.Drawing.Point(12, $y); $cbRestore.Size = New-Object System.Drawing.Size(490, 20); $cbRestore.Checked = $cfg.restoreEnabled; $sd.Controls.Add($cbRestore)
    $y += 24
    $lblKeep = New-Object System.Windows.Forms.Label; $lblKeep.Text = '隔离区保留天数（超过自动彻底删除）'; $lblKeep.Location = New-Object System.Drawing.Point(12, $y); $lblKeep.Size = New-Object System.Drawing.Size(240, 20); $sd.Controls.Add($lblKeep)
    $tbKeep = New-Object System.Windows.Forms.TextBox; $tbKeep.Text = [string]$cfg.restoreKeepDays; $tbKeep.Location = New-Object System.Drawing.Point(260, $y); $tbKeep.Size = New-Object System.Drawing.Size(120, 22); $sd.Controls.Add($tbKeep)
    $y += 32

    # ---- 隐私痕迹清理 (P2 差异化) ----
    $lblPriv = New-Object System.Windows.Forms.Label; $lblPriv.Text = '隐私痕迹清理（敏感，请谨慎）'; $lblPriv.Location = New-Object System.Drawing.Point(12, $y); $lblPriv.Size = New-Object System.Drawing.Size(490, 18); $lblPriv.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold); $sd.Controls.Add($lblPriv)
    $y += 22
    $cbPrivacy = New-Object System.Windows.Forms.CheckBox; $cbPrivacy.Text = '常规清理时顺带清理隐私痕迹（最近使用/跳转列表/运行记录）'; $cbPrivacy.Location = New-Object System.Drawing.Point(12, $y); $cbPrivacy.Size = New-Object System.Drawing.Size(490, 20); $cbPrivacy.Checked = $cfg.privacyClean; $sd.Controls.Add($cbPrivacy)
    $y += 24

    $btnSave = New-Object System.Windows.Forms.Button
    $btnSave.Text = '保存'
    $btnSave.Location = New-Object System.Drawing.Point(380, $y)
    $btnSave.Size = New-Object System.Drawing.Size(75, 28)
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = '取消'
    $btnCancel.Location = New-Object System.Drawing.Point(465, $y)
    $btnCancel.Size = New-Object System.Drawing.Size(75, 28)
    $sd.Controls.AddRange(@($btnSave, $btnCancel))

    $btnSave.Add_Click({
        $new = [PSCustomObject]@{
            huorongPath        = $rows['huorongPath'].Text.Trim()
            pclPath            = $rows['pclPath'].Text.Trim()
            ramPressurePct     = $RamPressureUsedPct
            monitorIntervalSec = $MonitorIntervalSec
            trayNotify         = $false
            gndEnabled         = $cbGnd.Checked
            gndProcesses       = $tbGndProc.Text.Trim()
            diskFreeThresholdPct = 10
            idleMinutes        = 5
            optimizeStrength   = 'strong'
            startupDelaySec    = 0
            dailyEmptyRecycle  = $cbRecycle.Checked
            restoreEnabled     = $cbRestore.Checked
            restoreKeepDays    = 30
            privacyClean       = $cbPrivacy.Checked
            autoUpdate         = $cbAutoUpdate.Checked
            updateUrl          = $tbUpdUrl.Text.Trim()
            updateIntervalDays = 7
        }
        $bad = @()
        if ($new.huorongPath -and -not (Test-Path $new.huorongPath)) { $bad += '火绒' }
        if ($new.pclPath -and -not (Test-Path $new.pclPath)) { $bad += 'PCL' }
        $thr = 0; $intv = 0; $disk = 0; $idle = 0; $delay = 0
        if (-not [int]::TryParse($tbThresh.Text, [ref]$thr)) { $bad += '阈值(需整数)' }
        elseif ($thr -lt 50 -or $thr -gt 99) { $bad += '阈值(需50-99)' }
        if (-not [int]::TryParse($tbInt.Text, [ref]$intv)) { $bad += '间隔(需整数)' }
        elseif ($intv -lt 10) { $bad += '间隔(≥10秒)' }
        if (-not [int]::TryParse($tbDisk.Text, [ref]$disk)) { $bad += '磁盘阈值(需整数)' }
        elseif ($disk -lt 1 -or $disk -gt 90) { $bad += '磁盘阈值(1-90)' }
        if (-not [int]::TryParse($tbIdle.Text, [ref]$idle)) { $bad += '空闲(需整数)' }
        elseif ($idle -lt 0) { $bad += '空闲(≥0)' }
        if (-not [int]::TryParse($tbDelay.Text, [ref]$delay)) { $bad += '延迟(需整数)' }
        elseif ($delay -lt 0) { $bad += '延迟(≥0)' }
        $udays = 0
        if (-not [int]::TryParse($tbUpdDays.Text, [ref]$udays)) { $bad += '更新间隔(需整数)' }
        elseif ($udays -lt 1 -or $udays -gt 365) { $bad += '更新间隔(1-365天)' }
        $keep = 0
        if (-not [int]::TryParse($tbKeep.Text, [ref]$keep)) { $bad += '保留天数(需整数)' }
        elseif ($keep -lt 1 -or $keep -gt 3650) { $bad += '保留天数(1-3650天)' }
        if ($bad.Count -gt 0) {
            [System.Windows.Forms.MessageBox]::Show('请修正: ' + ($bad -join '、'), '提示', 'OK', 'Warning')
            return
        }
        $new.ramPressurePct = $thr
        $new.monitorIntervalSec = $intv
        $new.diskFreeThresholdPct = $disk
        $new.idleMinutes = $idle
        $new.startupDelaySec = $delay
        $new.optimizeStrength = if ($cbStrength.SelectedIndex -eq 1) { 'standard' } else { 'strong' }
        $new.trayNotify = $cbNotify.Checked
        $new.autoUpdate = $cbAutoUpdate.Checked
        $new.updateUrl = $tbUpdUrl.Text.Trim()
        $new.updateIntervalDays = $udays
        $new.restoreEnabled = $cbRestore.Checked
        $new.restoreKeepDays = $keep
        Save-Settings $new
        # 立即应用到当前运行实例
        $script:RamPressureUsedPct = $thr
        $script:MonitorIntervalSec = $intv
        $script:trayNotify = $cbNotify.Checked
        $script:gndEnabled = $cbGnd.Checked
        $script:gndProcesses = $tbGndProc.Text.Trim()
        $script:diskFreeThresholdPct = $disk
        $script:idleMinutes = $idle
        $script:optimizeStrength = $new.optimizeStrength
        $script:startupDelaySec = $delay
        $script:dailyEmptyRecycle = $cbRecycle.Checked
        $script:restoreEnabled = $cbRestore.Checked
        $script:restoreKeepDays = $keep
        $script:privacyClean = $cbPrivacy.Checked
        $script:autoUpdate = $cbAutoUpdate.Checked
        $script:updateUrl = $tbUpdUrl.Text.Trim()
        $script:updateIntervalDays = $udays
        if ($timer) { $timer.Interval = $intv * 1000 }
        Update-AutoButtons
        $script:lblStatus.Text = "设置已保存并生效（阈值 $thr% / 间隔 ${intv}s）"
        $sd.DialogResult = 'OK'; $sd.Close()
    })
    $btnCancel.Add_Click({ $sd.DialogResult = 'Cancel'; $sd.Close() })
    $sd.ShowDialog() | Out-Null
}

# ---- run-log viewer (read-only, user-triggered) ----
function Show-LogDialog {
    $ld = New-Object System.Windows.Forms.Form
    $ld.Text = '运行日志'
    $ld.Size = New-Object System.Drawing.Size(560, 440)
    $ld.StartPosition = 'CenterParent'
    $ld.FormBorderStyle = 'FixedDialog'
    $ld.MaximizeBox = $false
    $ld.MinimizeBox = $false
    $ld.Owner = $form
    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true
    $tb.ReadOnly = $true
    $tb.ScrollBars = 'Vertical'
    $tb.Font = New-Object System.Drawing.Font('Consolas', 9)
    $tb.Location = New-Object System.Drawing.Point(12, 12)
    $tb.Size = New-Object System.Drawing.Size(536, 360)
    $ld.Controls.Add($tb)
    $btnRefresh = New-Object System.Windows.Forms.Button; $btnRefresh.Text = '刷新'; $btnRefresh.Location = New-Object System.Drawing.Point(372, 384); $btnRefresh.Size = New-Object System.Drawing.Size(90, 28)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(468, 384); $btnClose.Size = New-Object System.Drawing.Size(80, 28)
    $ld.Controls.AddRange(@($btnRefresh, $btnClose))
    function Refresh-Log {
        $out = @()
        foreach ($n in @('clean_daily', 'optimize_mem')) {
            $p = Join-Path $env:LOCALAPPDATA "CleanOpt\$n.log"
            $out += "===== $n.log ====="
            if (Test-Path $p) { $out += (Get-Content -Path $p -Encoding UTF8 -Tail 150) } else { $out += '(无记录)' }
            $out += ''
        }
        $tb.Text = $out -join "`r`n"
        $tb.SelectionStart = $tb.Text.Length
    }
    $btnRefresh.Add_Click({ Refresh-Log })
    $btnClose.Add_Click({ $ld.DialogResult = 'Cancel'; $ld.Close() })
    Refresh-Log
    $ld.ShowDialog() | Out-Null
}

# ---- 审计日志 (P3·操作留痕) ----
function Write-Audit {
    param([string]$Action, [string]$Detail = '')
    try {
        $af = Join-Path $env:LOCALAPPDATA 'CleanOpt\audit.log'
        $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        Add-Content -Path $af -Value "$ts`t$Action`t$Detail" -Encoding UTF8
    } catch { }
}

function Show-AuditDialog {
    $ad = New-Object System.Windows.Forms.Form
    $ad.Text = '操作审计'
    $ad.Size = New-Object System.Drawing.Size(620, 460)
    $ad.StartPosition = 'CenterParent'
    $ad.FormBorderStyle = 'FixedDialog'
    $ad.MaximizeBox = $false
    $ad.MinimizeBox = $false
    $ad.Owner = $form
    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true; $tb.ReadOnly = $true; $tb.ScrollBars = 'Vertical'
    $tb.Font = New-Object System.Drawing.Font('Consolas', 9)
    $tb.Location = New-Object System.Drawing.Point(12, 12)
    $tb.Size = New-Object System.Drawing.Size(596, 380)
    $ad.Controls.Add($tb)
    $btnRefresh = New-Object System.Windows.Forms.Button; $btnRefresh.Text = '刷新'; $btnRefresh.Location = New-Object System.Drawing.Point(428, 404); $btnRefresh.Size = New-Object System.Drawing.Size(90, 28)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '关闭'; $btnClose.Location = New-Object System.Drawing.Point(524, 404); $btnClose.Size = New-Object System.Drawing.Size(80, 28)
    $ad.Controls.AddRange(@($btnRefresh, $btnClose))
    function Refresh-Audit {
        $af = Join-Path $env:LOCALAPPDATA 'CleanOpt\audit.log'
        if (Test-Path $af) { $tb.Text = (Get-Content -Path $af -Encoding UTF8 -Tail 200) -join "`r`n" } else { $tb.Text = '(暂无操作记录)' }
        $tb.SelectionStart = $tb.Text.Length
    }
    $btnRefresh.Add_Click({ Refresh-Audit })
    $btnClose.Add_Click({ $ad.DialogResult = 'Cancel'; $ad.Close() })
    Refresh-Audit
    $ad.ShowDialog() | Out-Null
}

# ---- 自定义清理规则 (P3) ----
function Get-CustomRules {
    $f = Join-Path $root 'custom_rules.json'
    if (Test-Path $f) {
        try { return @(Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { }
    }
    return @()
}
function Save-CustomRules {
    param($Rules)
    try {
        $f = Join-Path $root 'custom_rules.json'
        $d = Split-Path $f -Parent
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        @($Rules) | ConvertTo-Json -Depth 4 | Set-Content -Path $f -Encoding UTF8
        return $true
    } catch { return $false }
}
function Show-CustomRulesDialog {
    $crd = New-Object System.Windows.Forms.Form
    $crd.Text = '自定义清理规则'
    $crd.Size = New-Object System.Drawing.Size(560, 440)
    $crd.StartPosition = 'CenterParent'
    $crd.FormBorderStyle = 'FixedDialog'
    $crd.MaximizeBox = $false; $crd.MinimizeBox = $false
    $crd.Owner = $form
    $lv = New-Object System.Windows.Forms.ListView
    $lv.Location = New-Object System.Drawing.Point(12, 12); $lv.Size = New-Object System.Drawing.Size(536, 300)
    $lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.GridLines = $true
    $lv.Columns.Add('路径/通配符', 300) | Out-Null
    $lv.Columns.Add('模式', 90) | Out-Null
    $lv.Columns.Add('含子目录', 70) | Out-Null
    $lv.Columns.Add('启用', 50) | Out-Null
    $crd.Controls.Add($lv)
    $btnAdd = New-Object System.Windows.Forms.Button; $btnAdd.Text = '添加'; $btnAdd.Location = New-Object System.Drawing.Point(12, 324); $btnAdd.Size = New-Object System.Drawing.Size(90, 28)
    $btnDel = New-Object System.Windows.Forms.Button; $btnDel.Text = '删除'; $btnDel.Location = New-Object System.Drawing.Point(110, 324); $btnDel.Size = New-Object System.Drawing.Size(90, 28)
    $btnToggle = New-Object System.Windows.Forms.Button; $btnToggle.Text = '启用/禁用'; $btnToggle.Location = New-Object System.Drawing.Point(208, 324); $btnToggle.Size = New-Object System.Drawing.Size(100, 28)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text = '完成'; $btnClose.Location = New-Object System.Drawing.Point(468, 324); $btnClose.Size = New-Object System.Drawing.Size(80, 28)
    $crd.Controls.AddRange(@($btnAdd, $btnDel, $btnToggle, $btnClose))
    $lblHint = New-Object System.Windows.Forms.Label
    $lblHint.Location = New-Object System.Drawing.Point(12, 360); $lblHint.Size = New-Object System.Drawing.Size(536, 40)
    $lblHint.Font = New-Object System.Drawing.Font('Segoe UI', 9); $lblHint.ForeColor = $script:cGray
    $lblHint.Text = '支持路径或通配符（如 C:\Temp 或 D:\Build\*.tmp）。规则在执行清理时一并处理，且走隔离（可还原）。'
    $crd.Controls.Add($lblHint)
    function Refresh-List {
        $lv.Items.Clear()
        foreach ($r in $script:_crRules) {
            $it = New-Object System.Windows.Forms.ListViewItem($r.path)
            $it.SubItems.Add($(if ($r.pattern) { $r.pattern } else { '*' })) | Out-Null
            $it.SubItems.Add($(if ($null -ne $r.recurse) { [bool]$r.recurse } else { $true })) | Out-Null
            $it.SubItems.Add($(if ($r.enabled -ne $false) { '是' } else { '否' })) | Out-Null
            $lv.Items.Add($it) | Out-Null
        }
    }
    $script:_crRules = @(Get-CustomRules)
    Refresh-List
    $btnAdd.Add_Click({
        $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
        $fbd.Description = '选择要清理的目录（清理其下文件）'
        if ($fbd.ShowDialog($crd) -eq 'OK') {
            $p = $fbd.SelectedPath
            $script:_crRules += [PSCustomObject]@{ path = $p; pattern = '*'; recurse = $true; enabled = $true }
            Refresh-List
        }
    })
    $btnDel.Add_Click({
        if ($lv.SelectedItems.Count -gt 0) {
            $idx = $lv.SelectedItems[0].Index
            $script:_crRules = @($script:_crRules | Where-Object { $_ -ne $script:_crRules[$idx] })
            Refresh-List
        }
    })
    $btnToggle.Add_Click({
        if ($lv.SelectedItems.Count -gt 0) {
            $idx = $lv.SelectedItems[0].Index
            $r = $script:_crRules[$idx]
            $r.enabled = ($r.enabled -eq $false)
            Refresh-List
        }
    })
    $btnClose.Add_Click({
        if (Save-CustomRules $script:_crRules) {
            Write-Audit "自定义规则" "已保存 $(@($script:_crRules).Count) 条规则"
            $script:lblStatus.Text = '自定义清理规则已保存'
        } else {
            $script:lblStatus.Text = '保存失败（权限不足？）'
        }
        $crd.DialogResult = 'OK'; $crd.Close()
    })
    $crd.ShowDialog() | Out-Null
}

# ---- 启动项管理 (P2): 注册表 Run / 启动文件夹 / 登录计划任务 ----
$script:disabledStartupFile = Join-Path $env:LOCALAPPDATA 'CleanOpt\disabled_startup.json'
$script:disabledStartupDir  = Join-Path $env:LOCALAPPDATA 'CleanOpt\DisabledStartup'

function Get-DisabledStartupStore {
    if (Test-Path $script:disabledStartupFile) {
        try { return @(Get-Content $script:disabledStartupFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { }
    }
    return @()
}

function Save-DisabledStartupStore {
    param($Items)
    try {
        $dir = Split-Path $script:disabledStartupFile -Parent
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        if ($Items -and @($Items).Count -gt 0) {
            @($Items) | ConvertTo-Json -Depth 4 | Set-Content -Path $script:disabledStartupFile -Encoding UTF8
        } elseif (Test-Path $script:disabledStartupFile) {
            Remove-Item -LiteralPath $script:disabledStartupFile -Force -ErrorAction SilentlyContinue
        }
    } catch { }
}

function Get-StartupItems {
    $items = @()
    # 1) 注册表 Run (当前用户 + 本机 32/64 位)
    $runKeys = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'
    )
    foreach ($k in $runKeys) {
        if (-not (Test-Path $k)) { continue }
        try {
            $kp = Get-Item -Path $k -ErrorAction Stop
            foreach ($n in $kp.GetValueNames()) {
                if (-not $n) { continue }
                $items += [PSCustomObject]@{
                    Id    = "reg|$k|$n"
                    Name  = $n
                    Kind  = 'registry'
                    Where = $k
                    Cmd   = [string]$kp.GetValue($n)
                    On    = $true
                }
            }
        } catch { }
    }
    # 2) 启动文件夹 (当前用户 + 所有用户)
    $startFolders = @(
        (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'),
        (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup')
    )
    foreach ($d in $startFolders) {
        if (-not $d -or -not (Test-Path $d)) { continue }
        Get-ChildItem -Path $d -Force -ErrorAction SilentlyContinue | ForEach-Object {
            $items += [PSCustomObject]@{
                Id    = "lnk|$($_.FullName)"
                Name  = $_.Name
                Kind  = 'folder'
                Where = $d
                Cmd   = $_.FullName
                On    = $true
            }
        }
    }
    # 3) 登录触发的计划任务 (排除系统自带, 避免误关系统组件)
    try {
        $tasks = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object {
            $_.TaskPath -and -not $_.TaskPath.StartsWith('\Microsoft\Windows')
        })
        foreach ($t in $tasks) {
            $isLogon = $false
            try {
                $isLogon = @(@($t.Triggers) | Where-Object { $_.CimClass -and $_.CimClass.CimClassName -eq 'MSFT_TaskLogonTrigger' }).Count -gt 0
            } catch { }
            if (-not $isLogon) { continue }
            $cmdText = ''
            try { $cmdText = (@($t.Actions) | ForEach-Object { ($_.Execute + ' ' + $_.Arguments).Trim() }) -join ' ; ' } catch { }
            $items += [PSCustomObject]@{
                Id    = "task|$($t.TaskPath)$($t.TaskName)"
                Name  = $t.TaskName
                Kind  = 'task'
                Where = $t.TaskPath
                Cmd   = $cmdText
                On    = ($t.State -ne 'Disabled')
            }
        }
    } catch { }
    # 4) 已被本工具禁用的项 (不在枚举结果里, 也列出来以便重新启用)
    $known = @{}
    foreach ($i in $items) { $known[$i.Id] = $true }
    foreach ($s in @(Get-DisabledStartupStore)) {
        if (-not $s -or -not $s.id) { continue }
        if ($known.ContainsKey($s.id)) { continue }
        $items += [PSCustomObject]@{
            Id    = $s.id
            Name  = $s.name
            Kind  = $s.kind
            Where = $s.loc
            Cmd   = $s.cmd
            On    = $false
        }
    }
    return $items
}

function Add-StartupStoreRecord {
    param($Item, [string]$SavedCmd, [string]$Loc)
    $store = @(Get-DisabledStartupStore | Where-Object { $_.id -ne $Item.Id })
    $store += [PSCustomObject]@{
        id      = $Item.Id
        kind    = $Item.Kind
        name    = $Item.Name
        cmd     = $SavedCmd
        loc     = $Loc
        savedAt = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    }
    Save-DisabledStartupStore $store
}

function Disable-StartupItem {
    param($Item)
    switch ($Item.Kind) {
        'registry' {
            $parts = $Item.Id.Split('|', 3)
            $k = $parts[1]; $n = $parts[2]
            $kp = Get-Item -Path $k -ErrorAction Stop
            $val = [string]$kp.GetValue($n)
            Add-StartupStoreRecord -Item $Item -SavedCmd $val -Loc $k
            Remove-ItemProperty -Path $k -Name $n -Force -ErrorAction Stop
        }
        'folder' {
            $src = $Item.Id.Substring(4)
            if (-not (Test-Path -LiteralPath $src)) { throw '源文件不存在: ' + $src }
            if (-not (Test-Path $script:disabledStartupDir)) { New-Item -ItemType Directory -Path $script:disabledStartupDir -Force | Out-Null }
            $dest = Join-Path $script:disabledStartupDir $Item.Name
            if (Test-Path -LiteralPath $dest) { $dest = Join-Path $script:disabledStartupDir ([guid]::NewGuid().ToString('N') + '_' + $Item.Name) }
            Move-Item -LiteralPath $src -Destination $dest -Force -ErrorAction Stop
            Add-StartupStoreRecord -Item $Item -SavedCmd $dest -Loc $src
        }
        'task' {
            $tn = $Item.Id.Substring(5)
            Disable-ScheduledTask -TaskName $tn -ErrorAction Stop | Out-Null
            Add-StartupStoreRecord -Item $Item -SavedCmd $Item.Cmd -Loc $tn
        }
        default { throw '未知类型: ' + $Item.Kind }
    }
}

function Enable-StartupItem {
    param($Item)
    $store = @(Get-DisabledStartupStore)
    $rec = @($store | Where-Object { $_.id -eq $Item.Id } | Select-Object -First 1)
    switch ($Item.Kind) {
        'registry' {
            if ($rec.Count -eq 0) { throw '未找到备份记录，无法还原' }
            $parts = $Item.Id.Split('|', 3)
            $k = $parts[1]; $n = $parts[2]
            if (-not (Test-Path $k)) { New-Item -Path $k -Force -ErrorAction Stop | Out-Null }
            New-ItemProperty -Path $k -Name $n -Value $rec[0].cmd -PropertyType String -Force -ErrorAction Stop | Out-Null
        }
        'folder' {
            if ($rec.Count -eq 0) { throw '未找到备份记录，无法还原' }
            if (-not (Test-Path -LiteralPath $rec[0].cmd)) { throw '备份文件已丢失: ' + $rec[0].cmd }
            $parent = Split-Path $rec[0].loc -Parent
            if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force -ErrorAction Stop | Out-Null }
            Move-Item -LiteralPath $rec[0].cmd -Destination $rec[0].loc -Force -ErrorAction Stop
        }
        'task' {
            $tn = $Item.Id.Substring(5)
            Enable-ScheduledTask -TaskName $tn -ErrorAction Stop | Out-Null
        }
        default { throw '未知类型: ' + $Item.Kind }
    }
    Save-DisabledStartupStore @($store | Where-Object { $_.id -ne $Item.Id })
}

function Show-StartupDialog {
    $sud = New-Object System.Windows.Forms.Form
    $sud.Text = '启动项管理'
    $sud.Size = New-Object System.Drawing.Size(880, 560)
    $sud.StartPosition = 'CenterParent'
    $sud.FormBorderStyle = 'Sizable'
    $sud.MaximizeBox = $true
    $sud.MinimumSize = New-Object System.Drawing.Size(720, 400)
    $sud.Icon = $script:appIcon

    $lv = New-Object System.Windows.Forms.ListView
    $lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.CheckBoxes = $true
    $lv.GridLines = $true; $lv.MultiSelect = $true; $lv.HideSelection = $false
    $lv.Location = New-Object System.Drawing.Point(12, 12)
    $lv.Size = New-Object System.Drawing.Size(840, 430)
    $lv.Anchor = 'Top, Bottom, Left, Right'
    $lv.Columns.Add('名称', 190) | Out-Null
    $lv.Columns.Add('类型', 90)  | Out-Null
    $lv.Columns.Add('位置', 250) | Out-Null
    $lv.Columns.Add('命令 / 目标', 290) | Out-Null
    $sud.Controls.Add($lv)

    $lblHint = New-Object System.Windows.Forms.Label
    $lblHint.Text = '勾选要操作的启动项。禁用前会保存原值，可随时启用还原；计划任务类需要管理员权限。'
    $lblHint.Location = New-Object System.Drawing.Point(12, 452)
    $lblHint.Size = New-Object System.Drawing.Size(600, 20)
    $lblHint.ForeColor = [System.Drawing.Color]::Gray
    $lblHint.Anchor = 'Bottom, Left'
    $sud.Controls.Add($lblHint)

    $by = 482
    $btnDis = New-Object System.Windows.Forms.Button; $btnDis.Text = '禁用选中'; $btnDis.Location = New-Object System.Drawing.Point(430, $by); $btnDis.Size = New-Object System.Drawing.Size(100, 28); $btnDis.Anchor = 'Bottom, Right'
    $btnEn  = New-Object System.Windows.Forms.Button; $btnEn.Text  = '启用选中'; $btnEn.Location  = New-Object System.Drawing.Point(540, $by); $btnEn.Size  = New-Object System.Drawing.Size(100, 28); $btnEn.Anchor  = 'Bottom, Right'
    $btnRf  = New-Object System.Windows.Forms.Button; $btnRf.Text  = '刷新';     $btnRf.Location  = New-Object System.Drawing.Point(650, $by); $btnRf.Size  = New-Object System.Drawing.Size(90, 28);  $btnRf.Anchor  = 'Bottom, Right'
    $btnCl  = New-Object System.Windows.Forms.Button; $btnCl.Text  = '关闭';     $btnCl.Location  = New-Object System.Drawing.Point(750, $by); $btnCl.Size  = New-Object System.Drawing.Size(100, 28); $btnCl.Anchor  = 'Bottom, Right'
    $sud.Controls.AddRange(@($btnDis, $btnEn, $btnRf, $btnCl))

    function Load-StartupList {
        $lv.Items.Clear()
        $items = @(Get-StartupItems)
        foreach ($it in $items) {
            $lvi = New-Object System.Windows.Forms.ListViewItem($it.Name)
            $kindText = switch ($it.Kind) {
                'registry' { '注册表' }
                'folder'   { '启动文件夹' }
                'task'     { '计划任务' }
                default    { $it.Kind }
            }
            $lvi.SubItems.Add($kindText) | Out-Null
            $lvi.SubItems.Add([string]$it.Where) | Out-Null
            $cmd = [string]$it.Cmd
            if ($cmd.Length -gt 110) { $cmd = $cmd.Substring(0, 110) + '…' }
            $lvi.SubItems.Add($cmd) | Out-Null
            $lvi.Tag = $it
            $lvi.Checked = [bool]$it.On
            if (-not $it.On) { $lvi.ForeColor = [System.Drawing.Color]::Gray }
            $lv.Items.Add($lvi) | Out-Null
        }
        $lblHint.Text = "共 $($items.Count) 项启动项。勾选后点『禁用选中』或『启用选中』。"
    }

    $btnRf.Add_Click({ Load-StartupList })
    $btnCl.Add_Click({ $sud.DialogResult = 'Cancel'; $sud.Close() })

    $btnDis.Add_Click({
        $sel = @($lv.Items | Where-Object { $_.Checked -and $_.Tag -and $_.Tag.On })
        if ($sel.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show('请勾选当前处于"启用"状态的启动项。', '启动项管理', 'OK', 'Information'); return }
        $names = (@($sel | Select-Object -First 12 | ForEach-Object { '· ' + $_.Text })) -join "`r`n"
        if ($sel.Count -gt 12) { $names += "`r`n· …共 $($sel.Count) 项" }
        $r = [System.Windows.Forms.MessageBox]::Show("确定禁用以下启动项？`r`n`r`n$names`r`n`r`n禁用前会保存原值，可随时启用还原。", '确认禁用', 'YesNo', 'Warning')
        if ($r -ne 'Yes') { return }
        $ok = 0; $fail = 0; $lastErr = ''
        foreach ($lvi in $sel) {
            try { Disable-StartupItem -Item $lvi.Tag; $ok++ }
            catch { $fail++; $lastErr = $_.Exception.Message }
        }
        Load-StartupList
        $msg = "已禁用 $ok 项。"
        if ($fail -gt 0) { $msg += "`r`n失败 $fail 项（多为系统级计划任务，需要管理员权限）。" ; if ($lastErr) { $msg += "`r`n最后错误: $lastErr" } }
        $lblHint.Text = $msg -replace "`r`n", ' '
    })

    $btnEn.Add_Click({
        $sel = @($lv.Items | Where-Object { $_.Checked })
        if ($sel.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show('请勾选要启用的启动项。', '启动项管理', 'OK', 'Information'); return }
        $ok = 0; $fail = 0; $lastErr = ''
        foreach ($lvi in $sel) {
            try { Enable-StartupItem -Item $lvi.Tag; $ok++ }
            catch { $fail++; $lastErr = $_.Exception.Message }
        }
        Load-StartupList
        $msg = "已启用 $ok 项。"
        if ($fail -gt 0) { $msg += " 失败 $fail 项" + $(if ($lastErr) { "（$lastErr）" } else { '（可能需要管理员权限）' }) }
        $lblHint.Text = $msg
    })

    Load-StartupList
    $sud.ShowDialog() | Out-Null
}

# ---- buttons ----
$btnOptimize.Add_Click({ Invoke-Optimize; $lblStatus.Text = '已触发内存优化（后台，无窗口）' })

$btnClean.Add_Click({
    $lblStatus.Text = '清理中…（后台，无窗口）'
    $bw.RunWorkerAsync()
})

$btnRecycle.Add_Click({
    $lblStatus.Text = '正在清空回收站…（后台，无窗口）'
    $bwRecycle.RunWorkerAsync()
})

$btnLaunch.Add_Click({ Show-LauncherDialog })

$btnSettings.Add_Click({ Show-SettingsDialog })

# 一键全面优化按钮的 Click 已在定义时绑定到 $pnlRunAll/$lblRunAll

$btnLog.Add_Click({ Show-LogDialog })
$btnAudit.Add_Click({ Show-AuditDialog })
$btnCustomRules.Add_Click({ Show-CustomRulesDialog })

$btnAbout.Add_Click({ Show-AboutDialog })

$btnDiag.Add_Click({ Export-Diagnostics })

$btnMem.Add_Click({ Show-MemHogs })
$btnMemDiag.Add_Click({ Show-MemDiag })

$btnKill.Add_Click({ Show-ProcessKiller })

$btnNet.Add_Click({ Repair-Network })

$btnClip.Add_Click({ Clear-ClipboardSafe })

$btnLock.Add_Click({ Lock-WorkStation })

$btnUpdate.Add_Click({ Show-UpdateDialog })
$btnRestore.Add_Click({ Show-RestoreDialog })
$btnStartup.Add_Click({ Show-StartupDialog })

$btnPrivacy.Add_Click({
    $lblStatus.Text = '正在清理隐私痕迹…（后台，无窗口）'
    $bwPrivacy.RunWorkerAsync()
})

$btnRegister.Add_Click({
    try {
        & "$root\Register-Tasks.ps1" -DailyTime '03:00'
        $ok = Get-ScheduledTask -TaskName 'CleanOpt-Daily' -ErrorAction SilentlyContinue
        $lblStatus.Text = if ($ok) { '每日任务已注册（03:00，静默运行）' } else { '注册失败，请手动以管理员运行 Register-Tasks.ps1' }
    } catch {
        $lblStatus.Text = '注册失败: ' + $_.Exception.Message
    }
})

$btnAutostart.Add_Click({
    $t = Get-ScheduledTask -TaskName 'CleanOpt-Logon' -ErrorAction SilentlyContinue
    if ($t) {
        Unregister-ScheduledTask -TaskName 'CleanOpt-Logon' -Confirm:$false -ErrorAction SilentlyContinue
        $btnAutostart.Text = '开机自启: 关'
        $lblStatus.Text = '已关闭开机自启'
    } else {
        & "$root\Register-Tasks.ps1" -DailyTime '03:00'
        $btnAutostart.Text = '开机自启: 开'
        $lblStatus.Text = '已开启开机自启（登录后后台运行）'
    }
})

$btnExit.Add_Click({ $global:forceExit = $true; if ($notifyIcon) { $notifyIcon.Icon = $null }; Dispose-BandIcons; $notifyIcon.Dispose(); $form.Close() })

# ---- 扫描垃圾 (评估各安全目录体积) + 选择性清理 ----
function Get-CleanScanCategories {
    $sumSize = {
        param($paths)
        $s = 0
        foreach ($p in $paths) {
            if (Test-Path $p) {
                $its = @(Get-ChildItem -Path $p -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer })
                $s += ($its | Measure-Object -Property Length -Sum).Sum
            }
        }
        return $s
    }
    $cntOf = {
        param($path, [string]$filter = '')
        if (-not (Test-Path $path)) { return 0 }
        if ($filter) { return @(Get-ChildItem -Path $path -Include $filter -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer }).Count }
        return @(Get-ChildItem -Path $path -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer }).Count
    }
    $cats = @()
    $sz = & $sumSize @($env:TEMP, "$env:SystemRoot\Temp")
    $cnt = & $cntOf $env:TEMP; $cnt += & $cntOf "$env:SystemRoot\Temp"
    $cats += [PSCustomObject]@{ Key='temp'; Name='系统/用户临时文件 (TEMP)'; SizeMB=[math]::Round($sz/1MB,1); Count=$cnt; Note='临时文件' }
    $sz = & $sumSize @("$env:SystemRoot\Prefetch")
    $cnt = & $cntOf "$env:SystemRoot\Prefetch"
    $cats += [PSCustomObject]@{ Key='prefetch'; Name='Prefetch 预读取缓存'; SizeMB=[math]::Round($sz/1MB,1); Count=$cnt; Note='系统预读' }
    $sz = & $sumSize @("$env:LOCALAPPDATA\Microsoft\Windows\Explorer")
    $cnt = & $cntOf "$env:LOCALAPPDATA\Microsoft\Windows\Explorer" 'thumbcache_*.db'
    $cats += [PSCustomObject]@{ Key='thumbcache'; Name='缩略图缓存'; SizeMB=[math]::Round($sz/1MB,1); Count=$cnt; Note='缩略图' }
    $sz = & $sumSize @("$env:SystemRoot\SoftwareDistribution\DeliveryOptimizationCache")
    $cnt = & $cntOf "$env:SystemRoot\SoftwareDistribution\DeliveryOptimizationCache"
    $cats += [PSCustomObject]@{ Key='deliveryopt'; Name='Delivery Optimization 缓存'; SizeMB=[math]::Round($sz/1MB,1); Count=$cnt; Note='更新缓存' }
    $sz = 0; $cnt = 0
    $browserRoots = @("$env:LOCALAPPDATA\Microsoft\Edge\User Data", "$env:LOCALAPPDATA\Google\Chrome\User Data")
    $cacheFolders = @('Cache','Cache2','Code Cache','GPUCache','Media Cache','Service Worker\CacheStorage')
    foreach ($root in $browserRoots) {
        if (-not (Test-Path $root)) { continue }
        Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
            $profile = $_.FullName
            foreach ($cf in $cacheFolders) {
                $pp = Join-Path $profile $cf
                if (Test-Path $pp) {
                    $its = @(Get-ChildItem -Path $pp -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer })
                    $cnt += $its.Count
                    $sz += ($its | Measure-Object -Property Length -Sum).Sum
                }
            }
        }
    }
    $cats += [PSCustomObject]@{ Key='browsercache'; Name='浏览器缓存 (Edge/Chrome)'; SizeMB=[math]::Round($sz/1MB,1); Count=$cnt; Note='浏览器缓存' }
    $cats += [PSCustomObject]@{ Key='dism'; Name='系统组件清理 (DISM)'; SizeMB=$null; Count=0; Note='每周限一次' }
    # 自定义清理规则 (P3): 作为可勾选类别出现在扫描结果里
    $customRules = Get-CustomRules
    if ($customRules -and @($customRules).Count -gt 0) {
        $sz = 0; $cnt = 0
        foreach ($r in $customRules) {
            $p = $r.path
            if (-not $p -or -not (Test-Path $p)) { continue }
            $pat = if ($r.pattern) { $r.pattern } else { '*' }
            $rec = if ($null -ne $r.recurse) { [bool]$r.recurse } else { $true }
            $its = @(Get-ChildItem -LiteralPath $p -Recurse:$rec -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer -and ($pat -eq '*' -or $_.Name -like $pat) })
            if ($its.Count -eq 0 -and (Test-Path -LiteralPath $p)) { $its = @(Get-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer }) }
            $cnt += $its.Count
            $sz += ($its | Measure-Object -Property Length -Sum).Sum
        }
        if ($cnt -gt 0) { $cats += [PSCustomObject]@{ Key='custom'; Name='自定义清理规则'; SizeMB=[math]::Round($sz/1MB,1); Count=$cnt; Note='用户自定义路径' } }
    }
    return $cats
}

$bwScan = New-Object System.ComponentModel.BackgroundWorker
$bwScan.Add_DoWork({ $script:scanCats = Get-CleanScanCategories })
$bwScan.Add_RunWorkerCompleted({
    $lvScan.Items.Clear()
    $total = 0
    foreach ($c in $script:scanCats) {
        $li = New-Object System.Windows.Forms.ListViewItem($c.Name)
        $li.SubItems.Add($(if ($null -eq $c.SizeMB) { '—' } else { "$($c.SizeMB) MB" }))
        $li.SubItems.Add($(if ($c.Count -eq 0) { '—' } else { "$($c.Count)" }))
        $li.SubItems.Add($c.Note)
        $li.Tag = $c.Key
        $li.Checked = $true
        $lvScan.Items.Add($li) | Out-Null
        if ($null -ne $c.SizeMB) { $total += $c.SizeMB }
    }
    $btnExecClean.Enabled = $true
    $script:lblStatus.Text = "扫描完成：可选清理约 $total MB（共 $($lvScan.Items.Count) 类，勾选后执行）"
})

$bwExecClean = New-Object System.ComponentModel.BackgroundWorker
$bwExecClean.Add_DoWork({
    param($s, $e)
    $keys = @($script:execKeys)
    $selFile = Join-Path $env:LOCALAPPDATA 'CleanOpt\clean_sel.json'
    try { $keys | ConvertTo-Json -Depth 2 | Set-Content -Path $selFile -Encoding UTF8 } catch { }
    Start-Process -FilePath 'powershell.exe' `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\clean_daily.ps1`" -CategoriesFile `"$selFile`"" `
        -WindowStyle Hidden -Wait
})
$bwExecClean.Add_RunWorkerCompleted({
    Update-Status
    $note = ''
    try {
        $last = Get-Content -Path (Join-Path $env:LOCALAPPDATA 'CleanOpt\clean_daily.log') -Encoding UTF8 -Tail 6 -ErrorAction SilentlyContinue
        $rb = $last | Where-Object { $_ -match 'RESTORE_BATCH\|' } | Select-Object -Last 1
        if ($rb -match 'RESTORE_BATCH\|([^|]+)\|(\d+)\|') { $note = '（已隔离 ' + $matches[2] + ' 个文件，可还原）' }
    } catch { }
    $script:lblStatus.Text = '选中项清理完成' + $note + '（' + (Get-Date -Format 'HH:mm:ss') + '）'
    Write-Audit "垃圾清理" "选择性执行完成: $($script:execKeys.Count) 类$note"
    $btnExecClean.Enabled = $false
})

$btnScan.Add_Click({
    $btnExecClean.Enabled = $false
    $script:lblStatus.Text = '扫描中…（统计各安全目录体积）'
    $bwScan.RunWorkerAsync()
})
$btnExecClean.Add_Click({
    $checked = @(); foreach ($item in $lvScan.Items) { if ($item.Checked) { $checked += $item.Tag } }
    if ($checked.Count -eq 0) { $script:lblStatus.Text = '请先勾选要清理的类别'; return }
    $script:execKeys = $checked
    $btnExecClean.Enabled = $false
    $script:lblStatus.Text = '清理中…（后台，无窗口）'
    $bwExecClean.RunWorkerAsync()
})
$btnMemOpt.Add_Click({ Invoke-Optimize; $script:lblStatus.Text = '已触发内存优化（后台，无窗口）' })
$chkPrivacyAuto.Add_Click({
    $script:privacyClean = $chkPrivacyAuto.Checked
    $sf = Join-Path $root 'settings.json'
    try {
        $j = if (Test-Path $sf) { Get-Content $sf -Raw -Encoding UTF8 | ConvertFrom-Json } else { [PSCustomObject]@{} }
        $j.privacyClean = $script:privacyClean
        $j | ConvertTo-Json -Depth 5 | Set-Content -Path $sf -Encoding UTF8
        $script:lblStatus.Text = if ($script:privacyClean) { '已开启：隐私痕迹随常规清理自动执行' } else { '已关闭：隐私痕迹仅手动清理' }
    } catch { $script:lblStatus.Text = '保存失败: ' + $_.Exception.Message }
})

# ---- 强力卸载页事件 ----
$btnScanApp.Add_Click({
    $btnScanApp.Enabled = $false
    $lvUninstall.Items.Clear()
    $script:lblStatus.Text = '正在扫描已安装程序…'
    # 后台扫描避免卡 UI
    $bwScanApp = New-Object System.ComponentModel.BackgroundWorker
    $bwScanApp.Add_DoWork({
        param($s, $e)
        $apps = @()
        $regPaths = @(
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
            'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
        )
        foreach ($rp in $regPaths) {
            if (Test-Path $rp) {
                Get-ChildItem -Path $rp -ErrorAction SilentlyContinue | ForEach-Object {
                    try {
                        $props = Get-ItemProperty -Path $_.PSPath -ErrorAction SilentlyContinue
                        if ($props.DisplayName -and $props.DisplayName.Trim()) {
                            $apps += [PSCustomObject]@{
                                Name    = $props.DisplayName.Trim()
                                Version = $(if($props.DisplayVersion){$props.DisplayVersion}else{'—'})
                                Date    = $(if($props.InstallDate){$props.InstallDate}else{'—'})
                                UninstallString = $(if($props.UninstallString){$props.UninstallString}else{''})
                                InstallLocation = $(if($props.InstallLocation){$props.InstallLocation}else{''})
                                RegPath = $_.PSPath
                            }
                        }
                    } catch { }
                }
            }
        }
        $e.Result = $apps | Sort-Object Name
    })
    $bwScanApp.Add_RunWorkerCompleted({
        $btnScanApp.Enabled = $true
        $apps = $e.Result
        foreach ($a in $apps) {
            $li = New-Object System.Windows.Forms.ListViewItem($a.Name)
            $li.SubItems.Add($a.Version)
            $li.SubItems.Add($a.Date)
            $unStr = if ($a.UninstallString.Length -gt 60) { $a.UninstallString.Substring(0, 57) + '...' } else { $a.UninstallString }
            $li.SubItems.Add($unStr)
            $li.Tag = $a
            $lvUninstall.Items.Add($li) | Out-Null
        }
        $script:lblStatus.Text = "扫描完成：共 $($lvUninstall.Items.Count) 个已安装程序"
    })
    $bwScanApp.RunWorkerAsync()
})

$btnDoUninstall.Add_Click({
    if ($lvUninstall.SelectedItems.Count -eq 0) { $script:lblStatus.Text = '请先选择要卸载的程序'; return }
    $app = $lvUninstall.SelectedItems[0].Tag
    if (-not $app.UninstallString) { $script:lblStatus.Text = '该程序无卸载命令，请使用「强制清除」'; return }
    $r = [System.Windows.Forms.MessageBox]::Show("确定要卸载「$($app.Name)」吗？`n`n将运行其官方卸载程序。", '确认卸载', 'YesNo', 'Warning')
    if ($r -ne 'Yes') { return }
    $script:lblStatus.Text = "正在卸载 $($app.Name)…"
    Start-Process -FilePath 'cmd.exe' -ArgumentList "/c `"$($app.UninstallString)`"" -Wait
    $script:lblStatus.Text = "卸载命令已执行：$($app.Name)（$(Get-Date -Format 'HH:mm:ss')）"
    Write-Audit "卸载" "标准卸载: $($app.Name) | $($app.UninstallString)"
})

$btnForceRemove.Add_Click({
    if ($lvUninstall.SelectedItems.Count -eq 0) { $script:lblStatus.Text = '请先选择要强制清除的程序'; return }
    $app = $lvUninstall.SelectedItems[0].Tag
    $r2 = [System.Windows.Forms.MessageBox]::Show("⚠️ 危险操作！`n`n将删除「$($app.Name)」的：`n• 注册表卸载项`n• 安装目录（若存在）`n`n此操作不可还原！确定继续？", '⚠️ 强制清除确认', 'YesNo', 'Warning')
    if ($r2 -ne 'Yes') { return }
    $script:lblStatus.Text = "正在强制清除 $($app.Name)…"
    $removed = @()
    try {
        if (Test-Path $app.RegPath) { Remove-Item -Path $app.RegPath -Recurse -Force -ErrorAction SilentlyContinue; $removed += '注册表项' }
        if ($app.InstallLocation -and (Test-Path $app.InstallLocation)) {
            Remove-Item -Path $app.InstallLocation -Recurse -Force -ErrorAction SilentlyContinue; $removed += '安装目录'
        }
    } catch { }
    $script:lblStatus.Text = "已强制清除 $($app.Name)：($($removed -join ' + ')）"
    Write-Audit "强制清除" "已删除: $($app.Name) | $($removed -join ' + ')"
    # 刷新列表
    $btnScanApp.PerformClick()
})

$lvUninstall.Add_SelectedIndexChanged({
    $btnForceRemove.Enabled = ($lvUninstall.SelectedItems.Count -gt 0)
})

# ---- 大文件分析页事件 ----
$btnScanBig.Add_Click({
    $btnScanBig.Enabled = $false
    $lvBigFiles.Items.Clear()
    $topN = [int]$txtBigTop.Value
    $script:lblStatus.Text = "正在扫描 C 盘 Top-$topN 大文件（排除系统目录）…"
    $bwScanBig = New-Object System.ComponentModel.BackgroundWorker
    $bwScanBig.Add_DoWork({
        param($s, $e)
        $exclude = @('C:\Windows', 'C:\Program Files', 'C:\Program Files (x86)', 'C:\$Recycle.Bin',
                     'C:\System Volume Information', 'C:\Recovery', 'C:\pagefile.sys',
                     'C:\hiberfil.sys', 'C:\swapfile.sys')
        $files = @()
        Get-ChildItem -Path 'C:\' -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
            $full = $_.FullName
            $ok = $true
            foreach ($ex in $exclude) { if ($full.StartsWith($ex, [System.StringComparison]::OrdinalIgnoreCase)) { $ok = $false; break } }
            $ok
        } | Sort-Object Length -Descending | Select-Object -First $topN | ForEach-Object {
            $ext = $_.Extension.TrimStart('.')
            $files += [PSCustomObject]@{
                Path     = $_.FullName
                SizeMB   = [math]::Round($_.Length / 1MB, 1)
                Type     = $(if($ext){$ext}else{'文件'})
                Modified = $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')
                SizeBytes= $_.Length
            }
        }
        $e.Result = $files
    })
    $bwScanBig.Add_RunWorkerCompleted({
        $btnScanBig.Enabled = $true
        $files = $e.Result
        $totalMB = 0
        foreach ($f in $files) {
            $li = New-Object System.Windows.Forms.ListViewItem($f.Path)
            $li.SubItems.Add("$($f.SizeMB) MB")
            $li.SubItems.Add($f.Type)
            $li.SubItems.Add($f.Modified)
            $li.Tag = $f
            $lvBigFiles.Items.Add($li) | Out-Null
            $totalMB += $f.SizeMB
        }
        $totalGB = [math]::Round($totalMB / 1024, 2)
        $script:lblStatus.Text = "扫描完成：Top-$topN 大文件合计约 $totalGB GB"
    })
    $bwScanBig.RunWorkerAsync()
})

$lvBigFiles.Add_SelectedIndexChanged({
    $btnMigrate.Enabled = ($lvBigFiles.SelectedItems.Count -gt 0)
})

$btnOpenFolder.Add_Click({
    if ($lvBigFiles.SelectedItems.Count -eq 0) { $script:lblStatus.Text = '请先选择一个文件'; return }
    $f = $lvBigFiles.SelectedItems[0].Tag
    $dir = Split-Path $f.Path -Parent
    if (Test-Path $dir) { explorer.exe "/select,$($f.Path)" } else { $script:lblStatus.Text = '目录不存在' }
})

$btnMigrate.Add_Click({
    if ($lvBigFiles.SelectedItems.Count -eq 0) { return }
    $f = $lvBigFiles.SelectedItems[0].Tag
    # 使用 FolderBrowserDialog 选择目标目录
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = "选择迁移目标文件夹（将移动到该目录下）"
    $dlg.ShowNewFolderButton = $true
    if ($dlg.ShowDialog() -ne 'OK') { return }
    $targetDir = $dlg.SelectedPath
    $targetPath = Join-Path $targetDir (Split-Path $f.Path -Leaf)
    if (Test-Path $targetPath) {
        $r = [System.Windows.Forms.MessageBox]::Show("目标已存在同名文件，是否覆盖？", '覆盖确认', 'YesNo', 'Question')
        if ($r -ne 'Yes') { return }
    }
    $script:lblStatus.Text = "正在迁移 $($f.Path) → $targetDir …"
    try {
        Move-Item -Path $f.Path -Destination $targetPath -Force -ErrorAction Stop
        $sizeMB = $f.SizeMB
        $script:lblStatus.Text = "迁移完成：$([math]::Round($sizeMB,1)) MB 已移至 $targetDir"
        Write-Audit "迁移" "$($f.Path) → $targetDir ($([math]::Round($sizeMB,1)) MB)"
        $btnScanBig.PerformClick()  # 刷新列表
    } catch { $script:lblStatus.Text = '迁移失败: ' + $_.Exception.Message }
})

# ---- background worker for cleanup (keeps UI responsive) ----
$bw = New-Object System.ComponentModel.BackgroundWorker
$bw.Add_DoWork({
    Start-Process -FilePath 'powershell.exe' `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\clean_daily.ps1`"" `
        -WindowStyle Hidden -Wait
})
$bw.Add_RunWorkerCompleted({
    Update-Status
    $note = ''
    try {
        $last = Get-Content -Path (Join-Path $env:LOCALAPPDATA 'CleanOpt\clean_daily.log') -Encoding UTF8 -Tail 6 -ErrorAction SilentlyContinue
        $rb = $last | Where-Object { $_ -match 'RESTORE_BATCH\|' } | Select-Object -Last 1
        if ($rb -match 'RESTORE_BATCH\|([^|]+)\|(\d+)\|') { $note = '（已隔离 ' + $matches[2] + ' 个文件，可还原）' }
    } catch { }
    $script:lblStatus.Text = '清理完成' + $note + '（' + (Get-Date -Format 'HH:mm:ss') + '）'
})

# ---- background worker for emptying the Recycle Bin (keeps UI responsive, no popup) ----
# Resilient: native cmdlet first; if it fails (e.g. a locked file aborts the whole
# operation, or the cmdlet is unavailable), fall back to per-drive per-item deletion so
# one bad file never aborts the rest. Reports PARTIAL instead of a hard error.
$bwRecycle = New-Object System.ComponentModel.BackgroundWorker
$bwRecycle.Add_DoWork({
    param($s, $e)
    # 调用系统原生 SHEmptyRecycleBin 清空当前用户【全部盘符】回收站（与资源管理器一致，最快最彻底）
    $r = Clear-MyRecycleBin
    if (-not $r.Ok) {
        $global:recycleResult = 'ERR|' + $r.Note
    } elseif ($r.Remaining -gt 0) {
        $global:recycleResult = "PARTIAL|已清空回收站（释放 $($r.Removed) 项），仍有 $($r.Remaining) 项因被占用未清除"
    } else {
        $global:recycleResult = 'OK|' + $r.Removed
    }
})
$bwRecycle.Add_RunWorkerCompleted({
    $r = $global:recycleResult
    if ($r -like 'OK|*') {
        $n = $r.Substring(3)
        $okMsg = if ($n -match '^\d+$' -and [int]$n -gt 0) { "回收站已清空，释放 $n 项" } else { '回收站已清空' }
        $script:lblStatus.Text = $okMsg + '（' + (Get-Date -Format 'HH:mm:ss') + '）'
    } elseif ($r -like 'PARTIAL|*') {
        $script:lblStatus.Text = ($r.Substring(8)) + '（' + (Get-Date -Format 'HH:mm:ss') + '）'
    } else {
        $script:lblStatus.Text = '清空回收站失败: ' + $r.Substring(4)
    }
    Update-Status
})

# ---- background worker for privacy-trace cleanup (keeps UI responsive) ----
$bwPrivacy = New-Object System.ComponentModel.BackgroundWorker
$bwPrivacy.Add_DoWork({
    Start-Process -FilePath 'powershell.exe' `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\clean_daily.ps1`" -PrivacyOnly" `
        -WindowStyle Hidden -Wait
})
$bwPrivacy.Add_RunWorkerCompleted({
    $note = ''
    try {
        $last = Get-Content -Path (Join-Path $env:LOCALAPPDATA 'CleanOpt\clean_daily.log') -Encoding UTF8 -Tail 8 -ErrorAction SilentlyContinue
        $pl = $last | Where-Object { $_ -match 'PRIVACY_DONE\|(\d+)' } | Select-Object -Last 1
        if ($pl -match 'PRIVACY_DONE\|(\d+)') { $note = "（处理 $($matches[1]) 项）" }
    } catch { }
    $script:lblStatus.Text = '隐私痕迹已清理' + $note + '（' + (Get-Date -Format 'HH:mm:ss') + '）'
    Update-Status
})

# ---- background worker for "一键全面优化" (clean -> optimize -> recycle, silent) ----
$bwAll = New-Object System.ComponentModel.BackgroundWorker
$bwAll.Add_DoWork({
    param($s, $e)
    # 1) 清理垃圾
    Start-Process -FilePath 'powershell.exe' `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\clean_daily.ps1`"" `
        -WindowStyle Hidden -Wait
    # 2) 优化内存 (PCL 优先, 失败回退原生, 见 optimize_mem.ps1)
    $argOpt = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\optimize_mem.ps1`" -Strength $script:optimizeStrength"
    Start-Process -FilePath 'powershell.exe' -ArgumentList $argOpt -WindowStyle Hidden -Wait
    # 3) 清空回收站 (原生快速删除当前用户 SID，不卡顿)
    Clear-MyRecycleBin | Out-Null
})
$bwAll.Add_RunWorkerCompleted({
    Update-Status
    $script:lblStatus.Text = '全面优化完成（' + (Get-Date -Format 'HH:mm:ss') + '）'
    if ($script:trayNotify) { $notifyIcon.ShowBalloonTip(3000, 'CleanOpt', '全面优化完成（清理+优化+回收站）', 'Info') }
})

# ---- 应用 settings.json 中的行为设置 (启动即生效) ----
$startupSettings = Load-Settings
if ($startupSettings.ramPressurePct -and $startupSettings.ramPressurePct -ge 50 -and $startupSettings.ramPressurePct -le 99) { $script:RamPressureUsedPct = $startupSettings.ramPressurePct }
if ($startupSettings.monitorIntervalSec -and $startupSettings.monitorIntervalSec -ge 10) { $script:MonitorIntervalSec = $startupSettings.monitorIntervalSec }
$script:trayNotify = [bool]$startupSettings.trayNotify
if ($null -ne $startupSettings.gndEnabled) { $script:gndEnabled = [bool]$startupSettings.gndEnabled }
if ($startupSettings.gndProcesses) { $script:gndProcesses = $startupSettings.gndProcesses }
if ($startupSettings.diskFreeThresholdPct -and $startupSettings.diskFreeThresholdPct -ge 1 -and $startupSettings.diskFreeThresholdPct -le 90) { $script:diskFreeThresholdPct = $startupSettings.diskFreeThresholdPct }
if ($null -ne $startupSettings.idleMinutes -and $startupSettings.idleMinutes -ge 0) { $script:idleMinutes = $startupSettings.idleMinutes }
if ($startupSettings.optimizeStrength -eq 'standard' -or $startupSettings.optimizeStrength -eq 'strong') { $script:optimizeStrength = $startupSettings.optimizeStrength }
if ($null -ne $startupSettings.startupDelaySec -and $startupSettings.startupDelaySec -ge 0) { $script:startupDelaySec = $startupSettings.startupDelaySec }
if ($null -ne $startupSettings.dailyEmptyRecycle) { $script:dailyEmptyRecycle = [bool]$startupSettings.dailyEmptyRecycle }
if ($null -ne $startupSettings.restoreEnabled) { $script:restoreEnabled = [bool]$startupSettings.restoreEnabled }
if ($null -ne $startupSettings.restoreKeepDays -and $startupSettings.restoreKeepDays -ge 1) { $script:restoreKeepDays = [int]$startupSettings.restoreKeepDays }
if ($null -ne $startupSettings.privacyClean) { $script:privacyClean = [bool]$startupSettings.privacyClean }
if ($null -ne $startupSettings.autoUpdate) { $script:autoUpdate = [bool]$startupSettings.autoUpdate }
if ($startupSettings.updateUrl) { $script:updateUrl = [string]$startupSettings.updateUrl }
if ($null -ne $startupSettings.updateIntervalDays -and $startupSettings.updateIntervalDays -ge 1 -and $startupSettings.updateIntervalDays -le 365) { $script:updateIntervalDays = $startupSettings.updateIntervalDays }

Update-AutoButtons   # 启动后按 settings 刷新按钮上的 auto-on/auto-off 指示

# ---- per-minute monitor ----
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = $MonitorIntervalSec * 1000
$timer.Add_Tick({
    Update-Status
    try {
        # F2: 磁盘空间不足 -> 静默自动清理 (6 小时内只触发一次, 用 stamp 限流)
        if ($script:diskFreeThresholdPct -gt 0) {
            $low = Get-LowDiskDrive $script:diskFreeThresholdPct
            if ($low) {
                $now = Get-Date
                $stamp = Join-Path $env:LOCALAPPDATA 'CleanOpt\diskclean.stamp'
                $doClean = $true
                if (Test-Path $stamp) {
                    try { $last = [datetime]::Parse((Get-Content $stamp -Encoding UTF8 -Raw).Trim()); if (($now - $last).TotalHours -lt 6) { $doClean = $false } } catch { }
                }
                if ($doClean) {
                    # 先估算可释放空间: 过少则跳过, 避免无意义地拉起清理进程
                    $pot = Measure-CleanupPotential
                    if ($pot -lt 30MB) {
                        $script:lblStatus.Text = "磁盘空间不足($low)，但可清理空间仅 $(Format-Bytes $pot)，暂不自动清理"
                    } else {
                        (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | Set-Content -Path $stamp -Encoding UTF8
                        $script:lblStatus.Text = "磁盘空间不足($low)，自动清理中…（预计释放 $(Format-Bytes $pot)，后台无窗口）"
                        # 不 -Wait: 后台异步执行, 避免 DISM 等重操作卡住 UI 线程
                        Start-Process -FilePath 'powershell.exe' -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$root\clean_daily.ps1`"" -WindowStyle Hidden
                        if ($script:trayNotify) { $notifyIcon.ShowBalloonTip(3000, 'CleanOpt', "磁盘空间不足($low)，已自动清理", 'Info') }
                    }
                }
            }
        }
        # 自动更新检查 (检测到新版本时弹出提示，由用户决定是否前往)
        if ($script:autoUpdate -and $script:updateUrl) {
            if (-not $script:_lastUpdateCheck -or ((Get-Date) - $script:_lastUpdateCheck).TotalDays -ge $script:updateIntervalDays) {
                $script:_lastUpdateCheck = Get-Date
                $vi = Test-UpdateAvailable $script:updateUrl
                if ($vi) {
                    # v1.21: 弹出提示让用户选择，不再静默后台自动更新
                    # 本次新增「稍后提醒」(Cancel): 延后下次检测, 避免反复弹窗
                    $form.BeginInvoke({
                        $result = [System.Windows.Forms.MessageBox]::Show(
                            $form,
                            "发现新版本 v$($vi.version)`n`n$($vi.notes)`n`n是否立即前往下载新版本？`n（是=前往下载 / 否=本次跳过 / 取消=稍后提醒）",
                            'CleanOpt - 发现新版本',
                            'YesNoCancel, Question, DefaultButton2'
                        )
                        if ($result -eq 'Yes') {
                            Invoke-ApplyUpdate
                        } elseif ($result -eq 'No') {
                            $script:lblStatus.Text = "已跳过更新（当前 v$($script:AppVersion)）"
                        } else {
                            # 取消=稍后提醒: 把下次检测延后到 6 小时后
                            $script:_lastUpdateCheck = (Get-Date).AddHours(-($script:updateIntervalDays - 0.25))
                            $script:lblStatus.Text = "已稍后提醒（将在数小时后再次检查更新）"
                        }
                    })
                }
            }
        }

        # 内存紧张 -> 自动优化 (受免打扰 / 空闲 控制)
        # 复用 Update-Status 刚算好的占用率, 避免每分钟重复查询 WMI
        $usedPct = $script:_lastUsedPct
        if ($usedPct -ge $RamPressureUsedPct) {
            if (Test-ShouldSkipAutoOptimize) {
                $script:lblStatus.Text = (Get-Date -Format 'HH:mm:ss') + " 内存紧张($usedPct%)，但处于免打扰(游戏/全屏)，跳过"
            } else {
                $idleOk = $true
                if ($script:idleMinutes -gt 0) {
                    $idleMs = Get-IdleMilliseconds
                    if ($idleMs -lt ($script:idleMinutes * 60000)) { $idleOk = $false }
                }
                if ($idleOk) {
                    # 冷却: 自动优化至少间隔 10 分钟, 避免内存长期偏高时每分钟都拉起新进程反复强力清空
                    $cool = 10 * 60000
                    if (((Get-Date) - $script:_lastAutoOptimize).TotalMilliseconds -ge $cool) {
                        $script:_lastAutoOptimize = Get-Date
                        Invoke-Optimize
                        $script:lblStatus.Text = (Get-Date -Format 'HH:mm:ss') + " 内存紧张($usedPct%)，已自动优化"
                        if ($script:trayNotify) { $notifyIcon.ShowBalloonTip(3000, 'CleanOpt', "内存紧张($usedPct%)，已自动优化", 'Info') }
                    } else {
                        $script:lblStatus.Text = (Get-Date -Format 'HH:mm:ss') + " 内存紧张($usedPct%)，冷却中(10分钟内已优化)"
                    }
                } else {
                    $script:lblStatus.Text = (Get-Date -Format 'HH:mm:ss') + " 内存紧张($usedPct%)，系统使用中，稍后优化"
                }
            }
        }
    } catch { }
})
# F6: 启动延迟 —— 延迟 N 秒再开始监控
if ($script:startupDelaySec -gt 0) {
    $startupTimer = New-Object System.Windows.Forms.Timer
    $startupTimer.Interval = $script:startupDelaySec * 1000
    $startupTimer.Add_Tick({
        $timer.Start()
        $startupTimer.Stop(); $startupTimer.Dispose()
    })
    $startupTimer.Start()
} else {
    $timer.Start()
}

# ---- 单实例: 唤醒信号(被另一实例触发时打开窗口) ----
# 用 WinForms 计时器轮询命名事件: 在 UI 线程执行, 无需跨线程封送, 最稳.
$wakeTimer = New-Object System.Windows.Forms.Timer
$wakeTimer.Interval = 500
$wakeTimer.Add_Tick({
    if ($global:showEvent.WaitOne(0)) {
        $form.ShowInTaskbar = $true
        $form.Show()
        $form.WindowState = 'Normal'
        $form.Activate()
    }
})
$wakeTimer.Start()

# ---- F9: 全局热键 Ctrl+Alt+O -> 立即优化内存 ----
try {
    $global:hotkeyFilter = New-Object HotkeyFilter
    $global:hotkeyFilter.OnHotkey = {
        try {
            Invoke-Optimize
            if ($script:lblStatus) { $script:lblStatus.Text = '全局热键(Ctrl+Alt+O)已触发内存优化' }
            if ($script:trayNotify) { $notifyIcon.ShowBalloonTip(3000, 'CleanOpt', '已通过热键优化内存', 'Info') }
        } catch { }
    }
    [System.Windows.Forms.Application]::AddMessageFilter($global:hotkeyFilter)
    $null = $form.Handle   # 确保窗口句柄已创建
    # MOD_CONTROL(2) | MOD_ALT(1), VK_O = 0x4F
    $global:hotkeyRegistered = [Win32Api]::RegisterHotKey($form.Handle, 1, (2 -bor 1), 0x4F)
} catch { $global:hotkeyRegistered = $false }

# ---- go ----
Invoke-PurgeRestore   # 启动即清理过期隔离批次
Update-Status
if ($Tray) {
    # 托盘模式: 启动后不弹任何窗口, 仅驻留系统托盘.
    $form.WindowState = 'Minimized'
    $form.ShowInTaskbar = $false
    $form.Hide()
}
[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::Run($form)