﻿<#
.SYNOPSIS
    CleanOpt - 静默内存优化器 (真实可用版).

    优化策略（按优先级）:
      1) [主回收] 终止 WorkBuddy --prewarm 预热带进程:
         这些是可丢弃的后台 CLI 缓存, daemon 按需懒重建; 结束它们释放的是真正
         "使用中"的工作集内存(通常 700MB~1GB), 且不会像"清空工作集"那样被进程
         瞬间 fault 回来 —— 是唯一能带来"持续下降"的动作.
         仅匹配命令行含 --prewarm 的进程, 绝不碰当前会话/UI/后端/主程序.
      2) [补充] 清空系统备用列表 (PurgeStandbyList / FlushModifiedList /
         PurgeLowPriorityStandbyList): 把备用缓存转为真正空闲, 无害, 在机器有
         富余缓存时带来额外可用空间. 需要管理员权限.

    已移除旧版的 EmptyWorkingSets(清空所有进程工作集, cmd 5):
      在内存真被用满的机器上它几乎无效(进程立刻把页面 fault 回工作集), 且优化时
      新拉起的子进程反而实增内存, 导致"越优化占用%越高". 现改为针对真正可回收的内存.

    强度:
      strong(默认) = 预热带清理 + 备用列表清理
      standard     = 仅备用列表清理(不结束任何进程, 最保守)

    无窗口、无输出、无弹窗; 仅写日志.
#>

param([string]$Strength = 'strong')

$ErrorActionPreference = 'SilentlyContinue'
$logFile = Join-Path $env:LOCALAPPDATA 'CleanOpt\optimize_mem.log'

# ============ 可调参数 ============
# PCL 路径优先级: ① settings.json 中的 pclPath  ② 留空则自动探测.
$settingsFile = Join-Path $PSScriptRoot 'settings.json'
$PCLPath = ''
if (Test-Path $settingsFile) {
    try {
        $j = Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($j.pclPath) { $PCLPath = $j.pclPath }
    } catch { }
}

function Write-Log {
    param([string]$Msg)
    try {
        $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        $line = "$ts  [optimize_mem] $Msg"
        # 日志旋转: 超过 200KB 时仅保留末尾 500 行, 避免无限增长影响读/写性能
        if (Test-Path $logFile) {
            if ((Get-Item $logFile).Length -gt 200KB) {
                $keep = Get-Content -Path $logFile -Encoding UTF8 -Tail 500 -ErrorAction SilentlyContinue
                Set-Content -Path $logFile -Value $keep -Encoding UTF8
            }
        }
        Add-Content -Path $logFile -Value $line -Encoding UTF8
    } catch { }
}

# ============ 原生备用列表清理引擎 (C#) ============
$src = @'
using System;
using System.Runtime.InteropServices;

public class MemOpt {
    [DllImport("ntdll.dll")]
    public static extern int NtSetSystemInformation(int SystemInformationClass, ref int SystemInformation, int SystemInformationLength);

    [DllImport("kernel32.dll")]
    public static extern IntPtr GetCurrentProcess();

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool LookupPrivilegeValue(string lpSystemName, string lpName, out long lpLuid);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool AdjustTokenPrivileges(IntPtr TokenHandle, bool DisableAllPrivileges, ref TOKEN_PRIVILEGES NewState, uint BufferLength, IntPtr PreviousState, IntPtr ReturnLength);

    [StructLayout(LayoutKind.Sequential)]
    public struct LUID { public uint LowPart; public int HighPart; }

    [StructLayout(LayoutKind.Sequential)]
    public struct LUID_AND_ATTRIBUTES { public LUID Luid; public uint Attributes; }

    [StructLayout(LayoutKind.Sequential)]
    public struct TOKEN_PRIVILEGES { public uint PrivilegeCount; public LUID_AND_ATTRIBUTES Privileges; }

    public static void EnablePrivilege(string name) {
        const uint TOKEN_ADJUST_PRIVILEGES = 0x20;
        const uint TOKEN_QUERY = 0x8;
        const uint SE_PRIVILEGE_ENABLED = 0x2;
        IntPtr token;
        if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, out token)) {
            long luid;
            if (LookupPrivilegeValue(null, name, out luid)) {
                TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES();
                tp.PrivilegeCount = 1;
                tp.Privileges.Luid = new LUID { LowPart = (uint)(luid & 0xFFFFFFFF), HighPart = (int)(luid >> 32) };
                tp.Privileges.Attributes = SE_PRIVILEGE_ENABLED;
                AdjustTokenPrivileges(token, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            }
        }
    }

    public static int RunCommand(int command) {
        return NtSetSystemInformation(0x50, ref command, 4);
    }
}
'@
# 程序集缓存: 首次编译后落盘到 LOCALAPPDATA\CleanOpt\MemOpt.dll, 后续运行直接加载,
# 避免每次优化(可能每分钟一次)都重新用 Roslyn 编译 C#, 省时明显.
$asmDir = Join-Path $env:LOCALAPPDATA 'CleanOpt'
if (-not (Test-Path $asmDir)) { try { New-Item -ItemType Directory -Path $asmDir -Force | Out-Null } catch { } }
$asmPath = Join-Path $asmDir 'MemOpt.dll'
function Load-MemOpt {
    if (Test-Path $asmPath) {
        try {
            [System.Reflection.Assembly]::LoadFrom($asmPath) | Out-Null
            $t = [System.AppDomain]::CurrentDomain.GetAssemblies() | ForEach-Object { $_.GetType('MemOpt') } | Where-Object { $_ } | Select-Object -First 1
            if ($t -and $t.GetMethod('RunCommand')) { return $true }
        } catch { }
        try { Remove-Item $asmPath -Force -ErrorAction SilentlyContinue } catch { }   # DLL 异常则删除重编
    }
    try {
        Add-Type -TypeDefinition $src -OutputAssembly $asmPath -OutputType Library -ErrorAction Stop
        [System.Reflection.Assembly]::LoadFrom($asmPath) | Out-Null
        return $true
    } catch {
        try { Add-Type -TypeDefinition $src -ErrorAction Stop; return $true } catch { return $false }
    }
}
if (-not (Load-MemOpt)) { Write-Log "MemOpt 引擎加载失败"; exit 1 }

# ============ 备用列表清理 (替换旧版"清空所有进程工作集") ============
function Invoke-StandbyPurge {
    # 提升强力清理所需的特权
    [MemOpt]::EnablePrivilege("SeProfileSingleProcessPrivilege")
    [MemOpt]::EnablePrivilege("SeIncreaseQuotaPrivilege")

    $cmds = @(
        @{ c = 1; n = "PurgeStandbyList" },
        @{ c = 4; n = "FlushModifiedList" },
        @{ c = 2; n = "PurgeLowPriorityStandbyList" }
    )
    $ok = 0; $fail = 0; $detail = @()
    foreach ($item in $cmds) {
        $r = [MemOpt]::RunCommand($item.c)
        if ($r -eq 0) { $ok++; $detail += "$($item.n):OK" }
        else { $fail++; $detail += "$($item.n):err$r" }
    }
    if ($ok -gt 0) {
        return $true
    } else {
        Write-Log "备用列表清理 FAILED 全部命令失败: $($detail -join ', ') (需管理员权限及对应特权)"
        return $false
    }
}

# ============ 终止 WorkBuddy 预热带 (真正的可回收内存) ============
function Invoke-PrewarmCleanup {
    $killed = 0; $reclaimed = 0
    try {
        $cim = Get-CimInstance Win32_Process -Filter "Name LIKE 'WorkBuddy%'" -ErrorAction SilentlyContinue
        $targets = $cim | Where-Object { $_.CommandLine -match '--prewarm' }
        if (-not $targets) { return @{ Killed = 0; ReclaimedMB = 0 } }
        foreach ($t in $targets) {
            try {
                $mb = [math]::Round($t.WorkingSetSize / 1MB, 1)
                $reclaimed += $mb
                $p = Get-Process -Id $t.ProcessId -ErrorAction Stop
                $p.Kill()
                $killed++
            } catch { }
        }
    } catch { }
    return @{ Killed = $killed; ReclaimedMB = [math]::Round($reclaimed, 1) }
}

# ============ 探测 PCL (可选, 仅用于备用列表清理) ============
function Find-PCL {
    # 1) 手动指定优先
    if ($PCLPath -and (Test-Path $PCLPath)) { return $PCLPath }

    $names = @('PCL.exe', 'PCL2.exe', 'Plain Craft Launcher 2.exe')
    $user = [Environment]::GetFolderPath('UserProfile')
    $desktop = [Environment]::GetFolderPath('Desktop')
    $programFiles = [Environment]::GetFolderPath('ProgramFiles')
    $programFilesX86 = [Environment]::GetFolderPath('ProgramFilesX86')
    $dirs = @(
        $desktop,
        (Join-Path $user 'Downloads'),
        (Join-Path $user 'Documents'),
        'D:\软件', 'D:\Software', 'D:\Games', 'D:\游戏', 'D:\Tools',
        $programFiles,
        $programFilesX86
    )
    foreach ($d in $dirs) {
        if (-not (Test-Path $d)) { continue }
        # 先查一层
        foreach ($n in $names) {
            $p = Join-Path $d $n
            if (Test-Path $p) { return $p }
        }
        # 再对"软件/游戏"类目录做有限深度递归 (最多 3 层), 兼顾性能
        if ($d -match '软件|Software|Games|游戏|Tools') {
            try {
                Get-ChildItem -Path $d -Recurse -Depth 3 -ErrorAction SilentlyContinue |
                    Where-Object { $_.PSIsContainer -eq $false -and $names -contains $_.Name } |
                    ForEach-Object { return $_.FullName }
            } catch { }
        }
    }
    return $null
}

# ============ 调用 PCL 静默优化 (仅备用列表清理的替代路径) ============
function Invoke-PCLMemOpt {
    param([string]$Exe)
    try {
        $p = Start-Process -FilePath $Exe -ArgumentList '--memory' -WindowStyle Hidden -PassThru
        $exited = $p.WaitForExit(60000)
        if (-not $exited) {
            try { $p.Kill() } catch { }
            Write-Log "PCL 调用超时(>60s)已终止, 回退原生引擎"
            return $false
        }
        Write-Log "PCL 静默优化完成 (exit=$($p.ExitCode))"
        return $true
    } catch {
        Write-Log ("PCL 调用异常: " + $_.Exception.Message + " -> 回退原生引擎")
        return $false
    }
}

# ============ 主流程 ============
try {
    # 优化前可用内存
    $os0 = Get-CimInstance Win32_OperatingSystem
    $freeBefore = $os0.FreePhysicalMemory  # KB

    # 主回收: 终止 WorkBuddy 预热带 (strong 才做, standard 只清备用列表)
    $pre = @{ Killed = 0; ReclaimedMB = 0 }
    if ($Strength -ne 'standard') {
        $pre = Invoke-PrewarmCleanup
    }

    # 补充: 清空系统备用列表 (PCL 优先, 否则原生)
    $usedPCL = $false
    $pcl = $null
    if ($PCLPath -and (Test-Path $PCLPath)) {
        $pcl = $PCLPath
    } elseif (Test-Path (Join-Path $env:LOCALAPPDATA 'CleanOpt\pcl.path')) {
        $cached = (Get-Content (Join-Path $env:LOCALAPPDATA 'CleanOpt\pcl.path') -Encoding UTF8 -Raw -ErrorAction SilentlyContinue) -replace '\s+$', ''
        if ($cached -and (Test-Path $cached)) { $pcl = $cached }
    }
    if (-not $pcl) {
        $pcl = Find-PCL
        if ($pcl) { try { Set-Content -Path (Join-Path $env:LOCALAPPDATA 'CleanOpt\pcl.path') -Value $pcl -Encoding UTF8 } catch { } }
    }
    if ($pcl) {
        Write-Log "检测到 PCL: $pcl -> 备用列表清理优先用 PCL --memory"
        if (Invoke-PCLMemOpt $pcl) {
            $usedPCL = $true
        } else {
            Write-Log "PCL 调用失败, 回退原生引擎"
        }
    }
    if (-not $usedPCL) {
        $nativeOk = Invoke-StandbyPurge
        if (-not $nativeOk) { Write-Log "原生备用列表清理失败" }
    }

    # 优化后可用内存
    $os1 = Get-CimInstance Win32_OperatingSystem
    $freeAfter = $os1.FreePhysicalMemory  # KB
    $freedMB = [math]::Round(($freeAfter - $freeBefore) / 1024, 1)
    $engine = if ($usedPCL) { 'PCL' } else { 'Native' }

    $parts = @()
    if ($pre.Killed -gt 0) { $parts += "预热带结束 $($pre.Killed) 个(≈$($pre.ReclaimedMB)MB)" }
    $parts += "备用列表已清理"
    $parts += "净释放≈${freedMB}MB"
    Write-Log ("OK " + ($parts -join ', ') + " (前=$([math]::Round($freeBefore/1024/1024,2))GB 后=$([math]::Round($freeAfter/1024/1024,2))GB) 引擎=$engine 强度=$Strength")
    exit 0
} catch {
    Write-Log ("ERROR: " + $_.Exception.Message)
    exit 2
}
