CleanOpt · 系统清理与内存优化工具 使用说明
========================================

【简介】
CleanOpt 是一套纯 PowerShell 实现的 Windows 清理 / 内存优化工具。
默认以管理员权限运行，后台静默清理垃圾 + 优化内存，常驻系统托盘，
全程不弹任何窗口。

【快速安装】
1. 把本压缩包解压到任意目录（例如 D:\Tools\useful_files）。
2. 双击根目录的 install.bat（建议右键“以管理员身份运行”）。
   安装脚本会：
     - 把工具复制到 C:\Program Files\CleanOpt
     - 在桌面创建“CleanOpt”快捷方式
     - 注册每日静默清理任务（03:00）与开机自启（登录后后台运行）
3. 双击桌面“CleanOpt”即可运行（默认最小化到托盘）。
   右键托盘图标可：立即优化内存 / 清空回收站 / 打开软件 / 设置 /
   运行日志 / 导出诊断 / 关于 / 退出。

【不安装直接运行】
- 直接双击 CleanOpt\CleanOpt.ps1（首次会请求管理员权限），同样可用。
- CleanOpt\CleanOpt-Tray.cmd 也可一键以托盘模式启动（已提权）。
- CleanOpt\CleanOpt.lnk 是托盘模式快捷方式，可固定到任务栏 / 桌面。

【核心功能】
- 内存优化：优先调用 PCL（PCL.exe --memory）静默优化；未检测到则使用
  原生四步强力引擎（清空工作集 / 刷新修改页 / 清空备用列表），达到
  PCL / Mem Reduct / RAMMap 同级别。
- 垃圾清理：检测到火绒则尽量走火绒后台静默清理；否则系统原生清理
  （TEMP / Prefetch / 缩略图 / Delivery Optimization / 浏览器缓存，
  安全、不碰用户数据）。
- 每分钟监控：内存紧张 / 磁盘不足 / 空闲时才自动优化。
- 游戏 / 全屏免打扰、全局热键 Ctrl+Alt+O、托盘图标随内存压力变色。
- 单实例：重复启动只唤醒已存在的窗口，不重复运行。
- 设置可配置阈值 / 间隔 / 强度 / 延迟 / 免打扰进程 / 回收站等。

【卸载】
以管理员运行：
  PowerShell -File "C:\Program Files\CleanOpt\install.ps1" -Uninstall
（也可重新运行安装包内的 安装.bat 后手动删除目录）。

【文件清单】
  CleanOpt\CleanOpt.ps1        主程序（窗口 + 后台监控）
  CleanOpt\optimize_mem.ps1    内存优化引擎
  CleanOpt\clean_daily.ps1     每日垃圾清理
  CleanOpt\daily_run.ps1       每日任务入口（清理→优化→回收站）
  CleanOpt\Register-Tasks.ps1  注册 / 注销计划任务（需管理员）
  CleanOpt\CleanOpt-Tray.cmd   托盘模式快速启动（已提权）
  CleanOpt\CleanOpt.lnk        托盘模式快捷方式
  install.ps1                  安装 / 卸载脚本
  install.bat                  以管理员运行安装脚本的入口

【生成自解压 exe（useful_files.exe）】
本包已附带 IExpress 指令文件 useful_files.sed 与一键生成器 build_exe.bat：
1. 把压缩包解压到任意目录（会得到 useful_files\ 文件夹 + useful_files.sed + build_exe.bat）。
2. 双击 build_exe.bat（无需管理员）。
3. 同目录下即生成 useful_files.exe 自解压包；双击它即可解压出全部文件。
   注意：build_exe.bat 依赖 Windows 自带的 IExpress，仅在你自己的电脑上可用，
   在受限/沙箱环境里会被拦截（属正常）。

【备注】
所有后台任务均 100% 无窗口、无弹窗、无提示，
仅写日志到 %LOCALAPPDATA%\CleanOpt\*.log。

本次版本 (v1.7) 优化点：
  - 托盘图标按压力档（绿/黄/红）缓存复用，修复长时间驻留的 GDI 句柄泄漏；
  - 监控循环合并 WMI 查询，降低每分钟开销。
