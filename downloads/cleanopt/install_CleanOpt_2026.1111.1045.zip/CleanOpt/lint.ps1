﻿<#
.SYNOPSIS
    CleanOpt static quality gate (read-only, changes nothing).
.DESCRIPTION
    Checks every .ps1 in this folder for:
      1. PowerShell parser errors
      2. UTF-8 BOM and consistent CRLF line endings (required by Windows PowerShell 5.1)
      3. duplicate function definitions
      4. calls that are neither defined functions, known cmdlets, nor known externals
      5. exactly one well-formed AppVersion
    Exit code 0 = PASS, 1 = FAIL.
.NOTES
    Run from a Windows PowerShell 5.1 host with -ExecutionPolicy Bypass.
#>
[CmdletBinding()]
param([string]$Root = $PSScriptRoot)

$ErrorActionPreference = 'Continue'
$script:fail = 0
$script:warn = 0
function Fail([string]$m) { $script:fail++; Write-Host ('[FAIL] ' + $m) }
function Warn([string]$m) { $script:warn++; Write-Host ('[WARN] ' + $m) }
function Info([string]$m) { Write-Host ('[ OK ] ' + $m) }

$files = @(Get-ChildItem -LiteralPath $Root -Filter '*.ps1' -File -ErrorAction SilentlyContinue | Sort-Object Name)
if ($files.Count -eq 0) { Fail "no .ps1 files in $Root"; exit 1 }

$knownExternal = @('if','else','elseif','switch','cmd','netsh','ipconfig','rd','del','reg','schtasks',
    'dism','taskkill','findstr','robocopy','powershell','cleanmgr','wmic','attrib','takeown',
    'icacls','sc','net','timeout','exit','return','break','continue','for','foreach','while',
    'do','try','catch','finally','throw','function','filter','begin','process','end','param',
    'trap','data','using','class','enum','in','not','and','or')
$cmdletNames = @{}
Get-Command -CommandType Cmdlet,Function -ErrorAction SilentlyContinue | ForEach-Object { $cmdletNames[$_.Name.ToLower()] = $true }

$allDefs = @{}
$parsed = @{}
foreach ($f in $files) {
    $tok = $null; $err = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$tok, [ref]$err)
    $parsed[$f.Name] = $ast
    if ($err.Count -gt 0) {
        foreach ($e in ($err | Select-Object -First 3)) { Fail ("{0}: L{1} {2}" -f $f.Name, $e.Extent.StartLineNumber, $e.Message) }
    } else { Info ("syntax  {0}" -f $f.Name) }

    $bytes = [System.IO.File]::ReadAllBytes($f.FullName)
    if (-not ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)) {
        Fail ("BOM missing: {0}" -f $f.Name)
    }
    $text = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
    $bareLf = ([regex]::Matches($text, "(?<!`r)`n")).Count
    if ($bareLf -gt 0) { Fail ("bare LF line endings: {0} ({1} lines)" -f $f.Name, $bareLf) }

    $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true) | ForEach-Object {
        $key = $_.Name.ToLower()
        if (-not $allDefs.ContainsKey($key)) { $allDefs[$key] = @() }
        $allDefs[$key] += ("{0}:L{1}" -f $f.Name, $_.Extent.StartLineNumber)
    }
}

foreach ($k in ($allDefs.Keys | Sort-Object)) {
    if ($allDefs[$k].Count -gt 1) {
        $locs = @($allDefs[$k])
        $fileCount = @($locs | ForEach-Object { ($_ -split ':L')[0] } | Sort-Object -Unique).Count
        if ($fileCount -lt $locs.Count) { Warn ("duplicate function '{0}' in one file at {1}" -f $k, ($locs -join ', ')) }
        else { Info ("shared helper '{0}' defined independently in {1} scripts" -f $k, $locs.Count) }
    }
}

foreach ($f in $files) {
    $ast = $parsed[$f.Name]
    $names = @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] -and $n.GetCommandName() }, $true) |
        ForEach-Object { $_.GetCommandName().ToLower() } | Sort-Object -Unique)
    foreach ($n in $names) {
        if ($allDefs.ContainsKey($n)) { continue }
        if ($cmdletNames.ContainsKey($n)) { continue }
        if ($knownExternal -contains $n) { continue }
        if ($n -match '\\|/|\.exe$|\.ps1$|\.cmd$|\.bat$') { continue }
        Fail ("undefined call '{0}' in {1}" -f $n, $f.Name)
    }
}

$main = Join-Path $Root 'CleanOpt.ps1'
if (Test-Path -LiteralPath $main) {
    $txt = [System.IO.File]::ReadAllText($main, [System.Text.Encoding]::UTF8)
    $vs = @([regex]::Matches($txt, "\`$script:AppVersion\s*=\s*'([^']+)'") |
        ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
    if ($vs.Count -ne 1) { Fail ("AppVersion definitions = {0}" -f ($vs -join ', ')) }
    elseif ($vs[0] -notmatch '^20\d{2}\.\d{4}\.\d{4}$') { Fail ("bad version format: {0}" -f $vs[0]) }
    else { Info ("AppVersion = {0}" -f $vs[0]) }
} else { Fail 'CleanOpt.ps1 not found' }

Write-Host ''
Write-Host ("files={0}  fail={1}  warn={2}" -f $files.Count, $script:fail, $script:warn)
if ($script:fail -gt 0) { Write-Host 'RESULT: FAIL'; exit 1 }
Write-Host 'RESULT: PASS'
exit 0
