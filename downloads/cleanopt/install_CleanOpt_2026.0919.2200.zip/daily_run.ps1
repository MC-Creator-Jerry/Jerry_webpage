﻿<#
.SYNOPSIS
    CleanOpt - Daily runner invoked by the scheduled task.
    Runs the silent junk cleaner, then the memory optimizer, then (optionally)
    empties the Recycle Bin. Fully unattended.

.NOTES
    Launched by Task Scheduler with -WindowStyle Hidden, so it produces no window.
    The "empty Recycle Bin" step is controlled by settings.json -> dailyEmptyRecycle
    (default: true).
#>

$ErrorActionPreference = 'SilentlyContinue'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Definition

# 1) Junk cleanup
& "$dir\clean_daily.ps1"

# 2) Memory optimize
& "$dir\optimize_mem.ps1"

# 3) Empty Recycle Bin (optional, from settings.json)
$settingsFile = Join-Path $dir 'settings.json'
$emptyRecycle = $true
if (Test-Path $settingsFile) {
    try {
        $j = Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -ne $j.dailyEmptyRecycle) { $emptyRecycle = [bool]$j.dailyEmptyRecycle }
    } catch { }
}
if ($emptyRecycle) {
    # 仅清空【当前用户】回收站：原生 rd /s /q 快速可靠，不卡顿、不跨用户失败
    try {
        $sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    } catch { $sid = $null }
    if ($sid) {
        $drives = @(Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction SilentlyContinue |
            ForEach-Object { $_.DeviceID.TrimEnd(':') + ':' })
        foreach ($drv in $drives) {
            $bin = "$drv\`$Recycle.Bin\$sid"
            if (-not (Test-Path -LiteralPath $bin)) { continue }
            $lp = '\\?\' + $bin
            cmd /c "rd /s /q ""$lp""" 2>$null
            if (Test-Path -LiteralPath $bin) {
                Get-ChildItem -LiteralPath $bin -Force -ErrorAction SilentlyContinue | ForEach-Object {
                    $p = '\\?\' + $_.FullName
                    if ($_.PSIsContainer) { cmd /c "rd /s /q ""$p""" 2>$null }
                    else { cmd /c "del /f /q ""$p""" 2>$null }
                }
            }
        }
    }
}

exit 0
